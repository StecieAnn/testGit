//JQuery Calendar Date Picker
(function($) {
    jQuery.fn.pickDate = function(callback) 
    {//http://stackoverflow.com/questions/2638740/jquery-datepicker-mindate-maxdate
        var date=jQuery.datepicker.formatDate('yy-mm-dd',new Date());
        this.each( function() {
            var me=jQuery(this);
            if(me.val().length==0){
                callback(moment().format("YYYY-MM-DD"),me); 
            }
            
            
            me.attr({"readonly":"readonly"}).datepicker({ showButtonPanel: true,dateFormat: 'yy-mm-dd',changeYear: true,changeMonth: true,
            beforeShow: function() { 
                var dateMin = new Date(1963, 1 - 1, 1);
                me.datepicker('option',{ minDate: dateMin, maxDate: '+3Y' });
            },
            onClose: function () {
                callback(moment(jQuery(this).datepicker( 'getDate')).format("YYYY-MM-DD"),me);
            }});
        });
    };
}(jQuery));
novia.selectedRecord = {};

var vars = {};
window.location.href.replace( location.hash, '' ).replace( 
    /[?&]+([^=&]+)=?([^&]*)?/gi, // regexp
    function( m, key, value ) { // callback
        vars[key] = value !== undefined ? value : '';
    }
); 

novia.loadModulesMenu = function(){
    network.get("./Users/modules", {}, function(data){
        //novia.showAlert(JSON.stringify(data.modules)); 
        var links="";
        if(data.modules!==undefined && data.modules.length>0){
          jQuery.each(data.modules,function(index,link){
             links+='<li class="divider"></li>';
             links+='<li><a href="./?load='+link.module+'">'+link.menutext+'</a></li>';
          });
        }
        jQuery("#systemModules").empty().html(links);
    }, true);    
};
novia.loadMenu = function(){
   
    if(vars['load']!==undefined){
        network.get("./Users/", {data:{module:vars['load']}}, function(data){
            if(data!==undefined){
                if(data.user!==undefined){
                    novia.displayUserInfo(data.user);               
                }
                if(data.permissions!==undefined){
                    novia.displayModuleMenu(data.permissions); 
                    novia.loadModulesMenu();                                 
                }
            }
        }, true); 
    }
    else{
        novia.loadModulesMenu();
    }
};
novia.showHelp = function(help){
  if(help.length>0){
      var text = '<div class="well"><div class="list-group">';
      for (var i = help.length - 1; i >= 0; i--){
        text+='<a href="javascript:void(0)" class="list-group-item">'+help[i]+'</a>';//
      };
      text+='</div></div>';
      novia.showAlert(text);
  }  
};
novia.searchEmployee = function(data,event,context,isGuard,isPosted,beforeSearch,callback){
    var searchTerm=jQuery.trim(data.searchTerm());
    if ((event.type=="click" || event.keyCode == 13)&&searchTerm.length>0) {
        try {
            var callbackfunc = eval(beforeSearch);
            callbackfunc();
        } catch (e) {}        
        
        var action = (isGuard&&isPosted)?"searchPostedEmployeesByPF":"searchClockedEmployeesByPF";
        if(!isGuard){
            action = "searchAllEmployeesByPF";
        }
        network.get("Employees/"+action+"/"+searchTerm, {}, function(record){
            if(record.length>0){
                callback(record[0]);
            }
        }, true);
    }
    
    if(event.keyCode == 16) {
        try {
            var callbackfunc = eval(beforeSearch);
            callbackfunc();
        } catch (e) {}
        
        var action = (isGuard&&isPosted)?"searchPostedEmployees":"searchClockedEmployees";
        if(!isGuard){
            action = "searchAllEmployees";
        }
        novia.ajaxSearchDialog("Employees",action,"pf_number,first_name,other_names,id_no",function(record){
            callback(record);
        });
    }
};

novia.viewEmployee = function(record){
    record.id_no = (record.id_no===undefined)?"None":record.id_no;
    return record.pf_number+" - "+record.first_name+" "+record.other_names+" ID : "+record.id_no;
};

novia.viewGuard = function(record){
    record.id_no = (record.id_no===undefined)?"None":record.id_no;
    record.mobile_no = (record.mobile_no===undefined)?"None":record.mobile_no;
    record.assignment = (record.assignment===undefined)?"None":record.assignment;
    return record.pf_number+" - "+record.first_name+" "+record.other_names+" ID : "+record.id_no+" Tel : "+record.mobile_no+" - Assignment : "+record.assignment;
};

novia.displayUserInfo = function(info){
    q("#display_name").html(info.display_name+" ");
};

novia.package=null;
novia.class=null;
novia.classText = null;
novia.loadJS=function(){
    network.axiosGet(network.rootpath+"/loadJS/"+novia.package+"$"+novia.class, {}, function(data){
        if(data!==undefined){
            var mainContent=q("#mainContent");
            mainContent.empty().html(data);
        }
    }, false);
};

novia.loadHTML=function(callBack){
    novia.createModalWindow(network.rootpath+"/loadHTML/"+novia.package+"$"+novia.class,novia.classText,callBack);
};

novia.afterFormInit=function(formObject){
    novia.populateForm(formObject,novia.selectedRecord);
    try {
        var func = eval(formId+"_after_fill");
        if(jQuery.isFunction(func)) {
            func(formObject);
        }                  
    } 
    catch (e){}
};

novia.loadHTMLNoModal=function(callBack){
    network.get(network.rootpath+"/loadHTML/"+novia.package+"$"+novia.class, {}, function(html) {
        var mainContent=q("#mainContent");
        mainContent.empty().html(html);
        setTimeout(function(){
            var func = eval(callBack);
            if(jQuery.isFunction(func)) {
                func(html);
            }  
        },200);
    });
};

novia.displayModuleMenu = function(menu){
    //https://bootsnipp.com/snippets/OVVM
    var mainContent=q("#mainContent");
    var m='';
    var m='<div class="panel panel-default">'; 
        m+='<div class="panel-heading">'; 
        m+='<h4 class="panel-title" id="dashboard">'; 
        m+='<a data-toggle="collapse" href="javascript:void(0);"><span class="glyphicon glyphicon-th-large">'; 
        m+='</span>Dash Board</a>'; 
        m+='</h4>'; 
        m+='</div>';
        m+='</div>';   
    q("#parentAccordion").find('.menuItem').click(function() {
        var moduleComponent = q(this).find('a').attr("menuid");
        var moduleUnit = q(this).find('a').attr("unitid");
        var moduleUnitText = q(this).find('a').text();
        moduleComponent=moduleComponent.replace(/menu_/g,"");;
        novia.package=moduleComponent;
        novia.class=moduleUnit;
        novia.classText=moduleUnitText;
        novia.loadJS();
    });
};
novia.createMainContentGrid = function(obj) {
    var mainContent=q("#mainContent"); 
    network.get(network.rootpath+"/loadHTML/grid$list", {}, function(htmlData){
        mainContent.empty().html(htmlData);
        setTimeout(function(){
           initGrid(obj); 
        },200);
    }, false);
};
//novia.loadMenu();
novia.displayModuleMenu();
