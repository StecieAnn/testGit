var network = {};
var novia = novia || {};

function getCookie(name) {
  var value = "; " + document.cookie;
  var parts = value.split("; " + name + "=");
  if (parts.length == 2) return parts.pop().split(";").shift();
}

network.basepath = "";
network.rootpath = network.basepath;
network.ajax = function(uri, method, data, datatype, callback) {
    var callbackfunc = null;
    try {
        callbackfunc = eval(callback);
        if (!jQuery.isFunction(callbackfunc)) {
            novia.showAlert("Ajax Requests With no Callbacks not allowed! Hakuna kurusha mawe hapa!");
            return;
        }
    } catch (e) { alert("Ajax Requests Not Understood!" + e.message); return; }

    var contenttype = 'text/plain';
    switch (datatype) { 
        case 'atom':
            {
                contenttype = 'application/atom+xml';
                break;
            }
        case 'css':
            {
                contenttype = 'text/css';
                break;
            }
        case 'javascript':
            {
                contenttype = 'text/javascript';
                break;
            }
        case 'image':
            {
                contenttype = 'image/jpeg';
                break;
            }
        case 'json':
            {
                contenttype = 'application/json; charset=utf-8';
                break;
            }
        case 'pdf':
            {
                contenttype = 'application/pdf';
                break;
            }
        case 'rss':
            {
                contenttype = 'application/rss+xml';
                break;
            }
        case 'plain':
            {
                contenttype = 'text/plain; charset=utf-8';
                break;
            }
        case 'xml':
            {
                contenttype = 'application/xml,text/xml; charset=utf-8';
                break;
            }
        default:
            {
                contenttype = 'application/x-www-form-urlencoded; charset=UTF-8';
                break;
            }
    }
    var options = {};
    options.url = uri;
    options.type = method;
    options.dataType = datatype;
    if (options.dataType == 'xml') {
        options.crossDomain = true;
        options.cache = false;
        options.async = true;
    }
    options.contentType = contenttype;
    if ((datatype === 'json' || datatype == 'jsonp') && method.toLowerCase()==="post") {
        data = JSON.stringify(data);
    }
    options.data = data;
    options.beforeSend = function(xhr) {
        // xhr.setRequestHeader("custom_header", "value");
    };
    options.headers = {
        /*
		 * "Accept": "text/plain; charset=utf-8", "Content-Type": "text/plain;
		 * charset=utf-8"
		 */
        'X-CSRF-Token':getCookie('csrfToken')
    };
    
    jQuery.msg({
        autoUnblock : false,
        clickUnblock : false,
        fadeOut : 2,
        content : 'Background Processing. Please wait..... ',
        afterBlock : function(){
            // store 'this' for other scope to use
            var self = this;
            var jqXHR = jQuery.ajax(options).done(function(responsedata, status, jqXHR) {
                self.unblock();
                if(responsedata.status!==undefined){
                   if(responsedata.status==="loggedout"){
                       jQuery(location).attr('href',"./login");
                   }
                }
                callbackfunc(responsedata);
            }).fail(function(jqXHR, status, err) {
                self.unblock();
                var error={};
                var eMessage ="";
                if(datatype === 'json' || datatype == 'jsonp'){
                    error=jqXHR.responseJSON;
                }
                else{
                    error=jqXHR.responseText;
                }
                // alert(JSON.stringify(error));
                try{
                    eMessage+=" Error : "+error.message;
                    BootstrapDialog.alert(eMessage);
                }
                catch(e){novia.showAlert("Server Error!");}
            }).always(function() {
             
            });
        }  
    });
};

network.upload = function(uri, formData, callback, isjson) {

    jQuery.ajax({
        url: network.basepath + uri,
        type: 'POST',
        data: formData,
        mimeType: "multipart/form-data",
        async: false,
        cache: false,
        contentType: false,
        processData: false,
        success: callback(returndata),
        error: function(jqXHR, textStatus, errorThrown) {

        }
    });
};

function generateErrorHTMLOutput(error) {
    var res = "";
    if (error.response) {
      // The request was made and the server responded with a status code
      // that falls out of the range of 2xx
      console.log(error.response.data);
      console.log(error.response.status);
      console.log(error.response.headers);
      res+='<pre>' + error.request + '</pre>';
    } else if (error.request) {
      // The request was made but no response was received
      // `error.request` is an instance of XMLHttpRequest in the browser and an instance of
      // http.ClientRequest in node.js
      console.log(error.request);
      res+='<pre>' + error.request + '</pre>';
    } else {
      // Something happened in setting up the request that triggered an Error
      res+='<pre>' + error.message + '</pre>';
      console.log('Error', error.message);
    }    
    
  return res;
 
}

network.post = function(path, data, callback, isjson) {
    var datatype = (isjson) ? "json" : "html"; 
    network.ajax(network.basepath + path, "post", data, datatype, callback); 
};

network.get = function(path, data, callback, isjson) {
    var datatype = (isjson) ? "json" : "html"; 
    network.ajax(network.basepath + path, "get", data, datatype, callback); 
};

network.getScript = function(path) {
    jQuery.getScript(network.basepath + path)
    .done(function() {})
    .fail(function(jqXHR, status, err) {
        BootstrapDialog.alert(err + "  " + jqXHR.responseText);
    });
};

axios.defaults.headers.common['X-CSRF-Token'] = getCookie('csrfToken');

network.axiosPost = function(path, sendData, callback,timeout) {
    var instance = axios.create();
    if(timeout!==undefined && !isNaN(parseInt(timeout))){
        instance.defaults.timeout = parseInt(timeout);
    }
    instance.post(path,sendData)
    .then(function (response) {
        callback(response.data);
    })
    .catch(function (error) {
        BootstrapDialog.alert(generateErrorHTMLOutput(error));// JSON.stringify(error));
    }); 
};

network.axiosGet = function(path, sendData, callback,timeout) {
    var instance = axios.create();
    if(timeout!==undefined && !isNaN(parseInt(timeout))){
        instance.defaults.timeout = parseInt(timeout);// 2500 = requests will
														// wait 2.5 seconds
														// before timing out
    }
    instance.get(path,sendData)
    .then(function (response) {
        callback(response.data);
    })
    .catch(function (error) {
        BootstrapDialog.alert(generateErrorHTMLOutput(error));
    }); 
};

w2utils.settings['date_format'] = 'yyyy-mm-dd';// 'yyyy-mm-dd';
// w2utils.settings['groupSymbol'] = ",";
// APPLICATION DETAILS
/*
 * NAME OF APPLICATION
 */
novia.appName = "Novia Sacco Soft Suite";
/*
 * VERSION OF APPLICATION
 */
novia.appVersion = "3.0";
/*
 * APPLICATION RELEASE DATE
 */
novia.appCommencementDate = "07th November 2016";
/*
 * This solution is created to be SAAS Thus we need to identify which customer
 * is using it App Installed for
 */
novia.isdebugmode=true;
novia.userId = 1;
// FORM
novia.dialogForm = null;
novia.dialogFormConfig = null;
novia.hasGrid = false;
novia.canAddToGrid = true;
novia.canEditGrid = true;
novia.canDeleteFromGrid = true;
novia.isSubmittingForm = false;
novia.formDataBeforeSave = null;
novia.formDataAfterSave = null;
/* SET Validity Output Mode */
novia.setValidityOutputMode=function($mode){
    switch ($mode) {
        case "summary":
        {
            jQuery.validity.setup({ outputMode:"summary" });
            var div='<div id="validationerrors" style="display: none;">';
            div+='<div class="validity-summary-container" style="margin: 0; padding: 0px;">';
            div+='<span style="margin-left: 20px; color: #002166; font-weight: bold; font-size: 18px;">Summary of the validation failures:</span>';
            div+='<ul></ul>';
            div+='</div></div>';
            if(jQuery("#validationerrors").length==0){// Ensure we append
														// summary validation
														// div once
                jQuery("body").append(div);
            }
            break;   
        }
        default :{
            jQuery.validity.setup({ outputMode:"modal" });
            break;
        }
    }
};
novia.setValidityOutputMode("summary");
novia.closeValidityMessages = function(){
    jQuery(".validity-modal-msg").each(function(i, elem){// Submit if no more
															// error messages
        jQuery(elem).click();
    });
};

/* BOOTSTRAP DIALOG */
novia.currentDialog = null;
// Basic Alert
novia.showAlert = function(theMessage) {
    BootstrapDialog.alert(theMessage);
};

novia.showMessageWithAction = function(theMessage, onShownCallback, onCloseCallback) {
    BootstrapDialog.show({
        title: 'System Message',
        closable: false,
        message: "<div style='overflow-x:auto;'>" + theMessage + "</div>",
        buttons: [{
            label: 'OK',
            cssClass: 'btn-primary',
            hotkey: 13, // Enter.
            action: function(dialog) {
                try { dialog.close(); var func = eval(onCloseCallback); if (jQuery.isFunction(func)) { func(); } } catch (e) { dialog.close(); }
            }
        }],
        onshown: function(dialogRef) {
            setTimeout(function() { dialogRef.close(); try { var func = eval(onShownCallback); if (jQuery.isFunction(func)) { func(); } } catch (e) {} }, 20000);
        }
    });
};

novia.confirmOption = function(theSqlQuery, callback) {
    var btnClass = 'btn-warning';
    var exitConfirmDialog = BootstrapDialog.show({
        title: "Confirmation Operation",
        message: theSqlQuery + '<h3>Continue?</h3>',
        closable: false,
        buttons: [{
                label: 'Cancel',
                action: function(dialog) {
                    dialog.close();
                    novia.isSubmittingForm = false; // THIS FLAG IS ONLY
													// APPROPRIATE FOR FORM
													// SUBMISSION. OTHERWISE IT
													// MAY BE IGNORED!
                }
            },
            {
                label: 'Yes! Continue',
                hotkey: 13,
                cssClass: btnClass,
                action: function(dialog) {
                    dialog.close();
                    try { var func = eval(callback); if (jQuery.isFunction(func)) { setTimeout(function() { func(); }, 50); } } catch (e) {}
                }
            }
        ]
    });
};

novia.setBootstrapWindowTitle = function(title) {
    var dialog = (novia.dialogForm!==null)?novia.dialogForm:novia.currentDialog;
    // alert(dialog);
    if (dialog !== null){
        dialog.setTitle(title.toUpperCase());   
    }
};

novia.removeBootstrapWindowButtons = function() {
    var dialog = (novia.dialogForm!==null)?novia.dialogForm:novia.currentDialog;
    // alert(dialog);
    if (dialog !== null){
        dialog.getModalFooter().empty();
    }
};

novia.removeBootstrapSubmitButton = function() {
    var dialog = (novia.dialogForm!==null)?novia.dialogForm:novia.currentDialog;
    // alert(dialog);
    if (dialog !== null){
        if(dialog.getModalFooter().find("button").length==3){
            dialog.getModalFooter().find("button")[0].remove();   
        }
    }
};

novia.removePopUpSubmitButton = function(container) {
    container.parent().parents(".modal-content").find('.bootstrap-dialog-footer').find("button").eq(0).remove();
};

novia.createModalWindow=function(url,windowTitle,onShowCallBack){
    var callback=function(data){
            var dialog=BootstrapDialog.show({
                title: windowTitle,
                closable: true,
                closeByBackdrop: false,
                closeByKeyboard: false,
                cssClass: 'form-dialog',
                message: jQuery('<div class="form-holder">'+data+'</div>'),
                buttons: [{
                    label: 'Submit (Press Enter)',
                    cssClass: 'btn-primary',
                    // hotkey: 13, // Enter.
                    action: function(dialogRef) {
                        var currentDialogForm = dialogRef.getModalBody().find('form').eq(0);
                        var formId=currentDialogForm.attr("name");
                        var func = eval(formId+"_before_save");
                        if(jQuery.isFunction(func)) {
                            func(currentDialogForm);
                        }                       
                    }
                },
                {
                    label: 'Reset & New',
                    cssClass: 'btn-primary',
                    action: function(dialogRef) {
                        var currentDialogForm = dialogRef.getModalBody().find('form').eq(0);
                        var formId=currentDialogForm.attr("name");
                        if(currentDialogForm!==null && currentDialogForm!==undefined){
                            currentDialogForm.get(0).reset();
                            currentDialogForm.find("input[name='id']").val(0).trigger('change');// SET
																								// ID
																								// TO
																								// ZERO
                            try {
                                var func = eval(formId+"_after_reset");
                                if(jQuery.isFunction(func)) {
                                    func(currentDialogForm);
                                }                  
                            } 
                            catch (e) {}
                        }
                    }
                },
                {
                    label: 'Close',
                    cssClass: 'btn-primary',
                    action: function(dialogRef) {
                        novia.closeValidityMessages();
                        dialogRef.close();
                    }
                }],
                onshown: function(dialogRef){
                    var currentDialogForm = dialogRef.getModalBody().find('form').eq(0);
                    novia.dialogForm = dialogRef;
                    var formId=currentDialogForm.attr("name");
                    var initForm = eval(formId+"_init");
                    if(jQuery.isFunction(initForm)) {
                        jQuery.when(initForm(currentDialogForm)).then(function() {
                             try {
                                if(jQuery.isFunction(eval(onShowCallBack))) {
                                    onShowCallBack(currentDialogForm);
                                }                   
                            } 
                            catch (e) {}
                        });
                    }
                    else{
                        novia.showAlert("Failed To Initialize Form. App may not work as Expected!");
                    }
                },
                onhidden: function(dialogRef){
                    var currentDialogForm = dialogRef.getModalBody().find('form').eq(0);
                    var formId=currentDialogForm.attr("name");
                    dialogRef.getModalBody().html("");
                    currentDialogForm.w2destroy();
                    dialogRef=null;
                    try {
                        var afterFCLS = eval(formId+"_after_close");
                        afterFCLS(currentDialogForm);              
                    } 
                    catch (e) {}
                    // CLOSE ALL ACTIVE MODAL MESSAGES
                    novia.closeValidityMessages();
                }
            });
    };
    if(url!=null && url.length>0){
        network.get(url, {}, function(html) {
          callback(html);
        });
    }
};
//


novia.bootstrapWindow = function(url, windowTitle, onshowcallback) {
    var callback = function(formHTML) {
        novia.currentDialog = BootstrapDialog.show({
            title: windowTitle,
            cssClass: 'form-dialog',
            closable: true,
            closeByBackdrop: false,
            closeByKeyboard: false,
            message: jQuery('<div id="modalpanel" class="panel panel-primary" style="margin:0;padding:0;padding-top:5px;"><div class="panel-body" style="margin:0;padding:0;">' + formHTML + '</div></div>'),
            buttons: [{
                    label: 'Submit (Press Enter)',
                    cssClass: 'btn-primary',
                    action: function(dialogRef) {
                        var currentDialogForm = dialogRef.getModalBody().find('form').eq(0);
                        var func = eval(currentDialogForm.attr("name") + "_beforesave");
                        if (jQuery.isFunction(func)) {
                            func(novia.currentDialogForm);
                        }
                    }
                },
                {
                    label: 'Reset & New',
                    cssClass: 'btn-primary',
                    action: function(dialogRef) {
                        var currentDialogForm = dialogRef.getModalBody().find('form').eq(0);
                        var func = eval(currentDialogForm.attr("name") + "_reset");
                        if (jQuery.isFunction(func)) {
                            func(currentDialogForm);
                        }
                    }
                },
                {
                    label: 'Cancel',
                    cssClass: 'btn-primary',
                    action: function(dialogRef) {
                        dialogRef.close();
                    }
                }
            ],
            onshow: function(dialogRef) {
                novia.dialogForm = dialogRef.getModalBody().find('form').eq(0);
            },
            onshown: function(dialogRef) {
                var formName = novia.dialogForm.attr("name");
                var initForm = eval(formName + "_init");
                if (jQuery.isFunction(initForm)) {
                    novia.formDataBeforeSave = null;
                    jQuery.when(initForm(novia.dialogForm)).then(function() {
                        try {
                            var func = eval(onshowcallback);
                            if (jQuery.isFunction(func)) {
                                func(dialogRef.getModalBody().find('form').eq(0));
                            }
                        } catch (e) { alert(e.message); }
                    });
                } else {
                    BootstrapDialog.alert("Failed To Initialize Form. App may not work as Expected!");
                }
            },
            onhidden: function(dialogRef) {
                try {
                    var formName = novia.dialogForm.attr("name");
                    var afterFCLS = eval(formName + "_close");
                    if (jQuery.isFunction(afterFCLS)) {
                        afterFCLS();
                    }
                } catch (e) {}
                // CLOSE ALL ACTIVE MODAL MESSAGES
                novia.closeValidityMessages();
            }
        });
    };
    if (url != null && url.length > 0) {
        jQuery.get(url, function(data) {
            if (data !== null) {
                callback(data);
            }
        });
    }
};

novia.showPopup = function(popupTitle, popupMessage, onshowcallback) {
    var popup = BootstrapDialog.show({
        title: popupTitle,
        closable: true,
        closeByBackdrop: true,
        closeByKeyboard: true,
        message: jQuery('<div class="panel panel-primary"><div class="panel-body">' + popupMessage + '</div></div>'),
        buttons: [{
            label: 'Close',
            cssClass: 'btn-primary',
            hotkey: 13,
            action: function(dialog) { dialog.close(); }
        }],
        onshown: function(dialogRef) {
            try {
                var func = eval(onshowcallback);
                if (jQuery.isFunction(func)) {
                    func(dialogRef.getModalBody().find('form').eq(0));
                }
            } catch (e) { alert(e.message); }
        }
    });
    return popup;
};

novia.showFormPopup = function(popupTitle, popupMessage, initData,onshowcallback) {
    var popup = BootstrapDialog.show({
        title: popupTitle,
        closable: true,
        closeByBackdrop: true,
        closeByKeyboard: true,
        message: jQuery('<div class="panel panel-primary"><div class="panel-body">' + popupMessage + '</div></div>'),
        buttons: [{
            label: 'Submit',
            cssClass: 'btn-primary',
            action: function(dialogRef) {
                try {
                    var currentDialogForm = dialogRef.getModalBody().find('form').eq(0);
                    var formId=currentDialogForm.attr("name");
                    var func = eval(formId+"_before_save");
                    if(jQuery.isFunction(func)) {
                        func(currentDialogForm);
                    }
                } catch (e) { 
                    w2popup.open({
                        title   : 'Invocation Error!',
                        body    : '<textarea class="text-danger" style="margin:5px; width:98%; height:90%; resize:none;" readonly="readonly">'+e.message+'</textarea>',
                        buttons : ''
                    }); 
                }
            },
            hotkey: 13,
            
        },{
            label: 'Close',
            cssClass: 'btn-primary',
            action: function(dialog) { dialog.close(); }
        }],
        onshown: function(dialogRef) {
            try {
                var currentDialogForm = dialogRef.getModalBody().find('form').eq(0);
                var formId=currentDialogForm.attr("name");
                var func = eval(formId+"_init");
                if(jQuery.isFunction(func)) {
                    func(currentDialogForm,initData);
                }
                setTimeout(function() {
                    var onshowfunc = eval(onshowcallback);
                    if(jQuery.isFunction(onshowfunc)) {
                        onshowfunc(currentDialogForm,initData);
                    }
                },1000);                
            } catch (e) { 
                w2popup.open({
                    title   : 'Invocation Error!',
                    body    : '<textarea class="text-danger" style="margin:5px; width:98%; height:90%; resize:none;" readonly="readonly">'+e.message+'</textarea>',
                    buttons : ''
                }); 
            }
        }
    });
    return popup;
};

novia.ajaxSearchDialog=function(controller,action,searchFields,callback){
  var dialog=null;
  var cols=Array();
  // cols.push({ field: 'recid', caption: 'ID', size: '10%' });
  var sf=searchFields.split(',');
  jQuery.each(sf,function(elem){
      elem=jQuery.trim(elem);
      cols.push({ field: sf[elem], caption: sf[elem].replace(/_/gi, " ").toUpperCase(), size: '10%' });
  });
  var getSearchData=function(){
    var searchTerm=dialog.getModalBody().find('#popupsearch').val();
    var ajaxCallback=function(data){
        if(w2ui['ajaxSearchGrid']!==undefined){
            w2ui['ajaxSearchGrid'].destroy(); 
        }
        jQuery.each(data, function(i, elem) {
            data[i].recid = data[i].id;
        });
        setTimeout(function () {
            jQuery().w2grid({
              name: 'ajaxSearchGrid',
              columns: cols,
              records: data,
              multiSelect : false,
              onKeydown: function(event) {
                    if(event.originalEvent.which==13){
                        var selItem=w2ui['ajaxSearchGrid'].get(w2ui['ajaxSearchGrid'].getSelection()[0]);
                        if(selItem!==null)submitSearchedItem(selItem);
                    }
             }
            });  
            // dialog.setMessage('Message 1');
            dialog.getModalBody().find('#ajaxSearchPopupGrid').w2render('ajaxSearchGrid');
        },100);
    };    
    network.get(controller+"/"+action+"/"+searchTerm, {}, function(jsonData){
        ajaxCallback(jsonData);
    }, true);    
  };
  
  var submitSearchedItem=function(selItem){
        if(selItem!==null){
            try {
                dialog.close();
                var func = eval(callback);
                if(jQuery.isFunction(func)) {
                    func(selItem);
                }               
            } 
            catch (e) {
                dialog.close();
            }                     
        }
        else{
            novia.showAlert("But you selected nothing!!!! Click OK then use close(X) button to exit");
        }
  };
  
  // alert(JSON.stringify(cols));
    BootstrapDialog.show({
        size: BootstrapDialog.SIZE_NORMAL,
        title:"Search Dialog",
        closable: true,
        message: '<div><span>Enter Search Term : <span><input style="width=\'25px;\'" id="popupsearch" type="text" /><span><input  id="popupsearchbtn" class="btn-info" style=" margin-left:10px; width:100px; height:23px; font-size:14px; font-weight:bold; " type="button" value="Search" /><span></div></br><div id="ajaxSearchPopupGrid"  style="width: 100%; height: 300px;">Grid Appears Here!</div>',
        onshow: function(dialogRef){
            // alert('Dialog is popping up, its message is ' +
			// dialogRef.getMessage());
        },
        onshown: function(dialogRef){
            dialog=dialogRef;
            getSearchData(); 
           setTimeout(function() {
            dialogRef.getModalBody().find('#popupsearchbtn').click(function() {
                getSearchData();
            });
            
            dialogRef.getModalBody().find('#popupsearch').focus().keyup(function(e) {
                if(e.which == 13 || jQuery(this).val().length==0){// Enter key
																	// pressed
                    getSearchData();
                }
            });
            
           },500);
        },
        onhide: function(dialogRef){
            // alert('Dialog is popping down, its message is ' +
			// dialogRef.getMessage());
        },
        onhidden: function(dialogRef){
            w2ui['ajaxSearchGrid'].destroy(); 
            // alert('Dialog is popped down.');
        },
        buttons: [
        {
            label: 'Choose Selected Item',
            cssClass: 'btn btn-primary',
            action: function(dialog) {
                var selItem=w2ui['ajaxSearchGrid'].get(w2ui['ajaxSearchGrid'].getSelection()[0]);
                submitSearchedItem(selItem);
            }
        },{
            label: 'Close',
            cssClass: 'btn-primary',
            action: function(dialog) { dialog.close(); }
        }]
    });
};
// W2 GRID
novia.clearTableRowSelection = function() {
    jQuery("#formButtons").empty().append("<span style='color:green'>Click an item/Row to Edit or Delete</span>").show();
};



// NOVIA UTILS
/**
 * Function count the occurrences of substring in a string;
 * 
 * @param {String}
 *            string Required. The string;
 * @param {String}
 *            subString Required. The string to search for;
 * @param {Boolean}
 *            allowOverlapping Optional. Default: false;
 * @author Vitim.us
 *         http://stackoverflow.com/questions/4009756/how-to-count-string-occurrence-in-string/7924240#7924240
 * 
 * Usage
 * 
 * occurrences("foofoofoo", "bar"); //0
 * 
 * occurrences("foofoofoo", "foo"); //3
 * 
 * occurrences("foofoofoo", "foofoo"); //1
 * 
 * allowOverlapping
 * 
 * occurrences("foofoofoo", "foofoo", true); //2
 * 
 */
novia.occurrences = function(string, subString, allowOverlapping) {

    string += "";
    subString += "";
    if (subString.length <= 0) return (string.length + 1);

    var n = 0,
        pos = 0,
        step = allowOverlapping ? 1 : subString.length;

    while (true) {
        pos = string.indexOf(subString, pos);
        if (pos >= 0) {
            ++n;
            pos += step;
        } else break;
    }
    return n;
};
// Arrays and Strings
novia.removeArrayElement=function(arr,itemtoRemove,itemvalue){
    var result = jQuery.grep(arr,function(elem){
       return elem[itemtoRemove] != itemvalue; 
    });
};
/*
 * arr = [{'id':'73','foo':'bar'},{'id':'45','foo':'bar'}];
 * novia.arrayElementExists(arr,"id",45);
 */
novia.arrayElementExists=function(arr,itemtosearch,itemvalue){
    var found = {};
    jQuery.map(arr, function(value, key) {
         if (jQuery.trim(value[itemtosearch]).toLowerCase() == jQuery.trim(itemvalue).toLowerCase())
         {
            found=value;
            return value;
         }
    });
    return found[itemtosearch]!==undefined;
};
/*
 * arr = [{'id':'73','foo':'bar'},{'id':'45','foo':'bar'}];
 * novia.getArrayElementAt(arr,"id",45);
 */
novia.getArrayElementAt=function(arr,itemtosearch,itemvalue){
    var found = {};
    jQuery.map(arr, function(value, key) {
         if (jQuery.trim(value[itemtosearch]).toLowerCase() == jQuery.trim(itemvalue).toLowerCase())
         {
             found=value;
             return value;
         }
    });
    return found;
};

// VUE JS WRAPPER. If you understand this then you are sorted.
novia.vueViewModel = function(container, extraData, appMethods = null, computedValues = null, oncreate = null) {
    var defaults = {};
    if (container !== null && container !== undefined) {
        // Loop through the container searching for form elements and
		// initializing them
        jQuery.each(container.find("input,select,textarea"), function() {
            switch (jQuery(this).prop('tagName').toLowerCase()) {
                case "input":
                    {
                        defaults[jQuery(this).attr("v-model")] = "";
                        break;
                    }
                case "select":
                    {
                        defaults[jQuery(this).attr("v-model")] = 0;
                        break;
                    }
                case "textarea":
                    {
                        defaults[jQuery(this).attr("v-model")] = "";
                        break;
                    }
            }
            if(jQuery(this).attr("v-model")===undefined){// Delete undefined values
                delete defaults[jQuery(this).attr("v-model")];
            }
        });
    }
    
    if(container.prop('tagName')=="FORM"){
        container.parent().parents(".modal-content").find('.bootstrap-dialog-footer').find("button").eq(1).on("click",function(){
            for (var property in defaults) {
                if (defaults.hasOwnProperty(property)) {
                    defaults[property] = "";
                }
            }
        });        
    }
    
    // Overide some default values. Especially multi-select and mult-check boxes
    jQuery.each(extraData, function(index, value) {
        defaults[index] = value;
    });
    // Ensure on create function is sane
    oncreate = (oncreate == null) ? function() {} : oncreate;
    // Ensure computed values are sane
    computedValues = (computedValues == null) ? {} : computedValues;
    // Ensure methods are sane
    appMethods = (appMethods == null) ? {} : appMethods;

    appMethods.load=function(json){
        if(json!=null && json!==undefined){
            for (var property in json) {
                if (json.hasOwnProperty(property)) {
                    defaults[property] = json[property];
                }
            }
        }
    };
    
    appMethods.clear=function(){
        for (var property in defaults) {
            if (defaults.hasOwnProperty(property)) {
                defaults[property] = "";
            }
        }
    };
    
    appMethods.json=function(){
        return defaults;
    }; 

    // And is your citcumcised boy. He is brave.
    return new Vue({
        el: '#'+container.attr("id"),
        data: defaults,
        methods: appMethods,
        computed: computedValues,
        created: oncreate
    });
};

// Forms
novia.processFormResponse = function(jsonData,callback,formObject){
    var status = jsonData.status;
    switch(status){
        case "error":{
            var errors = "<h4>"+jsonData.message+"</h4>";
            errors+"<hr>";
            jQuery.each(jsonData.data,function(i,v){
                errors+="<h6 class='text-danger'>"+v+"</h6>";
            });
            novia.showAlert(errors);
            break;
        }
        case "success":{
            if(formObject!=null && formObject!==undefined){
                novia.populateForm(formObject,jsonData.data);   
            }
            novia.showAlert("<h3 class='text-success'>"+jsonData.message+"</h3>");
                try {
                    var callbackfunc = eval(callback);
                    if (jQuery.isFunction(callbackfunc)) {
                        callbackfunc(jsonData.data);
                    }
                } catch (e) {}
            break;   
        }
        default : {
            novia.showAlert(JSON.stringify(jsonData));
            break;
        }
    }    
};

novia.submitForm = function(formObject,formData,controller,method,callback){
    network.post("/"+controller+"/"+method+"/",{data:formData}, function(jsonData){
        novia.processFormResponse(jsonData,callback,formObject);
    }, true);
};

novia.deleteRecord = function(record,controller,method,callback){
    network.axiosPost(network.basepath+controller+"/"+method+"/",record, function(jsonData){
        novia.processFormResponse(jsonData,callback,null);
    }, 5000);
};

novia.populateForm=function(form,data)
{
    if(form!==null && form!==undefined){
       form[0].reset();    
    }
    data=utils.dataFormatDate(data);
    jQuery.each(data, function(key, value){
        var ctrl = jQuery('[name='+key+']', form);  
        switch(ctrl.attr("type"))  
        {  
            case "text" :   
            case "hidden":  
            ctrl.val(value).trigger('change');   
            break;   
            case "radio":   
            ctrl.each(function(){
               if(jQuery(this).val()==value) {jQuery(this).attr("checked",true).trigger('change'); } });   
            break;  
            case "checkbox":   
            ctrl.each(function(){
               if(jQuery(this).val()==value) {jQuery(this).click().trigger('change'); } });  
            break;  
            default:{
                if(value==null||value==undefined||value.length==0){
                    value=0;
                }
                ctrl.val(value).trigger('change');
            }
        }  
    });
};




// W2 FIELDS
novia.forceFieldType=function(fieldname,fieldtype,fielddata,vm) {
// http://w2ui.com/web/docs/form/fields?ver=1.2
/*
 * Supported Types int integer float float number hex hexdecimal number money
 * number in money format alphaNumeric alpha-numeric text email email address
 * date date list drop down list select drop down list enum multi-select clear
 * removes any previous type
 */
    var field=jQuery("input[name='"+fieldname+"']");
    switch(fieldtype){
        case 'int':{
            field.w2field('int',options = {groupSymbol:''});
            break;
        }
        case 'float':{
            field.w2field('float',options = {groupSymbol:''});
            break;  
        }
        case 'an':{
            field.w2field('alphaNumeric');
            break;  
        }
        case 'email':{
            field.w2field('email');
            break;  
        }
        case 'date':{
            var dateField = field.w2field('date');
            if(vm!=null && vm!==undefined){
                dateField.on('change', function (event) {
                    vm[fieldname]=event.target.value;
                });                
            }
            break;  
        }
        case 'time':{
            field.w2field('time');
            break;  
        }
        case 'multi':{
            field.w2field('enum', { 
                items: fielddata,
                openOnFocus: true
                // selected: [{ id: 0, text: 'John Adams' }, { id: 0, text:
				// 'Thomas Jefferson' }]
            });
            break;  
        }
        case 'list':{
            field.w2field('list', { 
                items: fielddata
            });
            break;  
        }
    }
};

novia.findByKey=function(array, key,value,type) {
  for (var i = 0; i < array.length; i++) {
    var arraykey = array[i][key];
    if(type==="int"){
        arraykey = parseInt(arraykey);
    }
    if (arraykey === value) {
      return array[i];
    }
  }
  throw "Couldn't find object with key: " + value;
};





var utils={};

utils.dataFormatDate=function(r){
    jQuery.each(r, function(key, value){  
        if(key.indexOf('date')!=-1){
            var localDate = new Date();
            if(moment(value,  ["MM/DD/YYYY", "MM-DD-YYYY", "YYYY-MM-DD"]).isValid()){
                localDate = moment(value);
            }
            else{
                localDate = moment("2000-01-01");
            }
            r[key]=localDate.format("YYYY-MM-DD");                    
        }
    });
    return r;
};

// https://springmerchant.com/bigcommerce/hide-header-footer-when-printing-bigcommerce/
utils.printHTML=function(elemHTML){
    var isClosed = false;
    var w=window.open("", "Print Window", "width=800, height=600");
    
    // var printDivCSS = new String('<link media="print"
	// href="./assets/bootstrap/css/bootstrap.css" rel="stylesheet">');
    var pageCSS = '<style media="print" type="text/css">@page{size: auto;margin: 1mm;font-family: "DejaVu Sans Mono", monospace;}</style>';
    
    // function to call if you want to print
    var onPrintFinished=function(printed)
    {
        setTimeout(function(){w.close();}, 500);
    };
    
    jQuery.get("./assets/bootstrap/css/bootstrap.css", function( cssdata ) {
        if(w!=null && w!=undefined){
            w.document.write('<html moznomarginboxes mozdisallowselectionprint><head>');
            w.document.write('<style media="print" type="text/css">'+cssdata+'</style>'+pageCSS);
            w.document.write('</head>');
            w.document.write('<body>'+elemHTML+'</body></html>');
            onPrintFinished(w.print());   
        }
    });
    // w.document.write('<html moznomarginboxes
	// mozdisallowselectionprint><head>'+printDivCSS+pageCSS+'</head><body>'+elemHTML+'</body></html>');
    
};
