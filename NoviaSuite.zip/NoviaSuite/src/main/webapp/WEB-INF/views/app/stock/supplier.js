var supplier = {};
supplier.controller = "Supplier";
supplier.hasGrid = true;
supplier.gridEnableSearch = true;
supplier.gridData="suppliers";
supplier.gridTitle="Suppliers";
supplier.gridColumns=
[
    { field: 'supplierName', caption: 'Supplier', size: '30%', sortable: true },
    { field: 'contactPerson', caption: 'Contact Person', size: '30%', sortable: true },
    { field: 'phoneNumber', caption: 'Phone Number', size: '30%', sortable: true }
];

supplier.canView = true;
supplier.canAdd = true;
supplier.canEdit = true;
supplier.canDelete = true;

supplier.formURL = "save";
supplier.deleteURL = "delete";
supplier.findOneURL = "findOne";
supplier.selectedRecord = {};

supplier.deleteCallBack = function(record,callback) {
    novia.deleteRecord(record,supplier.controller,supplier.deleteURL,function(data) {
        callback();
    });
};
//VIEW MODEL
supplier.viewModel = null;
 
supplier.init = function (formObject) {
    var initData = {isEnabled:1};
    var appMethods = {
        submitForm: function(event) {
            var submitData = this.json();
            network.axiosPost("./"+supplier.controller+"/"+supplier.formURL,submitData,function (response) {
                novia.showAlert(JSON.stringify(response));
            });
        }
    };
    var computedValues = {};
    var onCreate = function() {};
    supplier.viewModel = novia.vueViewModel(formObject, initData, appMethods, computedValues, onCreate);
    if(supplier.selectedRecord.id!==undefined){
        supplier.viewModel.load(supplier.selectedRecord);
    }
};




function supplier_init(formObject) {
    novia.removeBootstrapSubmitButton();
    supplier.init(formObject);        
}
function supplier_before_save(formObject) {}
function supplier_after_reset (formObject) {
    supplier.viewModel.clear();
}
function supplier_after_close (formObject) {
    supplier.selectedRecord = {};
    novia.createMainContentGrid(supplier);
}
novia.createMainContentGrid(supplier);
