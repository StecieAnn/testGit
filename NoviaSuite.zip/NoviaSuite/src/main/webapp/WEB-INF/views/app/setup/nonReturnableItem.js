var non_returnable_item = {};
non_returnable_item.controller = "NonReturnableItem";
non_returnable_item.hasGrid = true;
non_returnable_item.gridEnableSearch = true;
non_returnable_item.gridData="nonReturnableItems";
non_returnable_item.gridTitle="Non-Returnable Items";
non_returnable_item.gridColumns=
[
    { field: 'product.displayName', caption: 'Product', size: '30%', sortable: true },
    { field: 'quantity', caption: 'Quantity', size: '30%', sortable: true }
];

non_returnable_item.canView = true;
non_returnable_item.canAdd = true;
non_returnable_item.canEdit = true;
non_returnable_item.canDelete = true;

non_returnable_item.formURL = "save";
non_returnable_item.deleteURL = "delete";
non_returnable_item.findOneURL = "findOne";
non_returnable_item.selectedRecord = {};

non_returnable_item.deleteCallBack = function(record,callback) {
    novia.deleteRecord(record,non_returnable_item.controller,non_returnable_item.deleteURL,function(data) {
        callback();
    });
};
//VIEW MODEL
non_returnable_item.viewModel = null;
 
non_returnable_item.init = function (formObject) {
    var initData = {product:null,products:Array()};
    var appMethods = {
        submitForm: function(event) {
            var submitData = this.json();
            network.axiosPost("./"+non_returnable_item.controller+"/"+non_returnable_item.formURL,submitData,function (response) {
                novia.showAlert(JSON.stringify(response));
            });
        }
    };
    var computedValues = {};
    var onCreate = function() {
   	 var context = this;
	   network.axiosGet("./Product/products",{},function (response) {
		   context.products=response;
	   });
    };
    non_returnable_item.viewModel = novia.vueViewModel(formObject, initData, appMethods, computedValues, onCreate);
    if(non_returnable_item.selectedRecord.id!==undefined){
    	setTimeout(() => {
	    	//novia.showAlert(JSON.stringify(non_returnable_item.selectedRecord));
	        non_returnable_item.viewModel.load(non_returnable_item.selectedRecord);
		}, 300);
    }
};




function non_returnable_item_init(formObject) {
    novia.removeBootstrapSubmitButton();
    non_returnable_item.init(formObject);        
}
function non_returnable_item_before_save(formObject) {}
function non_returnable_item_after_reset (formObject) {
    non_returnable_item.viewModel.clear();
}
function non_returnable_item_after_close (formObject) {
    non_returnable_item.selectedRecord = {};
    novia.createMainContentGrid(non_returnable_item);
}
novia.createMainContentGrid(non_returnable_item);
