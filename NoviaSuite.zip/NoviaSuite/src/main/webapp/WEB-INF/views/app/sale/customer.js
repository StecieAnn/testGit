var customer = {};
customer.controller = "Customer";
customer.hasGrid = true;
customer.gridEnableSearch = true;
customer.gridData="customers";
customer.gridTitle="Customers";
customer.gridColumns=
[
	{ field: 'customerCode', caption: 'Customer Code', size: '30%', sortable: true },
    { field: 'customerName', caption: 'Customer Name', size: '30%', sortable: true },
    { field: 'contactName', caption: 'Contact Name', size: '30%', sortable: true },
    { field: 'phoneNumber', caption: 'Phone Number', size: '10%', sortable: true }
];

customer.canView = true;
customer.canAdd = true;
customer.canEdit = true;
customer.canDelete = true;

customer.formURL = "save";
customer.deleteURL = "delete";
customer.findOneURL = "findOne";
customer.selectedRecord = {};

customer.deleteCallBack = function(record,callback) {
    novia.deleteRecord(record,customer.controller,customer.deleteURL,function(data) {
        callback();
    });
};
//VIEW MODEL
customer.viewModel = null;
 
customer.init = function (formObject) {
    var initData = {isEnabled:1};
    var appMethods = {
        submitForm: function(event) {
            var submitData = this.json();
            network.axiosPost("./"+customer.controller+"/"+customer.formURL,submitData,function (response) {
                novia.showAlert(JSON.stringify(response));
            });
        }
    };
    var computedValues = {};
    var onCreate = function() {};
    customer.viewModel = novia.vueViewModel(formObject, initData, appMethods, computedValues, onCreate);
    if(customer.selectedRecord.id!==undefined){
        customer.viewModel.load(customer.selectedRecord);
    }
};




function customer_init(formObject) {
    novia.removeBootstrapSubmitButton();
    customer.init(formObject);        
}
function customer_before_save(formObject) {}
function customer_after_reset (formObject) {
    customer.viewModel.clear();
}
function customer_after_close (formObject) {
    customer.selectedRecord = {};
    novia.createMainContentGrid(customer);
}
novia.createMainContentGrid(customer);
