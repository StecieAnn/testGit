var purchase_receipt = {};
purchase_receipt.controller = "PurchaseReceipt";
purchase_receipt.hasGrid = true;
purchase_receipt.gridEnableSearch = true;
purchase_receipt.gridData="purchaseReceipts";
purchase_receipt.gridTitle="Purchase Receipts";
purchase_receipt.gridColumns=
	[
		{ field: 'purchaseOrder.description', caption: 'Description', size: '30%', sortable: true },
		{ field: 'grnNo', caption: 'GRN No.', size: '30%', sortable: true },
		{ field: 'deliveryNoteNo', caption: 'Delivery Note No.', size: '30%', sortable: true }
	];

purchase_receipt.canView = true;
purchase_receipt.canAdd = true;
purchase_receipt.canEdit = true;
purchase_receipt.canDelete = true;

purchase_receipt.formURL = "save";
purchase_receipt.deleteURL = "delete";
purchase_receipt.findOneURL = "findOne";
purchase_receipt.selectedRecord = {};

purchase_receipt.deleteCallBack = function(record,callback) {
    novia.deleteRecord(record,purchase_receipt.controller,purchase_receipt.deleteURL,function(data) {
        callback();
    });
};
//VIEW MODEL
purchase_receipt.viewModel = null;
 
purchase_receipt.init = function (formObject) {
    var initData = {isEnabled:1,purchaseOrders:Array(),suppliers:Array(),paymentModes:Array(),receivedItems:Array()};
    var appMethods = {
        submitForm: function(event) {
        	var context=this;
            var submitData = context.json();
            network.axiosPost("./"+purchase_receipt.controller+"/"+purchase_receipt.formURL,submitData,function (response) {
            	context.load(response);
                novia.showAlert(JSON.stringify(response));
            });
        },
        addReceiptItem: function(event) {
        	novia.createModalWindow(network.rootpath+"/loadHTML/purchase$purchaseReceiptItem","Purchase Receipt Item",function(html){});
        },
        receiptItems: function(event) {
        	var context=this;
        	network.axiosPost("./PurchaseReceiptItem/findByPurchaseReceiptModel",context.json(),function (response) {
           		context.receivedItems = response;	
           	});
        }
    };
    var computedValues = {};
    var onCreate = function() {
    	var context=this;
    	network.axiosGet("./PurchaseOrder/purchaseOrders",{},function (response) {
    	context.purchaseOrders = response;	
    	});
    	var context=this;
    	network.axiosGet("./Supplier/suppliers",{},function (response) {
    	context.suppliers = response;	
    	});
    	var context=this;
    	network.axiosGet("./PaymentMode/paymentModes",{},function (response) {
    	context.paymentModes = response;	
    	});
    };
    purchase_receipt.viewModel = novia.vueViewModel(formObject, initData, appMethods, computedValues, onCreate);
    if(purchase_receipt.selectedRecord.id!==undefined){
        purchase_receipt.viewModel.load(purchase_receipt.selectedRecord);
        setTimeout(() => {
        	  purchase_receipt.viewModel.load(purchase_receipt.selectedRecord);
        	purchase_receipt.viewModel.receiptItems();
		}, 400);
        
    }
    jQuery(".dateField").pickDate(function(dateVal,src) {
    	purchase_receipt.viewModel[src.prop("id")] = dateVal;
	});
    
};




function purchase_receipt_init(formObject) {
    novia.removeBootstrapSubmitButton();
    purchase_receipt.init(formObject);        
}
function purchase_receipt_before_save(formObject) {}
function purchase_receipt_after_reset (formObject) {
    purchase_receipt.viewModel.clear();
}
function purchase_receipt_after_close (formObject) {
    purchase_receipt.selectedRecord = {};
    novia.createMainContentGrid(purchase_receipt);
}
novia.createMainContentGrid(purchase_receipt);
