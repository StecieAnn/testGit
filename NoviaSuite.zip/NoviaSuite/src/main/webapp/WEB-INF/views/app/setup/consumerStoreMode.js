var consumer_store_mode = {};
consumer_store_mode.controller = "ConsumerStoreMode";
consumer_store_mode.hasGrid = true;
consumer_store_mode.gridEnableSearch = true;
consumer_store_mode.gridData="consumerStoreModes";
consumer_store_mode.gridTitle="Consumer Store Modes";
consumer_store_mode.gridColumns=
[
    { field: 'product.displayName', caption: 'Product', size: '20%', sortable: true },
    { field: 'quantity', caption: 'Quantity', size: '20%', sortable: true }
];

consumer_store_mode.canView = true;
consumer_store_mode.canAdd = true;
consumer_store_mode.canEdit = true;
consumer_store_mode.canDelete = true;

consumer_store_mode.formURL = "save";
consumer_store_mode.deleteURL = "delete";
consumer_store_mode.findOneURL = "findOne";
consumer_store_mode.selectedRecord = {};

consumer_store_mode.deleteCallBack = function(record,callback) {
    novia.deleteRecord(record,consumer_store_mode.controller,consumer_store_mode.deleteURL,function(data) {
        callback();
    });
};
//VIEW MODEL
consumer_store_mode.viewModel = null;
 
consumer_store_mode.init = function (formObject) {
    var initData = {isEnabled:1,products:Array()};
    var appMethods = {
        submitForm: function(event) {
            var submitData = this.json();
            network.axiosPost("./"+consumer_store_mode.controller+"/"+consumer_store_mode.formURL,submitData,function (response) {
                novia.showAlert(JSON.stringify(response));
            });
        }
    };
    var computedValues = {};
    
    var onCreate = function() {
    	 var context = this;
    	   network.axiosGet("./Product/products",{},function (response) {
    		   context.products=response;
         });	
    };
    consumer_store_mode.viewModel = novia.vueViewModel(formObject, initData, appMethods, computedValues, onCreate);
    if(consumer_store_mode.selectedRecord.id!==undefined){
    	setTimeout(() => {
    	     consumer_store_mode.viewModel.load(consumer_store_mode.selectedRecord);	
		}, 300);
   
    }
};




function consumer_store_mode_init(formObject) {
    novia.removeBootstrapSubmitButton();
    consumer_store_mode.init(formObject);        
}
function consumer_store_mode_before_save(formObject) {}
function consumer_store_mode_after_reset (formObject) {
    consumer_store_mode.viewModel.clear();
}
function consumer_store_mode_after_close (formObject) {
    consumer_store_mode.selectedRecord = {};
    novia.createMainContentGrid(consumer_store_mode);
}
novia.createMainContentGrid(consumer_store_mode);
