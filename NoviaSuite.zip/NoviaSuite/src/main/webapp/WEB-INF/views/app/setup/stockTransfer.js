var stock_transfer = {};
stock_transfer.controller = "StockTransfer";
stock_transfer.hasGrid = true;
stock_transfer.gridEnableSearch = true;
stock_transfer.gridData="stockTransfers";
stock_transfer.gridTitle="Stock Transfers";
stock_transfer.gridColumns=
[
    { field: 'consumerStoreMode.product.displayName', caption: 'Product', size: '20%', sortable: true },   
    { field: 'quantity', caption: 'Quantity', size: '20%', sortable: true },
    { field: 'transferDate', caption: 'Transfer Date', size: '30%', sortable: true }
];

stock_transfer.canView = true;
stock_transfer.canAdd = true;
stock_transfer.canEdit = true;
stock_transfer.canDelete = true;

stock_transfer.formURL = "save";
stock_transfer.deleteURL = "delete";
stock_transfer.findOneURL = "findOne";
stock_transfer.selectedRecord = {};

stock_transfer.deleteCallBack = function(record,callback) {
	//novia.showAlert(JSON.stringify(record,stock_transfer));
   novia.deleteRecord(record,stock_transfer.controller,stock_transfer.deleteURL,function(data) {
        callback();
    });
};
//VIEW MODEL
stock_transfer.viewModel = null;
 
stock_transfer.init = function (formObject) {
    var initData = {isEnabled:1,consumerStoreModes:Array(),products:Array(),productCategories:Array};
    var appMethods = {
        submitForm: function(event) {
            var submitData = this.json();
            network.axiosPost("./"+stock_transfer.controller+"/"+stock_transfer.formURL,submitData,function (response) {
                novia.showAlert(JSON.stringify(response));
            });
        }
    };
    var computedValues = {};
    var onCreate = function() {
        var context = this;
   	   network.axiosGet("./ConsumerStoreMode/consumerStoreModes",{},function (response) {
   		   context.consumerStoreModes=response;
   	   });
   	  var context = this;
  	   network.axiosGet("./Product/products",{},function (response) {
  		   context.products=response;
  	   });
   	   var context = this;
   	   network.axiosGet("./ProductCategory/productCategories",{},function (response) {
   		   context.productCategories=response;
   	   });
    };
    stock_transfer.viewModel = novia.vueViewModel(formObject, initData, appMethods, computedValues, onCreate);
    stock_transfer.viewModel.$watch("productCategory",function(newValue,oldValue){
    	var context=this;
    	network.axiosPost("./Product/findByProductCategory",newValue,function (response) {
       		context.products = response;	
       	});

    });
    if(stock_transfer.selectedRecord.id!==undefined){
       setTimeout(() => {
    	   stock_transfer.viewModel.load(stock_transfer.selectedRecord);
	}, 300);
    }
    
    jQuery(".dateField").pickDate(function(dateVal,src) {
    	stock_transfer.viewModel[src.prop("id")] = dateVal;
	});
};




function stock_transfer_init(formObject) {
    novia.removeBootstrapSubmitButton();
    stock_transfer.init(formObject);        
}
function stock_transfer_before_save(formObject) {}
function stock_transfer_after_reset (formObject) {
    stock_transfer.viewModel.clear();
}
function stock_transfer_after_close (formObject) {
    stock_transfer.selectedRecord = {};
    novia.createMainContentGrid(stock_transfer);
}
novia.createMainContentGrid(stock_transfer);
