var sale_tax = {};
sale_tax.controller = "SaleTax";
sale_tax.hasGrid = true;
sale_tax.gridEnableSearch = true;
sale_tax.gridData="saleTaxes";
sale_tax.gridTitle="Stock Taxes";
sale_tax.gridColumns=
[
    { field: 'taxName', caption: 'Tax Name', size: '20%', sortable: true },
    { field: 'taxRate', caption: 'Tax Rate%', size: '20%', sortable: true }
];

sale_tax.canView = true;
sale_tax.canAdd = true;
sale_tax.canEdit = true;
sale_tax.canDelete = true;

sale_tax.formURL = "save";
sale_tax.deleteURL = "delete";
sale_tax.findOneURL = "findOne";
sale_tax.selectedRecord = {};

sale_tax.deleteCallBack = function(record,callback) {
    novia.deleteRecord(record,sale_tax.controller,sale_tax.deleteURL,function(data) {
        callback();
    });
};
//VIEW MODEL
sale_tax.viewModel = null;
 
sale_tax.init = function (formObject) {
    var initData = {isEnabled:1};
    var appMethods = {
        submitForm: function(event) {
            var submitData = this.json();
            network.axiosPost("./"+sale_tax.controller+"/"+sale_tax.formURL,submitData,function (response) {
                novia.showAlert(JSON.stringify(response));
            });
        }
    };
    var computedValues = {};
    var onCreate = function() {
    };
    sale_tax.viewModel = novia.vueViewModel(formObject, initData, appMethods, computedValues, onCreate);
    if(sale_tax.selectedRecord.id!==undefined){
        sale_tax.viewModel.load(sale_tax.selectedRecord);
    }
};




function sale_tax_init(formObject) {
    novia.removeBootstrapSubmitButton();
    sale_tax.init(formObject);        
}
function sale_tax_before_save(formObject) {}
function sale_tax_after_reset (formObject) {
    sale_tax.viewModel.clear();
}
function sale_tax_after_close (formObject) {
    sale_tax.selectedRecord = {};
    novia.createMainContentGrid(sale_tax);
}
novia.createMainContentGrid(sale_tax);
