var purchase_return = {};
purchase_return.controller = "PurchaseReturn";
purchase_return.hasGrid = true;
purchase_return.gridEnableSearch = true;
purchase_return.gridData="purchaseReturns";
purchase_return.gridTitle="Purchase Returns";
purchase_return.gridColumns=
	[
		{ field: 'product.displayName', caption: 'Product', size: '20%', sortable: true },
		{ field: 'productCategory.description', caption: 'Category', size: '20%', sortable: true },
		{ field: 'purchaseReceipt.deliveryNoteNo', caption: 'Delivery Note No.', size: '20%', sortable: true },
		{ field: 'returnNumber', caption: 'Return Number', size: '20%', sortable: true },
		{ field: 'quantity', caption: 'Quantity', size: '20%', sortable: true }
	];

purchase_return.canView = true;
purchase_return.canAdd = true;
purchase_return.canEdit = true;
purchase_return.canDelete = true;

purchase_return.formURL = "save";
purchase_return.deleteURL = "delete";
purchase_return.findOneURL = "findOne";
purchase_return.selectedRecord = {};

purchase_return.deleteCallBack = function(record,callback) {
    novia.deleteRecord(record,purchase_return.controller,purchase_return.deleteURL,function(data) {
        callback();
    });
};
//VIEW MODEL
purchase_return.viewModel = null;
 
purchase_return.init = function (formObject) {
    var initData = {isEnabled:1,productCategories:Array(),suppliers:Array(),products:Array(),purchaseReceipts:Array(),returnedItems:Array()};
    var appMethods = {
        submitForm: function(event) {
        	var context=this;
            var submitData = context.json();
            network.axiosPost("./"+purchase_return.controller+"/"+purchase_return.formURL,submitData,function (response) {
            	context.load(response);
                novia.showAlert(JSON.stringify(response));
            });
        },
        addReturnedItem: function(event) {
        	novia.createModalWindow(network.rootpath+"/loadHTML/purchase$purchaseReturnItem","Purchase Return Item",function(html){});
        },
        returnItems: function(event) {
        	var context=this;
        	network.axiosPost("./PurchaseReturnItem/findByPurchaseReturnModel",context.json(),function (response) {
           		context.returnedItems = response;	
           	});
        }
    };
    var computedValues = {};
    var onCreate = function() {
     	var context=this;
    	network.axiosGet("./Product/products",{},function (response) {
    	context.products = response;	
    	});
    	var context=this;
    	network.axiosGet("./ProductCategory/productCategories",{},function (response) {
    	context.productCategories = response;	
    	});
    	var context=this;
    	network.axiosGet("./PurchaseReceipt/purchaseReceipts",{},function (response) {
    	context.purchaseReceipts = response;	
    	});
    	var context=this;
    	network.axiosGet("./Supplier/suppliers",{},function (response) {
    	context.suppliers = response;	
    	});
    };
    purchase_return.viewModel = novia.vueViewModel(formObject, initData, appMethods, computedValues, onCreate);
    if(purchase_return.selectedRecord.id!==undefined){     
        setTimeout(() => {
        	purchase_return.viewModel.load(purchase_return.selectedRecord);
        	purchase_return.viewModel.returnItems();
		}, 400);
        
    }
    jQuery(".dateField").pickDate(function(dateVal,src) {
    	purchase_return.viewModel[src.prop("id")] = dateVal;
	});
    
};




function purchase_return_init(formObject) {
    novia.removeBootstrapSubmitButton();
    purchase_return.init(formObject);        
}
function purchase_return_before_save(formObject) {}
function purchase_return_after_reset (formObject) {
    purchase_return.viewModel.clear();
}
function purchase_return_after_close (formObject) {
    purchase_return.selectedRecord = {};
    novia.createMainContentGrid(purchase_return);
}
novia.createMainContentGrid(purchase_return);
