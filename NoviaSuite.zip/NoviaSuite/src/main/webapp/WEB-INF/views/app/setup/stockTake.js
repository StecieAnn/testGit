var stock_take = {};
stock_take.controller = "Product";
stock_take.hasGrid = true;
stock_take.gridEnableSearch = true;
stock_take.gridData="products";
stock_take.gridTitle="Stock Takes";
stock_take.gridColumns=
	[
		 { field: 'displayName', caption: 'displayName', size: '30%', sortable: true },
		 { field: 'productCategory.description', caption: 'Product Category', size: '30%', sortable: true },
	    { field: 'description', caption: 'Description', size: '30%', sortable: true }
	];

stock_take.canView = true;
stock_take.canAdd = true;
stock_take.canEdit = false;
stock_take.canDelete = false;

stock_take.formURL = "save";
stock_take.deleteURL = "delete";
stock_take.findOneURL = "findOne";
stock_take.selectedRecord = {};

stock_take.deleteCallBack = function(record,callback) {
    novia.deleteRecord(record,stock_take.controller,stock_take.deleteURL,function(data) {
        callback();
    });
    
};
//VIEW MODEL
stock_take.viewModel = null;
 
stock_take.init = function (formObject) {
    var initData = {products:Array();};
    var appMethods = {
        submitForm: function(event) {
            var submitData = this.json();
            network.axiosPost("./Product/"+stock_take.formURL,submitData,function (response) {
                novia.showAlert(JSON.stringify(response));
                novia.createMainContentGrid(stock_take);
            });
        }
    };

    var computedValues = {};
    var onCreate = function() {
    };
    stock_take.viewModel = novia.vueViewModel(formObject, initData, appMethods, computedValues, onCreate);
    if(stock_take.selectedRecord.id!==undefined){
        setTimeout(() => {
        	stock_take.viewModel.load(stock_take.selectedRecord);
		}, 300);
    }
    
    jQuery("#mainPanelActionButtons").remove();
};




function stock_take_init(formObject) {
    novia.removeBootstrapSubmitButton();
    stock_take.init(formObject);        
}
function stock_take_init(formObject) {
    novia.removeBootstrapeditRecordButton();
    stock_take.init(formObject);        
}

function stock_take_before_save(formObject) {}
function stock_take_after_reset (formObject) {
    stock_take.viewModel.clear();
}
function stock_take_after_close (formObject) {
    stock_take.selectedRecord = {};
    novia.createMainContentGrid(stock_take);
}
novia.createMainContentGrid(stock_take);
