var sale_status = {};
sale_status.controller = "Status";
sale_status.hasGrid = true;
sale_status.gridEnableSearch = true;
sale_status.gridData="statuses";
sale_status.gridTitle="Sale Status";
sale_status.gridColumns=
[
    { field: 'description', caption: 'Description', size: '50%', sortable: true }
];

sale_status.canView = true;
sale_status.canAdd = true;
sale_status.canEdit = true;
sale_status.canDelete = true;

sale_status.formURL = "save";
sale_status.deleteURL = "delete";
sale_status.findOneURL = "findOne";
sale_status.selectedRecord = {};

sale_status.deleteCallBack = function(record,callback) {
    novia.deleteRecord(record,sale_status.controller,sale_status.deleteURL,function(data) {
        callback();
    });
};
//VIEW MODEL
sale_status.viewModel = null;
 
sale_status.init = function (formObject) {
    var initData = {isEnabled:1};
    var appMethods = {
        submitForm: function(event) {
            var submitData = this.json();
            network.axiosPost("./"+sale_status.controller+"/"+sale_status.formURL,submitData,function (response) {
                novia.showAlert(JSON.stringify(response));
            });
        }
    };
    var computedValues = {};
    var onCreate = function() {};
    sale_status.viewModel = novia.vueViewModel(formObject, initData, appMethods, computedValues, onCreate);
    if(sale_status.selectedRecord.id!==undefined){
        sale_status.viewModel.load(sale_status.selectedRecord);
    }
};




function sale_status_init(formObject) {
    novia.removeBootstrapSubmitButton();
    sale_status.init(formObject);        
}
function sale_status_before_save(formObject) {}
function sale_status_after_reset (formObject) {
    sale_status.viewModel.clear();
}
function sale_status_after_close (formObject) {
    sale_status.selectedRecord = {};
    novia.createMainContentGrid(sale_status);
}
novia.createMainContentGrid(sale_status);
