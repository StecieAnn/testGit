var sale_return = {};
sale_return.controller = "SaleReturn";
sale_return.hasGrid = true;
sale_return.gridEnableSearch = true;
sale_return.gridData="saleReturns";
sale_return.gridTitle="Sale Returns";
sale_return.gridColumns=
[
	{ field: 'product.displayName', caption: 'Product', size: '30%', sortable: true },
    { field: 'customer.customerName', caption: 'Customer Name', size: '30%', sortable: true },
    { field: 'status.description', caption: 'Status', size: '30%', sortable: true }
];

sale_return.canView = true;
sale_return.canAdd = true;
sale_return.canEdit = true;
sale_return.canDelete = true;

sale_return.formURL = "save";
sale_return.deleteURL = "delete";
sale_return.findOneURL = "findOne";
sale_return.selectedRecord = {};

sale_return.deleteCallBack = function(record,callback) {
    novia.deleteRecord(record,sale_return.controller,sale_return.deleteURL,function(data) {
        callback();
    });
};
//VIEW MODEL
sale_return.viewModel = null;
 
sale_return.init = function (formObject) {
    var initData = {isEnabled:1,productCategories:Array(),products:Array(),statuses:Array(),customers:Array(),sales:Array()};
    var appMethods = {
        submitForm: function(event) {
            var submitData = this.json();
            network.axiosPost("./"+sale_return.controller+"/"+sale_return.formURL,submitData,function (response) {
                novia.showAlert(JSON.stringify(response));
            });
        }
    };
    var computedValues = {};
    var onCreate = function() {
    	 var context = this;
    	 network.axiosGet("./ProductCategory/productCategories",{},function (response) {
    		 context.productCategories = response;
         });
    	 var context = this;
    	 network.axiosGet("./Product/products",{},function (response) {
    		 context.products = response;
         });
    	 var context = this;
    	 network.axiosGet("./Status/statuses",{},function (response) {
    		 context.statuses = response;
         });
    	 var context = this;
    	 network.axiosGet("./Customer/customers",{},function (response) {
    		 context.customers = response;
         });
    	 var context = this;
    	 network.axiosGet("./Sale/sales",{},function (response) {
    		 context.sales = response;
         });
    };
    sale_return.viewModel = novia.vueViewModel(formObject, initData, appMethods, computedValues, onCreate);
    if(sale_return.selectedRecord.id!==undefined){
    	
     setTimeout(() => {
    	 sale_return.viewModel.load(sale_return.selectedRecord);	
	}, 300);   
    }
    jQuery(".dateField").pickDate(function(dateVal,src) {
    	sale_return.viewModel[src.prop("id")] = dateVal;
	});
};




function sale_return_init(formObject) {
    novia.removeBootstrapSubmitButton();
    sale_return.init(formObject);        
}
function sale_return_before_save(formObject) {}
function sale_return_after_reset (formObject) {
    sale_return.viewModel.clear();
}
function sale_return_after_close (formObject) {
    sale_return.selectedRecord = {};
    novia.createMainContentGrid(sale_return);
}
novia.createMainContentGrid(sale_return);
