var payment_mode = {};
payment_mode.controller = "PaymentMode";
payment_mode.hasGrid = true;
payment_mode.gridEnableSearch = true;
payment_mode.gridData="paymentModes";
payment_mode.gridTitle="Payment Modes";
payment_mode.gridColumns=
[
    { field: 'description', caption: 'Mode', size: '30%', sortable: true }  
   
];

payment_mode.canView = true;
payment_mode.canAdd = true;
payment_mode.canEdit = true;
payment_mode.canDelete = true;

payment_mode.formURL = "save";
payment_mode.deleteURL = "delete";
payment_mode.findOneURL = "findOne";
payment_mode.selectedRecord = {};

payment_mode.deleteCallBack = function(record,callback) {
    novia.deleteRecord(record,payment_mode.controller,payment_mode.deleteURL,function(data) {
        callback();
    });
};
//VIEW MODEL
payment_mode.viewModel = null;
 
payment_mode.init = function (formObject) {
    var initData = {isEnabled:1};
    var appMethods = {
        submitForm: function(event) {
            var submitData = this.json();
            network.axiosPost("./"+payment_mode.controller+"/"+payment_mode.formURL,submitData,function (response) {
                novia.showAlert(JSON.stringify(response));
            });
        }
    };
    var computedValues = {};
    var onCreate = function() {};
    
    payment_mode.viewModel = novia.vueViewModel(formObject, initData, appMethods, computedValues, onCreate);
    if(payment_mode.selectedRecord.id!==undefined){
        payment_mode.viewModel.load(payment_mode.selectedRecord);
    }
};




function payment_mode_init(formObject) {
    novia.removeBootstrapSubmitButton();
    payment_mode.init(formObject);        
}
function payment_mode_before_save(formObject) {}
function payment_mode_after_reset (formObject) {
    payment_mode.viewModel.clear();
}
function payment_mode_after_close (formObject) {
    payment_mode.selectedRecord = {};
    novia.createMainContentGrid(payment_mode);
}
novia.createMainContentGrid(payment_mode);
