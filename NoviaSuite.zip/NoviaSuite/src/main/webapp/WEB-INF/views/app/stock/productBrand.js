var product_brand = {};
product_brand.controller = "ProductBrand";
product_brand.hasGrid = true;
product_brand.gridEnableSearch = true;
product_brand.gridData="productBrands";
product_brand.gridTitle="Product Brands";
product_brand.gridColumns=
[
    { field: 'description', caption: 'Description', size: '50%', sortable: true }
];

product_brand.canView = true;
product_brand.canAdd = true;
product_brand.canEdit = true;
product_brand.canDelete = true;

product_brand.formURL = "save";
product_brand.deleteURL = "delete";
product_brand.findOneURL = "findOne";
product_brand.selectedRecord = {};

product_brand.deleteCallBack = function(record,callback) {
    novia.deleteRecord(record,product_brand.controller,product_brand.deleteURL,function(data) {
        callback();
    });
};
//VIEW MODEL
product_brand.viewModel = null;
 
product_brand.init = function (formObject) {
    var initData = {isEnabled:1};
    var appMethods = {
        submitForm: function(event) {
            var submitData = this.json();
            network.axiosPost("./"+product_brand.controller+"/"+product_brand.formURL,submitData,function (response) {
                novia.showAlert(JSON.stringify(response));
            });
        }
    };
    var computedValues = {};
    var onCreate = function() {};
    product_brand.viewModel = novia.vueViewModel(formObject, initData, appMethods, computedValues, onCreate);
    if(product_brand.selectedRecord.id!==undefined){
        product_brand.viewModel.load(product_brand.selectedRecord);
    }
};




function product_brand_init(formObject) {
    novia.removeBootstrapSubmitButton();
    product_brand.init(formObject);        
}
function product_brand_before_save(formObject) {}
function product_brand_after_reset (formObject) {
    product_brand.viewModel.clear();
}
function product_brand_after_close (formObject) {
    product_brand.selectedRecord = {};
    novia.createMainContentGrid(product_brand);
}
novia.createMainContentGrid(product_brand);
