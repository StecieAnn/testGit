var product_type = {};
product_type.controller = "ProductType";
product_type.hasGrid = true;
product_type.gridEnableSearch = true;
product_type.gridData="productTypes";
product_type.gridTitle="Product Types";
product_type.gridColumns=
[
    { field: 'description', caption: 'Description', size: '50%', sortable: true },

];

product_type.canView = true;
product_type.canAdd = true;
product_type.canEdit = true;
product_type.canDelete = true;

product_type.formURL = "save";
product_type.deleteURL = "delete";
product_type.findOneURL = "findOne";
product_type.selectedRecord = {};

product_type.deleteCallBack = function(record,callback) {
    novia.deleteRecord(record,product_type.controller,product_type.deleteURL,function(data) {
        callback();
    });
};
//VIEW MODEL
product_type.viewModel = null;
 
product_type.init = function (formObject) {
    var initData = {isEnabled:1};
    var appMethods = {
        submitForm: function(event) {
            var submitData = this.json();
            network.axiosPost("./"+product_type.controller+"/"+product_type.formURL,submitData,function (response) {
               novia.showAlert(JSON.stringify(response));
            });
        }
    };
    var computedValues = {};
    var onCreate = function() {};
    product_type.viewModel = novia.vueViewModel(formObject, initData, appMethods, computedValues, onCreate);
    if(product_type.selectedRecord.id!==undefined){
        product_type.viewModel.load(product_type.selectedRecord);
    }
};




function product_type_init(formObject) {
    novia.removeBootstrapSubmitButton();
    product_type.init(formObject);        
}
function product_type_before_save(formObject) {}
function product_type_after_reset (formObject) {
    product_type.viewModel.clear();
}
function product_type_after_close (formObject) {
    product_type.selectedRecord = {};
    novia.createMainContentGrid(product_type);
}
novia.createMainContentGrid(product_type);
