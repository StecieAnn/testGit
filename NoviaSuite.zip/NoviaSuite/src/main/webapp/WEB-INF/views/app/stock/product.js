var product = {};
product.controller = "Product";
product.hasGrid = true;
product.gridEnableSearch = true;
product.gridData="products";
product.gridTitle="Products";
product.gridColumns=
[
	 { field: 'displayName', caption: 'displayName', size: '30%', sortable: true },
	 { field: 'productCategory.description', caption: 'Product Category', size: '30%', sortable: true },
    { field: 'description', caption: 'Description', size: '30%', sortable: true }
];

product.canView = true;
product.canAdd = true;
product.canEdit = true;
product.canDelete = true;
product.formURL = "save";
product.deleteURL = "delete";
product.findOneURL = "findOne";
product.selectedRecord = {};

product.deleteCallBack = function(record,callback) {
    novia.deleteRecord(record,product.controller,product.deleteURL,function(data) {
        callback();
    });
};
//VIEW MODEL
product.viewModel = null;
 
product.init = function (formObject) {
    var initData = {isEnabled:1,productCategories:Array(),productBrands:Array(),productTypes:Array(),suppliers:Array()};
    var appMethods = {
        submitForm: function(event) {
            var submitData = this.json();
            network.axiosPost("./"+product.controller+"/"+product.formURL,submitData,function (response) {
                novia.showAlert(JSON.stringify(response));
            });
        }

    };
    var computedValues = {};
    var onCreate = function() {
    	var context = this;
    	 network.axiosGet("./Supplier/suppliers",{},function (response) {
    		 context.suppliers = response;
         });
    	 var context = this;
    	 network.axiosGet("./ProductBrand/productBrands",{},function (response) {
    		 context.productBrands = response;
         });
    	 var context = this;
    	 network.axiosGet("./ProductCategory/productCategories",{},function (response) {
    		 context.productCategories = response;
         });
    	 var context = this;
    	 network.axiosGet("./ProductType/productTypes",{},function (response) {
    		 context.productTypes = response;
         });
    	 
    };
    product.viewModel = novia.vueViewModel(formObject, initData, appMethods, computedValues, onCreate);
    if(product.selectedRecord.id!==undefined){
       setTimeout(() => {
    	   product.viewModel.load(product.selectedRecord);
	}, 400);
    }
    
    jQuery(".dateField").pickDate(function(dateVal,src) {
    	product.viewModel[src.prop("id")] = dateVal;
	});
    
    
};


function product_init(formObject) {
    novia.removeBootstrapSubmitButton();
    product.init(formObject);        
}
function product_before_save(formObject) {}
function product_after_reset (formObject) {
    product.viewModel.clear();
}
function product_after_close (formObject) {
    product.selectedRecord = {};
    novia.createMainContentGrid(product);
}
novia.createMainContentGrid(product);
