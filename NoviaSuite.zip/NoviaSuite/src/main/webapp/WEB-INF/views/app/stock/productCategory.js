	var product_category = {};
	product_category.controller = "ProductCategory";
	product_category.hasGrid = true;
	product_category.gridEnableSearch = true;
	product_category.gridData="productCategories";
	product_category.gridTitle="Product Categories";
	product_category.gridColumns=
	[
	 { field: 'description', caption: 'Description', size: '50%', sortable: true },
];

product_category.canView = true;
product_category.canAdd = true;
product_category.canEdit = true;
product_category.canDelete = true;
product_category.formURL = "save";
product_category.deleteURL = "delete";
product_category.findOneURL = "findOne";
product_category.selectedRecord = {};

product_category.deleteCallBack = function(record,callback) {
    //novia.showAlert(JSON.stringify(product_category.selectedRecord));
	
	novia.deleteRecord(record,product_category.controller,product_category.deleteURL,function(data) {
        callback();
    });
};
//VIEW MODEL
product_category.viewModel = null;
 
product_category.init = function (formObject) {
    var initData = {isEnabled:1};
    var appMethods = {
        submitForm: function(event) {
            var submitData = this.json();
            network.axiosPost("./"+product_category.controller+"/"+product_category.formURL,submitData,function (response) {
                novia.showAlert(JSON.stringify(response));
            });
        }
    };
    var computedValues = {};
    var onCreate = function() {};
    product_category.viewModel = novia.vueViewModel(formObject, initData, appMethods, computedValues, onCreate);
    if(product_category.selectedRecord.id!==undefined){
        product_category.viewModel.load(product_category.selectedRecord);
    }
};




function product_category_init(formObject) {
    novia.removeBootstrapSubmitButton();
    product_category.init(formObject);        
}
function product_category_before_save(formObject) {}
function product_category_after_reset (formObject) {
    product_category.viewModel.clear();
}
function product_category_after_close (formObject) {
    product_category.selectedRecord = {};
    novia.createMainContentGrid(product_category);
}
novia.createMainContentGrid(product_category);
