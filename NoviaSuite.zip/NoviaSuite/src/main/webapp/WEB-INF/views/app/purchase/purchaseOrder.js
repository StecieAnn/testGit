var purchase_order = {};
purchase_order.controller = "PurchaseOrder";
purchase_order.hasGrid = true;
purchase_order.gridEnableSearch = true;
purchase_order.gridData="purchaseOrders";
purchase_order.gridTitle="Purchase Orders";
purchase_order.gridColumns=
[
	{ field: 'orderNumber', caption: 'Order Number', size: '30%', sortable: true },
	{ field: 'description', caption: 'Description', size: '30%', sortable: true },
	{ field: 'quantity', caption: 'Quantity', size: '10%', sortable: true }
];

purchase_order.canView = true;
purchase_order.canAdd = true;
purchase_order.canEdit = true;
purchase_order.canDelete = true;

purchase_order.formURL = "save";
purchase_order.deleteURL = "delete";
purchase_order.findOneURL = "findOne";
purchase_order.selectedRecord = {};

purchase_order.deleteCallBack = function(record,callback) {
    novia.deleteRecord(record,purchase_order.controller,purchase_order.deleteURL,function(data) {
        callback();
    });
};
//VIEW MODEL
purchase_order.viewModel = null;
 
purchase_order.init = function (formObject) {
    var initData = {isEnabled:1,products:Array(),suppliers:Array()};
    var appMethods = {
        submitForm: function(event) {
            var submitData = this.json();
            network.axiosPost("./"+purchase_order.controller+"/"+purchase_order.formURL,submitData,function (response) {
                novia.showAlert(JSON.stringify(response));
            });
        }
    };
    var computedValues = {};
    var onCreate = function() {
    	var context=this;
    	network.axiosGet("./Product/products",{},function (response) {
    	context.products = response;	
    	});
    	var context = this;
   	 network.axiosGet("./Supplier/suppliers",{},function (response) {
   		 context.suppliers = response;
        });
    };
    purchase_order.viewModel = novia.vueViewModel(formObject, initData, appMethods, computedValues, onCreate);
    if(purchase_order.selectedRecord.id!==undefined){
       setTimeout(() => {
    	   purchase_order.viewModel.load(purchase_order.selectedRecord);
	}, 300);
    }
    jQuery(".dateField").pickDate(function(dateVal,src) {
    	purchase_order.viewModel[src.prop("id")] = dateVal;
	});
};

function purchase_order_init(formObject) {
    novia.removeBootstrapSubmitButton();
    purchase_order.init(formObject);        
}
function purchase_order_before_save(formObject) {}
function purchase_order_after_reset (formObject) {
    purchase_order.viewModel.clear();
}
function purchase_order_after_close (formObject) {
    purchase_order.selectedRecord = {};
    novia.createMainContentGrid(purchase_order);
}
novia.createMainContentGrid(purchase_order);
