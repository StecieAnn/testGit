var sale = {};
sale.controller = "Sale";
sale.hasGrid = true;
sale.gridEnableSearch = true;
sale.gridData="sales";
sale.gridTitle="Sales";
sale.gridColumns=
[
	{ field: 'product.displayName', caption: 'Product', size: '30%', sortable: true },
    { field: 'customer.customerName', caption: 'Customer', size: '30%', sortable: true },
    { field: 'quantity', caption: 'Quantity', size: '30%', sortable: true }
    //{ field: 'phoneNumber', caption: 'Phone Number', size: '10%', sortable: true }
];

sale.canView = true;
sale.canAdd = true;
sale.canEdit = true;
sale.canDelete = true;

sale.formURL = "save";
sale.deleteURL = "delete";
sale.findOneURL = "findOne";
sale.selectedRecord = {};

sale.deleteCallBack = function(record,callback) {
    novia.deleteRecord(record,sale.controller,sale.deleteURL,function(data) {
        callback();
    });
};
//VIEW MODEL
sale.viewModel = null;
 
sale.init = function (formObject) {
    var initData = {isEnabled:1,productCategories:Array(),products:Array(),statuses:Array(),customers:Array(),saleTaxes:Array()};
    var appMethods = {
        submitForm: function(event) {
            var submitData = this.json();
            network.axiosPost("./"+sale.controller+"/"+sale.formURL,submitData,function (response) {
                novia.showAlert(JSON.stringify(response));
            });
        }
    };
    var computedValues = {};
    var onCreate = function() {
   	 var context = this;
	 network.axiosGet("./ProductCategory/productCategories",{},function (response) {
		 context.productCategories = response;
     });
	 var context = this;
	 network.axiosGet("./Product/products",{},function (response) {
		 context.products = response;
     });
	 var context = this;
	 network.axiosGet("./Status/statuses",{},function (response) {
		 context.statuses = response;
     });
	 var context = this;
	 network.axiosGet("./Customer/customers",{},function (response) {
		 context.customers = response;
     });
	 var context = this;
	 network.axiosGet("./SaleTax/saleTaxes",{},function (response) {
		 context.saleTaxes = response;
     });
    };
    sale.viewModel = novia.vueViewModel(formObject, initData, appMethods, computedValues, onCreate);
    if(sale.selectedRecord.id!==undefined){
      setTimeout(() => {
    	  sale.viewModel.load(sale.selectedRecord);
	}, 300);
    }
    jQuery(".dateField").pickDate(function(dateVal,src) {
    	sale.viewModel[src.prop("id")] = dateVal;
	});
};




function sale_init(formObject) {
    novia.removeBootstrapSubmitButton();
    sale.init(formObject);        
}
function sale_before_save(formObject) {}
function sale_after_reset (formObject) {
    sale.viewModel.clear();
}
function sale_after_close (formObject) {
    sale.selectedRecord = {};
    novia.createMainContentGrid(sale);
}
novia.createMainContentGrid(sale);
