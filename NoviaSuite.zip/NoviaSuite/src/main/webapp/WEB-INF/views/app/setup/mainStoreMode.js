var main_store_mode = {};
main_store_mode.controller = "MainStoreMode";
main_store_mode.hasGrid = true;
main_store_mode.gridEnableSearch = true;
main_store_mode.gridData="mainStoreModes";
main_store_mode.gridTitle="Main Store Mode";
main_store_mode.gridColumns=
[
    { field: 'product.displayName', caption: 'Product', size: '30%', sortable: true },
    { field: 'quantity', caption: 'Quantity', size: '30%', sortable: true }
];

main_store_mode.canView = true;
main_store_mode.canAdd = true;
main_store_mode.canEdit = true;
main_store_mode.canDelete = true;

main_store_mode.formURL = "save";
main_store_mode.deleteURL = "delete";
main_store_mode.findOneURL = "findOne";
main_store_mode.selectedRecord = {};

main_store_mode.deleteCallBack = function(record,callback) {
    novia.deleteRecord(record,main_store_mode.controller,main_store_mode.deleteURL,function(data) {
        callback();
    });
};
//VIEW MODEL
main_store_mode.viewModel = null;
 
main_store_mode.init = function (formObject) {
    var initData = {isEnabled:1,products:Array()};
    var appMethods = {
        submitForm: function(event) {
            var submitData = this.json();
            network.axiosPost("./"+main_store_mode.controller+"/"+main_store_mode.formURL,submitData,function (response) {
                novia.showAlert(JSON.stringify(response));
            });
        }
    };
    var computedValues = {};
    var onCreate = function() {
   	 var context = this;
	   network.axiosGet("./Product/products",{},function (response) {
		   context.products=response;
   });
    };
    main_store_mode.viewModel = novia.vueViewModel(formObject, initData, appMethods, computedValues, onCreate);
    if(main_store_mode.selectedRecord.id!==undefined){
    	setTimeout(() => {
    		   main_store_mode.viewModel.load(main_store_mode.selectedRecord);	
		}, 300);
     
    }
};




function main_store_mode_init(formObject) {
    novia.removeBootstrapSubmitButton();
    main_store_mode.init(formObject);        
}
function main_store_mode_before_save(formObject) {}
function main_store_mode_after_reset (formObject) {
    main_store_mode.viewModel.clear();
}
function main_store_mode_after_close (formObject) {
    main_store_mode.selectedRecord = {};
    novia.createMainContentGrid(main_store_mode);
}
novia.createMainContentGrid(main_store_mode);
