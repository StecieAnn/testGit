var noviaforms = {};
noviaforms.readOnlyInputIfNotFocussed=function(formObject,elemname){
    formObject.find('input[name="'+elemname+'"]').focus(function() {
        jQuery(this).removeAttr('readonly');
    }).focusout(function() {
        jQuery(this).attr('readonly','readonly');
    });
};
/**
 * @sourceelemname = Element Whose Data To be Hashed using MD5
 * @destelemname = Readonly or Hidden Elem to store Hashed MD5 value of sourceelemname
 */
noviaforms.MD5encryptFormField=function(formObject,sourceelemname,destelemname){
    formObject.find('input[name="'+sourceelemname+'"]').keyup(function() {
        formObject.find('input[name="'+destelemname+'"]').val(md5(formObject.find('input[name="'+sourceelemname+'"]').val()));
    });
};
