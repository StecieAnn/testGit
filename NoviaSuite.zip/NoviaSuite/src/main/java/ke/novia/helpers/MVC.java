package ke.novia.helpers;
import java.io.InputStream;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
public class MVC {
    public static String getfile(HttpServletRequest request, String path,boolean isjs) {
        // We use FileUtils class from Apache Commons IO (commons.io) to read the content of a file. 
        // FileUtils have two static methods called
        // readFileToString(File file) and readFileToString(
        // File file, String encoding) that we can use.
        String content = "";
        ServletContext context = request.getServletContext();
        java.net.URL resourceUrl = null;
        String toload="";
        try {
            if(path!=null && path.length()>0){
            	String ext=(isjs)?".js":".html";
            	toload="/WEB-INF/views/"+path+ext;
            	System.out.println("File : " + toload);
            	resourceUrl = context.getResource(toload);
            	System.out.println(resourceUrl);
	            java.io.File file = new java.io.File(resourceUrl.toURI());
	            // Read the entire contents of sample.txt
	            content = FileUtils.readFileToString(file);
            }
            // For the sake of this example we show the file content here.
            //System.out.println("File content: " + jsonString);
        } catch (Exception e) {
        	try {
        		//content = FileUtils.readFileToString(new java.io.File(resourceUrl.toURI()));
        		//InputStream in = new FileInputStream(new java.io.File(resourceUrl.toURI())); 
        		InputStream resourceContent = context.getResourceAsStream(toload);
        		content = IOUtils.toString(resourceContent, "UTF-8");
        	}
        	catch (Exception e2) {
        		System.err.println("Exception : "+e2.getMessage());
        	}
        }
        return content;//"/js/test.html";
    }
    public static String objectToJSON(Object o){
    	String json = "{}";
    	try {
			json = new com.fasterxml.jackson.databind.ObjectMapper().writeValueAsString(o);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
		}
		return json;
    }
}