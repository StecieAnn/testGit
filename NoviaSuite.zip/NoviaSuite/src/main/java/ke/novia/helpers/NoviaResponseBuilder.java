package ke.novia.helpers;

import java.util.ArrayList;

import lombok.Getter;
import lombok.Setter;

@Setter @Getter
public class NoviaResponseBuilder {
	String status="error";
	String message="Unknown Error";
	String operation = "";
	Object data = null;
	//Valid operation = create/update/delete
	public NoviaResponseBuilder(String operation, String status,String displayValue,Object data){
		this.status = status;
		this.operation = operation;
		String msg = "";
		if(operation=="create"){
			if(status=="success"){
				msg = "Creating '"+displayValue+"' Successful";
			}
			else{
				msg = "Creation of item '"+displayValue+"' encountered an error!";
			}
		}
		else if(operation=="update"){
			if(status=="success"){
				msg = "Editing item '"+displayValue+"' successful";
			}
			else{
				msg = "Editing of item '"+displayValue+"' encountered an error!";
			}
		}
		else if(operation=="delete"){
			msg = status=="success"?"Item "+displayValue+" Deleted!":"Error Deleting "+displayValue;
		}
		else{
			msg = "Invalid/Erroneous Operation!";
		}
		message=msg;
		if(data==null){
			ArrayList<String> errors = new ArrayList<String>();
			errors.add(displayValue);
			this.data=errors;
		}
		else{
			this.data=data;
		}
	}
}

