package ke.novia.helpers;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.swing.JOptionPane;

public class Dates {
	  static void printDates(String startDate)
	  {
	    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	    Calendar c = Calendar.getInstance();
	    try
	    {
	      c.setTime(sdf.parse(startDate));
	    }
	    catch (Exception ex) {}
	    int maxDay = c.getActualMaximum(5);
	    for (int co = 0; co < maxDay; co++)
	    {
	      System.out.println(sdf.format(c.getTime()));
	      c.add(5, 1);
	    }
	  }
	  
	  public static String getNextMonthSameDate(String date)
	  {
	    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	    Calendar c = Calendar.getInstance();
	    try
	    {
	      c.setTime(sdf.parse(date));
	    }
	    catch (Exception ex)
	    {
	      JOptionPane.showMessageDialog(null, ex);
	    }
	    int numDays = c.getActualMaximum(5);
	    c.add(5, numDays);
	    return sdf.format(c.getTime());
	  }
	  
	  public static Date addMonthToDate(Date date,int months)
	  {
	      Calendar cal = Calendar.getInstance();
	      cal.setTime(date);
	      cal.add(Calendar.MONTH, months);
	      
	      //int numDays = cal.getActualMaximum(5);
	      //cal.add(5, numDays);
	      
	      System.err.println(cal.getTime());
	      return cal.getTime();
	  }
	  /*
		If you want get 3rd monday of month, then use set instead of add
		date.set(Calendar.DAY_OF_WEEK_IN_MONTH, 3);
	
		if you want add one month to current date, use
		date.add(Calendar.MONTH, 1); 
	   */
}
