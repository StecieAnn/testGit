package ke.novia.app.controller;
import java.io.File;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class NoviaController {
    final static Log logger = LogFactory.getLog(NoviaController.class);
    @RequestMapping({"","/"})
    public String index(HttpServletRequest request) {
    	String ret = ke.novia.helpers.MVC.getfile(request, "NoviaSimple", false);
    	ret+= "<script type='text/javascript'>"+ke.novia.helpers.MVC.getfile(request, "novia", true)+"</script>";
    	return ret+"<script type='text/javascript'>"+ke.novia.helpers.MVC.getfile(request, "app", true)+"</script>";
    }
    @RequestMapping({"/loadJS/{spath}"})
    public String loadJS(HttpServletRequest request, @PathVariable("spath") String spath) {
    	String path = spath.replace("$",File.separator);
    	String js = "<script type='text/javascript'>"+ke.novia.helpers.MVC.getfile(request, "app"+File.separatorChar+path, true)+"</script>";
    	//System.err.println(path+" - "+js);
    	return js;
    }
    
    @RequestMapping({"/loadHTML/{spath}"})
    public String loadHTML(HttpServletRequest request, @PathVariable("spath") String spath) {
    	String path = spath.replace("$",File.separator);
    	return ke.novia.helpers.MVC.getfile(request, "app"+File.separatorChar+path, false);
    }
}

