package ke.novia.stock.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import ke.novia.stock.dao.ProductBrandDao;
import ke.novia.stock.model.ProductBrandModel;

@Service
public class ProductBrandServiceImpl implements ProductBrandService {
	
	@Autowired
	ProductBrandDao productBrandDao;
	
	@Override
	public ProductBrandModel save(ProductBrandModel entity) {
		// TODO Auto-generated method stub
		if(entity.getId()==null || entity.getId()<1){
			entity.setId(ke.novia.helpers.UniqueID.get());
			List<ProductBrandModel> dups = productBrandDao.findBydescription(entity.getDescription());
			if(dups==null || dups.size()>0){
				return null;
			}
		}
	
		return productBrandDao.save(entity);
	}

	@Override
	public ProductBrandModel findById(Long id) {
		// TODO Auto-generated method stub
		return productBrandDao.findOne(id);
	}

	@Override
	public List<ProductBrandModel> findAll() {
		// TODO Auto-generated method stub
		return productBrandDao.findAll();
	}

	@Override
	public List<ProductBrandModel> search(String query) {
		// TODO Auto-generated method stub
		return productBrandDao.search(query,new PageRequest(0, 100));
	}

	@Override
	public boolean delete(Long id) {
		productBrandDao.delete(id);
		return productBrandDao.findOne(id)==null;
	}



}

