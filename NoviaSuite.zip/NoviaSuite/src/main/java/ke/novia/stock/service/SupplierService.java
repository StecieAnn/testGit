package ke.novia.stock.service;

import java.util.List;
import ke.novia.stock.model.SupplierModel;

public interface SupplierService {
	SupplierModel save(SupplierModel entity);
	SupplierModel findById(Long id);
	List<SupplierModel> findAll();
	List<SupplierModel> search(String query);
	boolean delete(Long id);
}

