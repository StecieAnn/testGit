package ke.novia.stock.dao;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import ke.novia.dao.BaseRepository;
import ke.novia.stock.model.ProductTypeModel;

@Repository
public interface ProductTypeDao extends BaseRepository<ProductTypeModel,Long> {
	
List<ProductTypeModel> findBydescription(String description);
@Query("SELECT s FROM ProductTypeModel s WHERE lower(s.description) LIKE :query% ORDER BY s.description DESC")
public List<ProductTypeModel> search(@Param("query") String query, Pageable pageable);
}
