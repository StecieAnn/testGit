package ke.novia.stock.controller;


import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import ke.novia.stock.model.ProductCategoryModel;
import ke.novia.stock.service.ProductCategoryService;



@RestController
@RequestMapping({"ProductCategory","/ProductCategory"})
public class ProductCategoryController {
	private final Logger logger = LoggerFactory.getLogger(ProductCategoryModel.class);
	@Autowired
	ProductCategoryService productCategoryService;
	
	@RequestMapping("/productCategories")
	public List<ProductCategoryModel> productCategories() {
		return productCategoryService.search("");
	}
	@RequestMapping("/productCategories/{searchterm}")
	public List<ProductCategoryModel> entitySearch(@PathVariable String searchterm) {
		return productCategoryService.search(searchterm);
	}
	@RequestMapping("/findOne/{id}")
	public ProductCategoryModel findOne(@PathVariable Long id) {
		return productCategoryService.findById(id);
	} 
	@RequestMapping("/delete")
	public boolean delete(@Valid @RequestBody ProductCategoryModel obj,Errors errors) {
		return productCategoryService.delete(obj.getId());
	}
	@RequestMapping(value = "/save", method = RequestMethod.POST)//Save
	public @ResponseBody Object saveOrUpdateProductCategory(@Valid @RequestBody ProductCategoryModel obj,Errors errors) {//Locale locale, Model model
		logger.error("saveOrUpdateProductCategory() : {}", obj);
		if (errors.hasErrors()) {
    		return errors;
    	}
    	else{
    		return productCategoryService.save(obj);
    	}
	}
}
