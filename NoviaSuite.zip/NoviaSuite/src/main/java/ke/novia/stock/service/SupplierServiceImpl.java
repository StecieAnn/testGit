package ke.novia.stock.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import ke.novia.stock.dao.SupplierDao;
import ke.novia.stock.model.SupplierModel;

@Service
public class SupplierServiceImpl implements SupplierService {
	@Autowired
	SupplierDao supplierDao;
	@Override
	public SupplierModel save(SupplierModel entity) {
		// TODO Auto-generated method stub
		if(entity.getId()==null || entity.getId()<1){
			entity.setId(ke.novia.helpers.UniqueID.get());
			List<SupplierModel> dups = supplierDao.findBysupplierName(entity.getSupplierName());
			if(dups==null || dups.size()>0){
				return null;
			}
		}
	
		return supplierDao.save(entity);
	}

	@Override
	public SupplierModel findById(Long id) {
		// TODO Auto-generated method stub
		return supplierDao.findOne(id);
	}

	@Override
	public List<SupplierModel> findAll() {
		// TODO Auto-generated method stub
		return supplierDao.findAll();
	}

	@Override
	public List<SupplierModel> search(String query) {
		// TODO Auto-generated method stub
		return supplierDao.search(query,new PageRequest(0, 100));
	}

	@Override
	public boolean delete(Long id) {
		supplierDao.delete(id);
		return supplierDao.findOne(id)==null;
	}



}

