package ke.novia.stock.service;



import java.util.List;
import ke.novia.stock.model.ProductTypeModel;



public interface ProductTypeService {
	ProductTypeModel save(ProductTypeModel entity);
	ProductTypeModel findById(Long id);
	List<ProductTypeModel> findAll();
	List<ProductTypeModel> search(String query);
	boolean delete(Long id);
}

