package ke.novia.stock.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@Entity
@Table(name="stock_suppliers")
@Data
public class SupplierModel {
	@Id
	private Long id;
	@Column(name="contact_person")
	private String contactPerson;
	@Column(name="supplier_name")
	private String supplierName;
	@Column(name="supplier_code")
	private String supplierCode;
	@Column(name="phone_number")
	private String phoneNumber;
	@Column(name="physical_location")
	private String physicalLocation;
	@Column(name="email")
	private String 	email;
	
}
