package ke.novia.stock.dao;
import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import ke.novia.dao.BaseRepository;
import ke.novia.stock.model.ProductCategoryModel;
import ke.novia.stock.model.ProductModel;

@Repository
public interface ProductDao extends BaseRepository<ProductModel, Long> {
	List<ProductModel> findBydisplayName(String displayName);
	
	List<ProductModel> findByProductCategory(ProductCategoryModel productCategoryModel);
	
	@Query("SELECT s FROM ProductModel s WHERE lower(s.displayName) LIKE :query% ORDER BY s.displayName DESC")
    public List<ProductModel> search(@Param("query") String query, Pageable pageable);
	
	
	@Modifying
	@Transactional
	@Query("UPDATE ProductModel s SET s.onHandQuantity=s.onHandQuantity+:quantity WHERE s.id = :productId")
    public void incrementStock(@Param("productId") long id,@Param("quantity") double quantity);
	
	@Modifying
	@Transactional
	@Query("UPDATE ProductModel s SET s.onHandQuantity=s.onHandQuantity-:quantity WHERE s.id= :productId")
	public void decrementStock (@Param("productId") long id,@Param("quantity") double quantity);
	
}

