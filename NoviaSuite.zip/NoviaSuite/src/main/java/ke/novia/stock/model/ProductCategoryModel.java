package ke.novia.stock.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;


@Entity
@Table(name="stock_item_categories")
@Data
public class ProductCategoryModel {
	@Id
	private Long id;
	@Column(name="description")
	private String description;
	
}
