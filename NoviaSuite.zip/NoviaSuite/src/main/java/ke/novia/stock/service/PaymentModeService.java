package ke.novia.stock.service;

import java.util.List;

import ke.novia.setup.model.PaymentModeModel;


public interface PaymentModeService {
	PaymentModeModel save(PaymentModeModel entity);
	PaymentModeModel findById(Long id);
	List<PaymentModeModel> findAll();
	List<PaymentModeModel> search(String query);
	boolean delete(Long id);
}

