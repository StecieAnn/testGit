package ke.novia.stock.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import ke.novia.stock.dao.ProductTypeDao;
import ke.novia.stock.model.ProductTypeModel;

@Service
public class ProductTypeServiceImpl implements ProductTypeService {
	@Autowired
	ProductTypeDao productTypeDao;
	@Override
	public ProductTypeModel save(ProductTypeModel entity) {
		// TODO Auto-generated method stub
		if(entity.getId()==null || entity.getId()<1){
			entity.setId(ke.novia.helpers.UniqueID.get());
			List<ProductTypeModel> dups = productTypeDao.findBydescription(entity.getDescription());
			if(dups==null || dups.size()>0){
				return null;
			}
		}
	
		return productTypeDao.save(entity);
	}

	@Override
	public ProductTypeModel findById(Long id) {
		// TODO Auto-generated method stub
		return productTypeDao.findOne(id);
	}

	@Override
	public List<ProductTypeModel> findAll() {
		// TODO Auto-generated method stub
		return productTypeDao.findAll();
	}

	@Override
	public List<ProductTypeModel> search(String query) {
		// TODO Auto-generated method stub
		return productTypeDao.search(query,new PageRequest(0, 100));
	}

	@Override
	public boolean delete(Long id) {
		productTypeDao.delete(id);
		return productTypeDao.findOne(id)==null;
	}



}

