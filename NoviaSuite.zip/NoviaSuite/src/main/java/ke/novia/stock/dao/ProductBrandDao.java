package ke.novia.stock.dao;
import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ke.novia.dao.BaseRepository;
import ke.novia.stock.model.ProductBrandModel;

@Repository
public interface ProductBrandDao extends BaseRepository<ProductBrandModel, Long> {
	List<ProductBrandModel> findBydescription(String description);
	@Query("SELECT s FROM ProductBrandModel s WHERE lower(s.description) LIKE :query% ORDER BY s.description DESC")
    public List<ProductBrandModel> search(@Param("query") String query, Pageable pageable);
}

