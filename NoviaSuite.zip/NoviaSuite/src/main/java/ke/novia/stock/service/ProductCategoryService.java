package ke.novia.stock.service;



import java.util.List;

import ke.novia.stock.model.ProductCategoryModel;


public interface ProductCategoryService {
	ProductCategoryModel save(ProductCategoryModel entity);
	ProductCategoryModel findById(Long id);
	List<ProductCategoryModel> findAll();
	List<ProductCategoryModel> search(String query);
	boolean delete(Long id);
}

