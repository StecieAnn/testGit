package ke.novia.stock.controller;


import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import ke.novia.stock.model.SupplierModel;
import ke.novia.stock.service.SupplierService;



@RestController
@RequestMapping({"Supplier","/Supplier"})
public class SupplierController {
	private final Logger logger = LoggerFactory.getLogger(SupplierModel.class);
	@Autowired
	SupplierService supplierService;
	
	@RequestMapping("/suppliers")//Grid Data no search term
	public List<SupplierModel> suppliers() {
		return supplierService.search("");
	}
	@RequestMapping("/suppliers/{searchterm}")//Grid Data via search term
	public List<SupplierModel> entitySearch(@PathVariable String searchterm) {
		return supplierService.search(searchterm);
	}
	@RequestMapping("/findOne/{id}")//Find by is
	public SupplierModel findOne(@PathVariable Long id) {
		return supplierService.findById(id);
	} 
	@RequestMapping("/delete/{id}")//Delete by id
	public boolean delete(@PathVariable Long id) {
		return supplierService.delete(id);//Change THis
	}
	@RequestMapping(value = "/save", method = RequestMethod.POST)//Save
	public @ResponseBody Object saveOrUpdateSupplier(@Valid @RequestBody SupplierModel obj,Errors errors) {//Locale locale, Model model
		logger.error("saveOrUpdateSupplier() : {}", obj);
		if (errors.hasErrors()) {
    		return errors;
    	}
    	else{
    		return supplierService.save(obj);
    	}
	}
}
