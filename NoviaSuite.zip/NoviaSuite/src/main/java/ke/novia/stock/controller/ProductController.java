package ke.novia.stock.controller;


import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import ke.novia.stock.model.ProductCategoryModel;
import ke.novia.stock.model.ProductModel;
import ke.novia.stock.service.ProductService;



@RestController
@RequestMapping({"Product","/Product"})
public class ProductController {
	private final Logger logger = LoggerFactory.getLogger(ProductModel.class);
	@Autowired
	ProductService productService;
	
	@RequestMapping("/products")
	public List<ProductModel> products() {
		return productService.search("");
	}
	@RequestMapping("/products/{searchterm}")
	public List<ProductModel> entitySearch(@PathVariable String searchterm) {
		return productService.search(searchterm);
	}
	
	@RequestMapping("/findByProductCategory")
	public List<ProductModel> findByProductCategory(@RequestBody ProductCategoryModel obj) {
		return productService.findByProductCategory(obj);
	}
	
	@RequestMapping("/findOne/{id}")
	public ProductModel findOne(@PathVariable Long id) {
		return productService.findById(id);
	} 
	@RequestMapping("/delete")
	public boolean delete(@Valid @RequestBody ProductModel obj,Errors errors) {
		return productService.delete(obj.getId());
	}
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public @ResponseBody Object saveOrUpdateProduct(@Valid @RequestBody ProductModel obj,Errors errors) {
		logger.error("saveOrUpdateProduct() : {}", obj);
		if (errors.hasErrors()) {
    		return errors;
    	}
    	else{
    		return productService.save(obj);
    	}
	}
}
