package ke.novia.stock.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import ke.novia.purchase.dao.PurchaseReceiptItemDao;
import ke.novia.purchase.dao.PurchaseReturnItemDao;
import ke.novia.purchase.model.PurchaseReceiptItemModel;
import ke.novia.purchase.model.PurchaseReturnItemModel;
import ke.novia.sale.dao.SaleDao;
import ke.novia.sale.dao.SaleReturnDao;
import ke.novia.sale.model.SaleModel;
import ke.novia.sale.model.SaleReturnModel;
import ke.novia.setup.dao.NonReturnableItemDao;
import ke.novia.setup.dao.StockTranferDao;
import ke.novia.setup.model.NonReturnableItemModel;
import ke.novia.setup.model.StockTransferModel;
import ke.novia.stock.dao.ProductDao;
import ke.novia.stock.model.ProductCategoryModel;
import ke.novia.stock.model.ProductModel;


@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	ProductDao productDao;
	
	@Autowired
	private PurchaseReceiptItemDao purchaseReceiptItemDao;
	
	@Autowired
	private PurchaseReturnItemDao purchaseReturnItemDao;
	
	@Autowired
	StockTranferDao stockTranferDao;
	
	@Autowired
	NonReturnableItemDao nonReturnableItemDao;
	
	@Autowired
	SaleDao saleDao;
	
	@Autowired
	SaleReturnDao saleReturnDao;

	@Override
	public ProductModel save(ProductModel entity) {
		
		if(entity.getId()==null || entity.getId()<1){
			entity.setId(ke.novia.helpers.UniqueID.get());
			List<ProductModel> dups = productDao.findBydisplayName(entity.getDisplayName());
			if(dups==null || dups.size()>0){
				return null;
			}
		}
	
		return productDao.save(entity);
	}
	@Override
	public ProductModel findById(Long id) {
		return productDao.findOne(id);
	}

	@Override
	public List<ProductModel> findAll() {
		return productDao.findAll();
	}

	@Override
	public List<ProductModel> search(String query) {
		return productDao.search(query,new PageRequest(0, 100));
	}

	@Override
	public boolean delete(Long id) {
		productDao.delete(id);
		return productDao.findOne(id)==null;
	}
	@Override
	public PurchaseReceiptItemModel findByquantity(Long id) {
		return purchaseReceiptItemDao.findOne(id);
	}
	@Override
	public PurchaseReturnItemModel findByQuantity(Long id) {
		return  purchaseReturnItemDao.findOne(id);
	}
	
	public List<ProductModel> findByProductCategory(ProductCategoryModel productCategoryModel){
		return  productDao.findByProductCategory(productCategoryModel);
	}
	@Override
	public StockTransferModel getByQuantity(Long id) {
		return stockTranferDao.findOne(id);
	}
	@Override
	public NonReturnableItemModel getByQntty(Long id) {
		return nonReturnableItemDao.findOne(id);
	}
	@Override
	public SaleModel getByquantity(Long id) {
		return saleDao.findOne(id);
	}
	@Override
	public SaleReturnModel getByqntty(Long id) {
		// TODO Auto-generated method stub
		return saleReturnDao.findOne(id);
	}

}

