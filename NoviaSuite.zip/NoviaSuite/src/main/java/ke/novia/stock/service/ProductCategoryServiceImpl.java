package ke.novia.stock.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import ke.novia.stock.dao.ProductCategoryDao;
import ke.novia.stock.model.ProductCategoryModel;

@Service
public class ProductCategoryServiceImpl implements ProductCategoryService {
	
	@Autowired
	ProductCategoryDao productCategoryDao;
	
	@Override
	public ProductCategoryModel save(ProductCategoryModel entity) {
		// TODO Auto-generated method stub
		if(entity.getId()==null || entity.getId()<1){
			entity.setId(ke.novia.helpers.UniqueID.get());
			List<ProductCategoryModel> dups = productCategoryDao.findBydescription(entity.getDescription());
			if(dups==null || dups.size()>0){
				return null;
			}
		}
	
		return productCategoryDao.save(entity);
	}

	@Override
	public ProductCategoryModel findById(Long id) {
		// TODO Auto-generated method stub
		return productCategoryDao.findOne(id);
	}

	@Override
	public List<ProductCategoryModel> findAll() {
		// TODO Auto-generated method stub
		return productCategoryDao.findAll();
	}

	@Override
	public List<ProductCategoryModel> search(String query) {
		// TODO Auto-generated method stub
		return productCategoryDao.search(query,new PageRequest(0, 100));
	}

	@Override
	public boolean delete(Long id) {
		productCategoryDao.delete(id);
		return productCategoryDao.findOne(id)==null;
	}

	public boolean delete(ProductCategoryModel entity) {
		long id = entity.getId();
		productCategoryDao.delete(id);
		return productCategoryDao.findOne(id)==null;
	}

}

