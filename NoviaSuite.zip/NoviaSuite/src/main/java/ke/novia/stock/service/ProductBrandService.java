package ke.novia.stock.service;

import java.util.List;
import ke.novia.stock.model.ProductBrandModel;

public interface ProductBrandService {
	ProductBrandModel save(ProductBrandModel entity);
	ProductBrandModel findById(Long id);
	List<ProductBrandModel> findAll();
	List<ProductBrandModel> search(String query);
	boolean delete(Long id);
}

