package ke.novia.stock.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="product_brands")
@Getter @Setter @ToString
public class ProductBrandModel {
	@Id
	private Long id;
	@Column(name="description")
	private String description;
	
}
