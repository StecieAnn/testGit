package ke.novia.stock.controller;


import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import ke.novia.stock.model.ProductTypeModel;
import ke.novia.stock.service.ProductTypeService;


@RestController
@RequestMapping({"ProductType", "/ProductType"})
public class ProductTypeController {
	private final Logger logger = LoggerFactory.getLogger(ProductTypeModel.class);
	@Autowired
	ProductTypeService productTypeService;
	
	@RequestMapping("/productTypes")
	public List<ProductTypeModel> productTypes() {
		return productTypeService.search("");
	}
	@RequestMapping("/productTypes/{searchterm}")
	public List<ProductTypeModel> entitySearch(@PathVariable String searchterm) {
		return productTypeService.search(searchterm);
	}
	@RequestMapping("/findOne/{id}")
	public ProductTypeModel findOne(@PathVariable Long id) {
		return productTypeService.findById(id);
	} 
	@RequestMapping("/delete/{id}")
	public boolean delete(@PathVariable Long id) {
		return productTypeService.delete(id);
	}
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public @ResponseBody Object saveOrUpdateProductType(@Valid @RequestBody ProductTypeModel obj,Errors errors) {
		logger.error("saveOrUpdateProductType() : {}", obj);
		if (errors.hasErrors()) {
    		return errors;
    	}
    	else{
    		return productTypeService.save(obj);
    	}
	
	}
}
