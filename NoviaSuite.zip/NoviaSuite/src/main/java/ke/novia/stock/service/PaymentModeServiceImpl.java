package ke.novia.stock.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import ke.novia.setup.dao.PaymentModeDao;
import ke.novia.setup.model.PaymentModeModel;


@Service
public class PaymentModeServiceImpl implements PaymentModeService {
	
	@Autowired
	PaymentModeDao paymentModeDao;
	
	@Override
	public PaymentModeModel save(PaymentModeModel entity) {
		// TODO Auto-generated method stub
		if(entity.getId()==null || entity.getId()<1){
			entity.setId(ke.novia.helpers.UniqueID.get());
			List<PaymentModeModel> dups = paymentModeDao.findBydescription(entity.getDescription());
			if(dups==null || dups.size()>0){
				return null;
			}
		}
	
		return paymentModeDao.save(entity);
	}

	@Override
	public PaymentModeModel findById(Long id) {
		// TODO Auto-generated method stub
		return paymentModeDao.findOne(id);
	}

	@Override
	public List<PaymentModeModel> findAll() {
		// TODO Auto-generated method stub
		return paymentModeDao.findAll();
	}

	@Override
	public List<PaymentModeModel> search(String query) {
		// TODO Auto-generated method stub
		return paymentModeDao.search(query,new PageRequest(0, 100));
	}

	@Override
	public boolean delete(Long id) {
		paymentModeDao.delete(id);
		return paymentModeDao.findOne(id)==null;
	}



}

