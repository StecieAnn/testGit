package ke.novia.stock.dao;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ke.novia.dao.BaseRepository;
import ke.novia.stock.model.ProductCategoryModel;


@Repository
public interface ProductCategoryDao extends BaseRepository<ProductCategoryModel,Long> {	
	List<ProductCategoryModel> findBydescription(String description);
	@Query("SELECT s FROM ProductCategoryModel s WHERE lower(s.description) LIKE :query% ORDER BY s.description DESC")
    public List<ProductCategoryModel> search(@Param("query") String query, Pageable pageable);
}


