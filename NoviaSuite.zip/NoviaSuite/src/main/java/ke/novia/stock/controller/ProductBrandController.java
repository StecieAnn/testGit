package ke.novia.stock.controller;


import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import ke.novia.stock.model.ProductBrandModel;
import ke.novia.stock.service.ProductBrandService;



@RestController
@RequestMapping({"ProductBrand","/ProductBrand"})
public class ProductBrandController {
	private final Logger logger = LoggerFactory.getLogger(ProductBrandModel.class);
	@Autowired
	ProductBrandService productBrandService;
	
	@RequestMapping("/productBrands")
	public List<ProductBrandModel> productBrands() {
		return productBrandService.search("");
	}
	@RequestMapping("/productBrands/{searchterm}")
	public List<ProductBrandModel> entitySearch(@PathVariable String searchterm) {
		return productBrandService.search(searchterm);
	}
	@RequestMapping("/findOne/{id}")
	public ProductBrandModel findOne(@PathVariable Long id) {
		return productBrandService.findById(id);
	} 
	@RequestMapping("/delete/{id}")
	public boolean delete(@PathVariable Long id) {
		return productBrandService.delete(id);
	}
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public @ResponseBody Object saveOrUpdateProductBrand(@Valid @RequestBody ProductBrandModel obj,Errors errors) {
		logger.error("saveOrUpdateProductBrand() : {}", obj);
		if (errors.hasErrors()) {
    		return errors;
    	}
    	else{
    		return productBrandService.save(obj);
    	}
	}
}
