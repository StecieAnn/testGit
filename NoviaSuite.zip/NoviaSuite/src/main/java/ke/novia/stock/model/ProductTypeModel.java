package ke.novia.stock.model;



import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;


@Entity
@Table(name="product_types")
@Data
public class ProductTypeModel {
	@Id
	private Long id;
	private String description;	
}
