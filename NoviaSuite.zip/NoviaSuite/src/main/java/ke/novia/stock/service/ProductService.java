package ke.novia.stock.service;

import java.util.List;
import ke.novia.purchase.model.PurchaseReceiptItemModel;
import ke.novia.purchase.model.PurchaseReturnItemModel;
import ke.novia.sale.model.SaleModel;
import ke.novia.sale.model.SaleReturnModel;
import ke.novia.setup.model.NonReturnableItemModel;
import ke.novia.setup.model.StockTransferModel;
import ke.novia.stock.model.ProductCategoryModel;
import ke.novia.stock.model.ProductModel;

public interface ProductService {
	ProductModel save(ProductModel entity);
	ProductModel findById(Long id);
	List<ProductModel> findAll();
	List<ProductModel> search(String query);
	boolean delete(Long id);
	PurchaseReceiptItemModel findByquantity(Long id);
	PurchaseReturnItemModel  findByQuantity(Long id);
	StockTransferModel  getByQuantity(Long id);
	NonReturnableItemModel  getByQntty(Long id);
	SaleModel  getByquantity(Long id);
	SaleReturnModel  getByqntty(Long id);
	List<ProductModel> findByProductCategory(ProductCategoryModel productCategoryModel);
}
