package ke.novia.purchase.controller;


import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import ke.novia.purchase.model.PurchaseReceiptItemModel;
import ke.novia.purchase.model.PurchaseReceiptModel;
import ke.novia.purchase.service.PurchaseReceiptItemService;




@RestController
@RequestMapping({"PurchaseReceiptItem","/PurchaseReceiptItem"})
public class PurchaseReceiptItemController {
	private final Logger logger = LoggerFactory.getLogger(PurchaseReceiptItemModel.class);
	@Autowired
	PurchaseReceiptItemService purchaseReceiptItemService;
	
	@RequestMapping("/purchaseReceiptItems")
	public List<PurchaseReceiptItemModel> purchaseReceiptItems() {
		return purchaseReceiptItemService.search("");
	}
	@RequestMapping("/purchaseReceiptItems/{searchterm}")
	public List<PurchaseReceiptItemModel> entitySearch(@PathVariable String searchterm) {
		return purchaseReceiptItemService.search(searchterm);
	}
	@RequestMapping("/findOne/{id}")
	public PurchaseReceiptItemModel findOne(@PathVariable Long id) {
		return purchaseReceiptItemService.findById(id);
	} 
	@RequestMapping("/delete/{id}")
	public boolean delete(@PathVariable Long id) {
		return purchaseReceiptItemService.delete(id);
	}
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public @ResponseBody Object saveOrUpdatePurchaseReceiptItem(@Valid @RequestBody PurchaseReceiptItemModel obj,Errors errors) {
		logger.error("saveOrUpdatePurchaseReceiptItem() : {}", obj);
		if (errors.hasErrors()) {
    		return errors;
    	}
    	else{
    		return purchaseReceiptItemService.save(obj);
    	}
	}
	@RequestMapping(value = "/findByPurchaseReceiptModel", method = RequestMethod.POST)
	public List<PurchaseReceiptItemModel> findByPurchaseReceiptModel(@RequestBody PurchaseReceiptModel purchaseReceiptModel){
		return purchaseReceiptItemService.findByPurchaseReceiptModel(purchaseReceiptModel);
	}
	
}
