package ke.novia.purchase.controller;


import java.util.List;

import javax.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import ke.novia.purchase.model.PurchaseReturnItemModel;
import ke.novia.purchase.model.PurchaseReturnModel;
import ke.novia.purchase.service.PurchaseReturnItemService;

@RestController
@RequestMapping({"PurchaseReturnItem","/PurchaseReturnItem"})
public class PurchaseReturnItemController {
	private final Logger logger = LoggerFactory.getLogger(PurchaseReturnItemModel.class);
	@Autowired
	PurchaseReturnItemService purchaseReturnItemService;
	
	@RequestMapping("/purchaseReturnItems")
	public List<PurchaseReturnItemModel> purchaseReturnItems() {
		return purchaseReturnItemService.search("");
	}
	@RequestMapping("/purchaseReturnItems/{searchterm}")
	public List<PurchaseReturnItemModel> entitySearch(@PathVariable String searchterm) {
		return purchaseReturnItemService.search(searchterm);
	}
	@RequestMapping("/findOne/{id}")
	public PurchaseReturnItemModel findOne(@PathVariable Long id) {
		return purchaseReturnItemService.findById(id);
	} 
	@RequestMapping("/delete/{id}")
	public boolean delete(@PathVariable Long id) {
		return purchaseReturnItemService.delete(id);
	}
	@RequestMapping(value = "/findByPurchaseReturnModel", method = RequestMethod.POST)
	public List<PurchaseReturnItemModel> findBypurchaseReturn(@RequestBody PurchaseReturnModel purchaseReturnModel){
		return purchaseReturnItemService.findBypurchaseReturn(purchaseReturnModel);
	}
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public @ResponseBody Object saveOrUpdatePurchaseReturnItem(@Valid @RequestBody PurchaseReturnItemModel obj,Errors errors) {
		logger.error("saveOrUpdatePurchaseReturnItem() : {}", obj);
		if (errors.hasErrors()) {
    		return errors;
    	}
    	else{
    		return purchaseReturnItemService.save(obj);
    	}
	}
}
