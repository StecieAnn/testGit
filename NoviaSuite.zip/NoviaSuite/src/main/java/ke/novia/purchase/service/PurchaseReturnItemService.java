package ke.novia.purchase.service;

import java.util.List;

import ke.novia.purchase.model.PurchaseReturnItemModel;
import ke.novia.purchase.model.PurchaseReturnModel;


public interface PurchaseReturnItemService {
	PurchaseReturnItemModel save(PurchaseReturnItemModel entity);
	PurchaseReturnItemModel findById(Long id);
	List<PurchaseReturnItemModel> findAll();
	boolean delete(Long id);
	List<PurchaseReturnItemModel> search(String string);
	List<PurchaseReturnItemModel> findBypurchaseReturn(PurchaseReturnModel purchaseReturnModel);
	
}

