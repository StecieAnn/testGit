package ke.novia.purchase.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import ke.novia.stock.model.ProductCategoryModel;
import ke.novia.stock.model.ProductModel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Entity
@Table(name="stock_purchase_return_items")
@Getter @Setter @ToString
public class PurchaseReturnItemModel {
	@Id
	private Long id;
	@ManyToOne
	@JoinColumn(name="purchase_return_id")
	PurchaseReturnModel purchaseReturn;
	@ManyToOne
	@JoinColumn(name="stock_item_category_id")
	ProductCategoryModel productCategory;
	@ManyToOne
	@JoinColumn(name="stock_item_id")
	ProductModel product;
	@Column(name="quantity")
	private double quantity;//purchaseUnits
	@Column(name="unit_price")
	private double unitPrice;
	
}