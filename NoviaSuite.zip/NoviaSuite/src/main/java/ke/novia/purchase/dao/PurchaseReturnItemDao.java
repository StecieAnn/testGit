package ke.novia.purchase.dao;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ke.novia.dao.BaseRepository;
import ke.novia.purchase.model.PurchaseReturnItemModel;
import ke.novia.purchase.model.PurchaseReturnModel;
import ke.novia.stock.model.ProductModel;


@Repository
public interface PurchaseReturnItemDao extends BaseRepository<PurchaseReturnItemModel,Long> {
	List<PurchaseReturnItemModel> findByproduct(ProductModel productModel);
	List<PurchaseReturnItemModel> findBypurchaseReturn(PurchaseReturnModel purchaseReturnModel);
	@Query("SELECT t FROM PurchaseReturnItemModel t where t.product.displayName =:product")	
    public List<PurchaseReturnItemModel> search(@Param("product") String purchaseReturnModel, Pageable pageable);
}


