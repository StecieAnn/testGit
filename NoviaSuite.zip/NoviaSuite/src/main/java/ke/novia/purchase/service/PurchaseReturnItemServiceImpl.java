package ke.novia.purchase.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import ke.novia.purchase.dao.PurchaseReturnItemDao;
import ke.novia.purchase.model.PurchaseReturnItemModel;
import ke.novia.purchase.model.PurchaseReturnModel;
import ke.novia.stock.dao.ProductDao;



@Service
public class PurchaseReturnItemServiceImpl implements PurchaseReturnItemService{
	@Autowired
	PurchaseReturnItemDao purchaseReturnItemDao;
	
	@Autowired
	ProductDao productDao;
	
	@Override
	public PurchaseReturnItemModel save(PurchaseReturnItemModel entity) {
		// TODO Auto-generated method stub
		if(entity.getId()==null || entity.getId()<1){
			entity.setId(ke.novia.helpers.UniqueID.get());
			List<PurchaseReturnItemModel> dups = purchaseReturnItemDao.findByproduct(entity.getProduct());
			PurchaseReturnItemModel purchaseReturnItemModel= purchaseReturnItemDao.save(entity);
			if(purchaseReturnItemModel!=null && purchaseReturnItemModel.getId()>0){
				productDao.decrementStock(purchaseReturnItemModel.getProduct().getId(),purchaseReturnItemModel.getQuantity());	
			}
			if(dups==null || dups.size()>0){
				return null;
			}
		}
	
		return purchaseReturnItemDao.save(entity);
	}

	@Override
	public PurchaseReturnItemModel findById(Long id) {
		// TODO Auto-generated method stub
		return purchaseReturnItemDao.findOne(id);
	}

	@Override
	public List<PurchaseReturnItemModel> findAll() {
		// TODO Auto-generated method stub
		return purchaseReturnItemDao.findAll();
	}

	@Override
	public List<PurchaseReturnItemModel> search(String string) {
		// TODO Auto-generated method stub
		return purchaseReturnItemDao.search(string,new PageRequest(0, 100));
	}
	@Override
	public boolean delete(Long id) {
		purchaseReturnItemDao.delete(id);
		return purchaseReturnItemDao.findOne(id)==null;
	}

	public List<PurchaseReturnItemModel> findBypurchaseReturn(PurchaseReturnModel purchaseReturnModel){
		return purchaseReturnItemDao.findBypurchaseReturn(purchaseReturnModel);
	}

}

