package ke.novia.purchase.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import ke.novia.purchase.dao.PurchaseOrderDao;
import ke.novia.purchase.model.PurchaseOrderModel;


@Service
public class PurchaseOrderServiceImpl implements PurchaseOrderService {
	
	@Autowired
	PurchaseOrderDao purchaseOrderDao;
	
	@Override
	public PurchaseOrderModel save(PurchaseOrderModel entity) {
		// TODO Auto-generated method stub
		if(entity.getId()==null || entity.getId()<1){
			entity.setId(ke.novia.helpers.UniqueID.get());
			List<PurchaseOrderModel> dups = purchaseOrderDao.findByorderNumber(entity.getOrderNumber());
			if(dups==null || dups.size()>0){
				return null;
			}
		}
	
		return purchaseOrderDao.save(entity);
	}

	@Override
	public PurchaseOrderModel findById(Long id) {
		// TODO Auto-generated method stub
		return purchaseOrderDao.findOne(id);
	}

	@Override
	public List<PurchaseOrderModel> findAll() {
		// TODO Auto-generated method stub
		return purchaseOrderDao.findAll();
	}

	@Override
	public List<PurchaseOrderModel> search(String query) {
		// TODO Auto-generated method stub
		return purchaseOrderDao.search(query,new PageRequest(0, 100));
	}

	@Override
	public boolean delete(Long id) {
		purchaseOrderDao.delete(id);
		return purchaseOrderDao.findOne(id)==null;
	}



}

