package ke.novia.purchase.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import ke.novia.purchase.dao.PurchaseReturnDao;
import ke.novia.purchase.model.PurchaseReturnModel;


@Service
public class PurchaseReturnServiceImpl implements PurchaseReturnService {
	
	@Autowired
	PurchaseReturnDao purchaseReturnDao;
	
	@Override
	public PurchaseReturnModel save(PurchaseReturnModel entity) {
		// TODO Auto-generated method stub
		if(entity.getId()==null || entity.getId()<1){
			entity.setId(ke.novia.helpers.UniqueID.get());
			List<PurchaseReturnModel> dups = purchaseReturnDao.findByreturnNumber(entity.getReturnNumber());
			if(dups==null || dups.size()>0){
				return null;
			}
		}
	
		return purchaseReturnDao.save(entity);
	}

	@Override
	public PurchaseReturnModel findById(Long id) {
		// TODO Auto-generated method stub
		return purchaseReturnDao.findOne(id);
	}

	@Override
	public List<PurchaseReturnModel> findAll() {
		// TODO Auto-generated method stub
		return purchaseReturnDao.findAll();
	}

	@Override
	public List<PurchaseReturnModel> search(String query) {
		// TODO Auto-generated method stub
		return purchaseReturnDao.search(query,new PageRequest(0, 100));
	}

	@Override
	public boolean delete(Long id) {
		purchaseReturnDao.delete(id);
		return purchaseReturnDao.findOne(id)==null;
	}



}

