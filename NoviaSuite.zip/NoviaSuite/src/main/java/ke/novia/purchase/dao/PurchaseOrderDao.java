package ke.novia.purchase.dao;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ke.novia.dao.BaseRepository;
import ke.novia.purchase.model.PurchaseOrderModel;


@Repository
public interface PurchaseOrderDao extends BaseRepository<PurchaseOrderModel,Long> {
	
List<PurchaseOrderModel> findByorderNumber(String orderNumber);
@Query("SELECT s FROM PurchaseOrderModel s WHERE lower(s.orderNumber) LIKE :query% ORDER BY s.orderNumber DESC")
public List<PurchaseOrderModel> search(@Param("query") String query, Pageable pageable);
}
