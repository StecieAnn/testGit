package ke.novia.purchase.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import ke.novia.stock.model.ProductModel;
import ke.novia.stock.model.SupplierModel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "stock_purchase_orders")
@Getter @Setter @ToString
public class PurchaseOrderModel {
	@Id
	private Long id;
	@ManyToOne
	@JoinColumn(name = "stock_item_id")
	ProductModel product;
	@ManyToOne
	@JoinColumn(name = "stock_supplier_id")
	SupplierModel supplier;
	@Column(name = "order_by")
	private String orderBy;
	@Column(name = "order_number")
	private String orderNumber;
	@Column(name = "date_of_order")
	private String dateOfOrder;
	@Column(name = "description")
	private String description;
	@Column(name = "quantity")
	private double quantity;
	@Column(name = "unit_price")
	private String unitPrice;
	


}
