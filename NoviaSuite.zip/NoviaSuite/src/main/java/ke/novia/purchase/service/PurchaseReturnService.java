package ke.novia.purchase.service;

import java.util.List;

import ke.novia.purchase.model.PurchaseReturnModel;

public interface PurchaseReturnService {
	PurchaseReturnModel save(PurchaseReturnModel entity);
	PurchaseReturnModel findById(Long id);
	List<PurchaseReturnModel> findAll();
	List<PurchaseReturnModel> search(String query);
	boolean delete(Long id);
}

