package ke.novia.purchase.dao;

import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ke.novia.dao.BaseRepository;
import ke.novia.purchase.model.PurchaseReceiptModel;


@Repository
public interface PurchaseReceiptDao extends BaseRepository<PurchaseReceiptModel,Long> {
	
	List<PurchaseReceiptModel> findBydeliveryNoteNo(String deliveryNoteNo);
	@Query("SELECT s FROM PurchaseReceiptModel s WHERE lower(s.deliveryNoteNo) LIKE :query% ORDER BY s.deliveryNoteNo DESC")
	public List<PurchaseReceiptModel> search(@Param("query") String query, Pageable pageable);
	}
