package ke.novia.purchase.controller;


import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import ke.novia.purchase.model.PurchaseReturnModel;
import ke.novia.purchase.service.PurchaseReturnService;




@RestController
@RequestMapping({"PurchaseReturn","/PurchaseReturn"})
public class PurchaseReturnController {
	private final Logger logger = LoggerFactory.getLogger(PurchaseReturnModel.class);
	@Autowired
	PurchaseReturnService purchaseReturnService;
	
	@RequestMapping("/purchaseReturns")
	public List<PurchaseReturnModel> purchaseReturns() {
		return purchaseReturnService.search("");
	}
	@RequestMapping("/purchaseReturns/{searchterm}")
	public List<PurchaseReturnModel> entitySearch(@PathVariable String searchterm) {
		return purchaseReturnService.search(searchterm);
	}
	@RequestMapping("/findOne/{id}")
	public PurchaseReturnModel findOne(@PathVariable Long id) {
		return purchaseReturnService.findById(id);
	} 
	@RequestMapping("/delete/{id}")
	public boolean delete(@PathVariable Long id) {
		return purchaseReturnService.delete(id);
	}
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public @ResponseBody Object saveOrUpdatePurchaseReturn(@Valid @RequestBody PurchaseReturnModel obj,Errors errors) {
		logger.error("saveOrUpdatePurchaseReturn() : {}", obj);
		if (errors.hasErrors()) {
    		return errors;
    	}
    	else{
    		return purchaseReturnService.save(obj);
    	}
	}

}
