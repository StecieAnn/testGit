package ke.novia.purchase.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import ke.novia.purchase.dao.PurchaseReceiptItemDao;
import ke.novia.purchase.model.PurchaseReceiptItemModel;
import ke.novia.purchase.model.PurchaseReceiptModel;
import ke.novia.stock.dao.ProductDao;



@Service
public class PurchaseReceiptItemServiceImpl implements PurchaseReceiptItemService {
	@Autowired
	PurchaseReceiptItemDao purchaseReceiptItemDao;
	
	@Autowired
	ProductDao productDao;

	
	@Override
	public PurchaseReceiptItemModel save(PurchaseReceiptItemModel entity) {
		// TODO Auto-generated method stub
		if(entity.getId()==null || entity.getId()<1){
			entity.setId(ke.novia.helpers.UniqueID.get());			
			List<PurchaseReceiptItemModel> dups = purchaseReceiptItemDao.findByproduct(entity.getProduct());
			PurchaseReceiptItemModel purchaseReceiptItemModel=purchaseReceiptItemDao.save(entity);
			if(purchaseReceiptItemModel!= null && purchaseReceiptItemModel.getId()>0){
				//increment stock
				productDao.incrementStock(purchaseReceiptItemModel.getProduct().getId(), purchaseReceiptItemModel.getQuantity());
				
			}
			if(dups==null || dups.size()>0){
				return null;
			}
			return purchaseReceiptItemModel ;
		}
		return purchaseReceiptItemDao.save(entity);
	}

	@Override
	public PurchaseReceiptItemModel findById(Long id) {
		// TODO Auto-generated method stub
		return purchaseReceiptItemDao.findOne(id);
	}

	@Override
	public List<PurchaseReceiptItemModel> findAll() {
		// TODO Auto-generated method stub
		return purchaseReceiptItemDao.findAll();
	}

	@Override
	public List<PurchaseReceiptItemModel> search(String string) {
		// TODO Auto-generated method stub
		return purchaseReceiptItemDao.search(string,new PageRequest(0, 100));
	}
	@Override
	public boolean delete(Long id) {
		purchaseReceiptItemDao.delete(id);
		return purchaseReceiptItemDao.findOne(id)==null;
	}

	public List<PurchaseReceiptItemModel> findByPurchaseReceiptModel(PurchaseReceiptModel purchaseReceiptModel){
		return purchaseReceiptItemDao.findByPurchaseReceipt(purchaseReceiptModel);
	}

}

