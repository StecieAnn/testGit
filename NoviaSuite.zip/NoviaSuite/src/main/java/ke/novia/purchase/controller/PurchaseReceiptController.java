package ke.novia.purchase.controller;


import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import ke.novia.purchase.model.PurchaseReceiptModel;
import ke.novia.purchase.service.PurchaseReceiptService;




@RestController
@RequestMapping({"PurchaseReceipt","/PurchaseReceipt"})
public class PurchaseReceiptController {
	private final Logger logger = LoggerFactory.getLogger(PurchaseReceiptModel.class);
	@Autowired
	PurchaseReceiptService purchaseReceiptService;
	
	@RequestMapping("/purchaseReceipts")
	public List<PurchaseReceiptModel> purchaseReceipts() {
		return purchaseReceiptService.search("");
	}
	@RequestMapping("/purchaseReceipts/{searchterm}")
	public List<PurchaseReceiptModel> entitySearch(@PathVariable String searchterm) {
		return purchaseReceiptService.search(searchterm);
	}
	@RequestMapping("/findOne/{id}")
	public PurchaseReceiptModel findOne(@PathVariable Long id) {
		return purchaseReceiptService.findById(id);
	} 
	@RequestMapping("/delete/{id}")
	public boolean delete(@PathVariable Long id) {
		return purchaseReceiptService.delete(id);
	}
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public @ResponseBody Object saveOrUpdatePurchaseReceipt(@Valid @RequestBody PurchaseReceiptModel obj,Errors errors) {
		logger.error("saveOrUpdatePurchaseReceipt() : {}", obj);
		if (errors.hasErrors()) {
    		return errors;
    	}
    	else{
    		return purchaseReceiptService.save(obj);
    	}
	}
}
