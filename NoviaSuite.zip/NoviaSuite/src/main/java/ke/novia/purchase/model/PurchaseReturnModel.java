package ke.novia.purchase.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import ke.novia.stock.model.ProductCategoryModel;
import ke.novia.stock.model.ProductModel;
import ke.novia.stock.model.SupplierModel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Entity
@Table(name="stock_purchase_returns")
@Getter @Setter @ToString
public class PurchaseReturnModel {
	@Id
	private Long id;
	@ManyToOne
	@JoinColumn(name="stock_supplier_id")
    SupplierModel supplier;
	@ManyToOne
	@JoinColumn(name="purchase_receipt_id")
	PurchaseReceiptModel purchaseReceipt;
	@ManyToOne
	@JoinColumn(name="stock_item_category_id")
	ProductCategoryModel productCategory;
	@ManyToOne
	@JoinColumn(name="stock_item_id")
	ProductModel product;
	@Column(name="returning_date")
	private String returningDate;
	@Column(name="return_number")
	private String returnNumber;
	@Column(name="comment")
	private String comment;

}