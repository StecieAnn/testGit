package ke.novia.purchase.service;

import java.util.List;

import ke.novia.purchase.model.PurchaseOrderModel;

public interface PurchaseOrderService {
	PurchaseOrderModel save(PurchaseOrderModel entity);
	PurchaseOrderModel findById(Long id);
	List<PurchaseOrderModel> findAll();
	List<PurchaseOrderModel> search(String query);
	boolean delete(Long id);
}

