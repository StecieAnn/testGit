package ke.novia.purchase.service;

import java.util.List;

import ke.novia.purchase.model.PurchaseReceiptModel;

public interface PurchaseReceiptService {
	PurchaseReceiptModel save(PurchaseReceiptModel entity);
	PurchaseReceiptModel findById(Long id);
	List<PurchaseReceiptModel> findAll();
	List<PurchaseReceiptModel> search(String query);
	boolean delete(Long id);
}
