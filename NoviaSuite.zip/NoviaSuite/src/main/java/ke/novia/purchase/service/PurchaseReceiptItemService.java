package ke.novia.purchase.service;

import java.util.List;

import ke.novia.purchase.model.PurchaseReceiptItemModel;
import ke.novia.purchase.model.PurchaseReceiptModel;



public interface PurchaseReceiptItemService {
	PurchaseReceiptItemModel save(PurchaseReceiptItemModel entity);
	PurchaseReceiptItemModel findById(Long id);
	List<PurchaseReceiptItemModel> findAll();
	boolean delete(Long id);
	List<PurchaseReceiptItemModel> search(String string);
	List<PurchaseReceiptItemModel> findByPurchaseReceiptModel(PurchaseReceiptModel purchaseReceiptModel);
}

