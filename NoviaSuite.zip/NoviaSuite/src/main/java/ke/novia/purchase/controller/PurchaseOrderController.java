package ke.novia.purchase.controller;


import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import ke.novia.purchase.model.PurchaseOrderModel;
import ke.novia.purchase.service.PurchaseOrderService;




@RestController
@RequestMapping({"PurchaseOrder","/PurchaseOrder"})
public class PurchaseOrderController {
	private final Logger logger = LoggerFactory.getLogger(PurchaseOrderModel.class);
	@Autowired
	PurchaseOrderService purchaseOrderService;
	
	@RequestMapping("/purchaseOrders")
	public List<PurchaseOrderModel> purchaseOrders() {
		return purchaseOrderService.search("");
	}
	@RequestMapping("/purchaseOrders/{searchterm}")
	public List<PurchaseOrderModel> entitySearch(@PathVariable String searchterm) {
		return purchaseOrderService.search(searchterm);
	}
	@RequestMapping("/findOne/{id}")
	public PurchaseOrderModel findOne(@PathVariable Long id) {
		return purchaseOrderService.findById(id);
	} 
	@RequestMapping("/delete/{id}")
	public boolean delete(@PathVariable Long id) {
		return purchaseOrderService.delete(id);
	}
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public @ResponseBody Object saveOrUpdatePurchaseOrder(@Valid @RequestBody PurchaseOrderModel obj,Errors errors) {
		logger.error("saveOrUpdatePurchaseOrder() : {}", obj);
		if (errors.hasErrors()) {
    		return errors;
    	}
    	else{
    		return purchaseOrderService.save(obj);
    	}
	}
}
