package ke.novia.purchase.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import ke.novia.purchase.dao.PurchaseReceiptDao;
import ke.novia.purchase.model.PurchaseReceiptModel;


@Service
public class PurchaseReceiptServiceImpl implements PurchaseReceiptService {
	
	@Autowired
	PurchaseReceiptDao purchaseReceiptDao;
	
	@Override
	public PurchaseReceiptModel save(PurchaseReceiptModel entity) {
		// TODO Auto-generated method stub
		if(entity.getId()==null || entity.getId()<1){
			entity.setId(ke.novia.helpers.UniqueID.get());
			List<PurchaseReceiptModel> dups = purchaseReceiptDao.findBydeliveryNoteNo(entity.getDeliveryNoteNo());
			if(dups==null || dups.size()>0){
				return null;
			}
		}
	
		return purchaseReceiptDao.save(entity);
	}

	@Override
	public PurchaseReceiptModel findById(Long id) {
		// TODO Auto-generated method stub
		return purchaseReceiptDao.findOne(id);
	}

	@Override
	public List<PurchaseReceiptModel> findAll() {
		// TODO Auto-generated method stub
		return purchaseReceiptDao.findAll();
	}

	@Override
	public List<PurchaseReceiptModel> search(String query) {
		// TODO Auto-generated method stub
		return purchaseReceiptDao.search(query,new PageRequest(0, 100));
	}

	@Override
	public boolean delete(Long id) {
		purchaseReceiptDao.delete(id);
		return purchaseReceiptDao.findOne(id)==null;
	}



}

