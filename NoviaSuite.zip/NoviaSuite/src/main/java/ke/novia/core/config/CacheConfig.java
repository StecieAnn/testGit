package ke.novia.core.config;

import org.springframework.context.annotation.ComponentScan;

/*
import org.springframework.cache.CacheManager;
import org.springframework.cache.ehcache.EhCacheCacheManager;
import org.springframework.cache.ehcache.EhCacheManagerFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.ClassPathResource;
*/
//@Configuration
//@EnableCaching
@ComponentScan(basePackages = {
		"ke.novia.sacco.controller",
		/*
		"org.apache.fineract.accounting.*",
	      "org.apache.fineract.commands.provider.*",
	      "org.apache.fineract.commands.handler.*",
		  "org.apache.fineract.commands.service.*",
		  "org.apache.fineract.commands.*",
		  "org.apache.fineract.audit.*",
		  "org.apache.fineract.infrastructure.*",
		  "org.apache.fineract.scheduledjobs.*",
		  "org.apache.fineract.organisation.*",
		  "org.apache.fineract.portfolio.loanaccount.*",
		  "org.apache.fineract.portfolio.savingsaccount.*",
		  "org.apache.fineract.portfolio.*",
		  "org.apache.fineract.useradministration.*",
		  "org.apache.fineract.mix.*",
		  "org.apache.fineract.template.*",
		  "org.apache.fineract.template.service.*",
		  "org.apache.fineract.useradministration.*",
		  "org.apache.fineract.batch"	
		  */
		  
})
public class CacheConfig {
	/*
	public CacheConfig(){
		System.err.println("CacheConfig");
	}
	@Bean
	public CacheManager cacheManager() {
		return new EhCacheCacheManager(ehCacheCacheManager().getObject());
	}

	@Bean
	public EhCacheManagerFactoryBean ehCacheCacheManager() {
		EhCacheManagerFactoryBean cmfb = new EhCacheManagerFactoryBean();
		cmfb.setConfigLocation(new ClassPathResource("ehcache.xml"));
		cmfb.setShared(true);
		return cmfb;
	}
	*/
}
