package ke.novia.sale.controller;


import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import ke.novia.sale.model.CustomerModel;
import ke.novia.sale.service.CustomerService;





@RestController
@RequestMapping({"Customer","/Customer"})
public class CustomerController {
	private final Logger logger = LoggerFactory.getLogger(CustomerModel.class);
	@Autowired
	CustomerService customerService;
	
	@RequestMapping("/customers")
	public List<CustomerModel> customers() {
		return customerService.search("");
	}
	@RequestMapping("/customers/{searchterm}")
	public List<CustomerModel> entitySearch(@PathVariable String searchterm) {
		return customerService.search(searchterm);
	}
	@RequestMapping("/findOne/{id}")
	public CustomerModel findOne(@PathVariable Long id) {
		return customerService.findById(id);
	} 
	@RequestMapping("/delete/{id}")
	public boolean delete(@PathVariable Long id) {
		return customerService.delete(id);
	}
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public @ResponseBody Object saveOrUpdateCustomer(@Valid @RequestBody CustomerModel obj,Errors errors) {
		logger.error("saveOrUpdateCustomer() : {}", obj);
		if (errors.hasErrors()) {
    		return errors;
    	}
    	else{
    		return customerService.save(obj);
    	}
	}
}
