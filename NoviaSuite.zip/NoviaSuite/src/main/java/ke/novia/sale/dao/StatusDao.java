package ke.novia.sale.dao;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import ke.novia.dao.BaseRepository;
import ke.novia.sale.model.StatusModel;


@Repository
public interface StatusDao extends BaseRepository<StatusModel,Long> {
	
List<StatusModel> findBydescription(String description);
@Query("SELECT s FROM StatusModel s WHERE lower(s.description) LIKE :query% ORDER BY s.description DESC")
public List<StatusModel> search(@Param("query") String query, Pageable pageable);
}
