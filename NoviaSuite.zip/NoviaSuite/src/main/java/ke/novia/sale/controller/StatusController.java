package ke.novia.sale.controller;


import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import ke.novia.sale.model.StatusModel;
import ke.novia.sale.service.StatusService;





@RestController
@RequestMapping({"Status","/Status"})
public class StatusController {
	private final Logger logger = LoggerFactory.getLogger(StatusModel.class);
	@Autowired
	StatusService statusService;
	
	@RequestMapping("/statuses")
	public List<StatusModel> statuses() {
		return statusService.search("");
	}
	@RequestMapping("/statuses/{searchterm}")
	public List<StatusModel> entitySearch(@PathVariable String searchterm) {
		return statusService.search(searchterm);
	}
	@RequestMapping("/findOne/{id}")
	public StatusModel findOne(@PathVariable Long id) {
		return statusService.findById(id);
	} 
	@RequestMapping("/delete/{id}")
	public boolean delete(@PathVariable Long id) {
		return statusService.delete(id);
	}
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public @ResponseBody Object saveOrUpdateStatus(@Valid @RequestBody StatusModel obj,Errors errors) {
		logger.error("saveOrUpdateStatus() : {}", obj);
		if (errors.hasErrors()) {
    		return errors;
    	}
    	else{
    		return statusService.save(obj);
    	}
	}
}
