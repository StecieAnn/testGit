package ke.novia.sale.controller;


import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import ke.novia.sale.model.SaleModel;
import ke.novia.sale.service.SaleService;





@RestController
@RequestMapping({"Sale","/Sale"})
public class SaleController {
	private final Logger logger = LoggerFactory.getLogger(SaleModel.class);
	@Autowired
	SaleService saleService;
	
	@RequestMapping("/sales")//Grid Data no search term
	public List<SaleModel> sales() {
		return saleService.search("");
	}
	@RequestMapping("/sales/{searchterm}")//Grid Data via search term
	public List<SaleModel> entitySearch(@PathVariable String searchterm) {
		return saleService.search(searchterm);
	}
	@RequestMapping("/findOne/{id}")//Find by is
	public SaleModel findOne(@PathVariable Long id) {
		return saleService.findById(id);
	} 
	@RequestMapping("/delete/{id}")//Delete by id
	public boolean delete(@PathVariable Long id) {
		return saleService.delete(id);//Change THis
	}
	@RequestMapping(value = "/save", method = RequestMethod.POST)//Save
	public @ResponseBody Object saveOrUpdateSale(@Valid @RequestBody SaleModel obj,Errors errors) {//Locale locale, Model model
		logger.error("saveOrUpdateSale() : {}", obj);
		if (errors.hasErrors()) {
    		return errors;
    	}
    	else{
    		return saleService.save(obj);
    	}
	}
}
