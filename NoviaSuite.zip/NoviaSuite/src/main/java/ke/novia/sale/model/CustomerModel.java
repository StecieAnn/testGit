package ke.novia.sale.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
@Entity
@Table(name="customers")
@Getter @Setter @ToString
public class CustomerModel {
	@Id
	private Long id;
	@Column(name="customer_name")
	private String customerName;
	@Column(name="contact_name")
	private String contactName;
	@Column(name="customer_code")
	private String customerCode;
	@Column(name="phone_number")
	private String phoneNumber;
	@Column(name="description")
	private String description;
	@Column(name="email")
	private String 	email;
	@Column(name="physical_location")
	private String physicalLocation;
	@Column(name="postal_code")
	private String 	postalCode;
	@Column(name="address")
	private String 	address;

	
}