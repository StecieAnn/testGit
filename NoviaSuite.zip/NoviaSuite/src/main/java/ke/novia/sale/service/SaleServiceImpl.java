package ke.novia.sale.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import ke.novia.sale.dao.SaleDao;
import ke.novia.sale.model.SaleModel;
import ke.novia.stock.dao.ProductDao;
import ke.novia.stock.model.ProductModel;


@Service
public class SaleServiceImpl implements SaleService {

		@Autowired
		SaleDao saleDao;
		
		@Autowired
		ProductDao productDao;
		
		@Override
		public SaleModel save(SaleModel entity) {
				if(entity.getId()==null || entity.getId()<1){
					entity.setId(ke.novia.helpers.UniqueID.get());
				List<SaleModel> dups = saleDao.findByproduct(entity.getProduct());
				SaleModel saleModel=saleDao.save(entity);
				if(saleModel!= null && saleModel.getId()>0){
					productDao.decrementStock(saleModel.getProduct().getId(), saleModel.getQuantity());
				}
				if(dups==null || dups.size()>0){
					return null;
				}
				return saleModel;
			}
					
			return saleDao.save(entity);
		}
		
		@Override
		public SaleModel findById(Long id) {
			return saleDao.findOne(id);
		}

		@Override
		public List<SaleModel> findAll() {

			return saleDao.findAll();
		}
		@Override
		public boolean delete(Long id) {
			saleDao.delete(id);
			return saleDao.findOne(id)==null;
		}

		@Override
		public List<SaleModel> search(String string) {
			return saleDao.search(string,new PageRequest(0, 100));
		}
		
		public ProductModel getByDiscount(Long id){
			return productDao.findOne(id);	
		}


	}

