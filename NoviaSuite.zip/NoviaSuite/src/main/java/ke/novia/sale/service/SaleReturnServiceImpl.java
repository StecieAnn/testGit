package ke.novia.sale.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import ke.novia.sale.dao.SaleReturnDao;
import ke.novia.sale.model.SaleReturnModel;
import ke.novia.stock.dao.ProductDao;



@Service
public class SaleReturnServiceImpl implements SaleReturnService {
	
	@Autowired
	SaleReturnDao saleReturnDao;

	@Autowired
	ProductDao productDao;

	@Override
	public SaleReturnModel save(SaleReturnModel entity) {
		// TODO Auto-generated method stub
		if(entity.getId()==null || entity.getId()<1){
			entity.setId(ke.novia.helpers.UniqueID.get());
			List<SaleReturnModel> dups = saleReturnDao.findByproduct(entity.getProduct());
			SaleReturnModel saleReturnModel=saleReturnDao.save(entity);
			if(saleReturnModel!= null && saleReturnModel.getId()>0){
				productDao.incrementStock(saleReturnModel.getProduct().getId(), saleReturnModel.getQuantity());
			}
			if(dups==null || dups.size()>0){
				return null;
			}
			return saleReturnModel;
		}
		return saleReturnDao.save(entity);
	}

	@Override
	public SaleReturnModel findById(Long id) {
		return saleReturnDao.findOne(id);
	}

	@Override
	public List<SaleReturnModel> findAll() {
		return saleReturnDao.findAll();
	}

	@Override
	public List<SaleReturnModel> search(String string) {
		return saleReturnDao.search(string,new PageRequest(0, 100));
	}
	@Override
	public boolean delete(Long id) {
		saleReturnDao.delete(id);
		return saleReturnDao.findOne(id)==null;
	}



}

