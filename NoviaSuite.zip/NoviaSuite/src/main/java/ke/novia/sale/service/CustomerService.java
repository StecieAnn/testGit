package ke.novia.sale.service;

import java.util.List;

import ke.novia.sale.model.CustomerModel;


public interface CustomerService {
	CustomerModel save(CustomerModel entity);
	CustomerModel findById(Long id);
	List<CustomerModel> findAll();
	List<CustomerModel> search(String query);
	boolean delete(Long id);
}

