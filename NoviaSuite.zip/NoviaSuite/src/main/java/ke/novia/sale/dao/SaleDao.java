package ke.novia.sale.dao;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ke.novia.dao.BaseRepository;
import ke.novia.sale.model.SaleModel;
import ke.novia.stock.model.ProductModel;




@Repository
public interface SaleDao extends BaseRepository<SaleModel,Long> {
		List<SaleModel> findByproduct(ProductModel productModel);
		@Query("SELECT t FROM SaleModel t where t.product.displayName LIKE %:product%")
	    public List<SaleModel> search(@Param("product") String productModel, Pageable pageable);

	}
