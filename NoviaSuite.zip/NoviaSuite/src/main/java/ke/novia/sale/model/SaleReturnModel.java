package ke.novia.sale.model;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import ke.novia.stock.model.ProductCategoryModel;
import ke.novia.stock.model.ProductModel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="sales_returns")
@Getter @Setter @ToString
public class SaleReturnModel {
	@Id
	private Long id;
	@ManyToOne
	@JoinColumn(name="customer_id")
	CustomerModel customer;
	@ManyToOne
    @JoinColumn(name="sales_status_id")
	StatusModel status;	
	@ManyToOne
    @JoinColumn(name="stock_item_category_id")
	ProductCategoryModel productCategory;
	@ManyToOne
    @JoinColumn(name="stock_item_id")
	ProductModel product;	
	@ManyToOne
    @JoinColumn(name="stock_sale_id")
	SaleModel sale;
	@Column(name="return_date")
	private Date returnDate;
	@Column(name="reason_for_returning")
	private String reasonForReturning;
	@Column(name="quantity")
	private double quantity;
	
}
