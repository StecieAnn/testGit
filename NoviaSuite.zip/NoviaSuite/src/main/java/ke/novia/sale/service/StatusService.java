package ke.novia.sale.service;



import java.util.List;

import ke.novia.sale.model.StatusModel;




public interface StatusService {
	StatusModel save(StatusModel entity);
	StatusModel findById(Long id);
	List<StatusModel> findAll();
	List<StatusModel> search(String query);
	boolean delete(Long id);
}

