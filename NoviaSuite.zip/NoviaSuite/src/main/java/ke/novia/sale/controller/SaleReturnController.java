package ke.novia.sale.controller;


import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import ke.novia.sale.model.SaleReturnModel;
import ke.novia.sale.service.SaleReturnService;





@RestController
@RequestMapping({"SaleReturn","/SaleReturn"})
public class SaleReturnController {
	private final Logger logger = LoggerFactory.getLogger(SaleReturnModel.class);
	@Autowired
	SaleReturnService saleReturnService;
	
	@RequestMapping("/saleReturns")//Grid Data no search term
	public List<SaleReturnModel> saleReturns() {
		return saleReturnService.search("");
	}
	@RequestMapping("/saleReturns/{searchterm}")//Grid Data via search term
	public List<SaleReturnModel> entitySearch(@PathVariable String searchterm) {
		return saleReturnService.search(searchterm);
	}
	@RequestMapping("/findOne/{id}")//Find by is
	public SaleReturnModel findOne(@PathVariable Long id) {
		return saleReturnService.findById(id);
	} 
	@RequestMapping("/delete/{id}")//Delete by id
	public boolean delete(@PathVariable Long id) {
		return saleReturnService.delete(id);//Change THis
	}
	@RequestMapping(value = "/save", method = RequestMethod.POST)//Save
	public @ResponseBody Object saveOrUpdateSaleReturn(@Valid @RequestBody SaleReturnModel obj,Errors errors) {//Locale locale, Model model
		logger.error("saveOrUpdateSaleReturn() : {}", obj);
		if (errors.hasErrors()) {
    		return errors;
    	}
    	else{
    		return saleReturnService.save(obj);
    	}
	}
}
