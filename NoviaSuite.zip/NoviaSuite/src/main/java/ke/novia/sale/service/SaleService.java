package ke.novia.sale.service;

import java.util.List;
import ke.novia.sale.model.SaleModel;
import ke.novia.stock.model.ProductModel;



public interface SaleService {
	SaleModel save(SaleModel entity);
	SaleModel findById(Long id);
	List<SaleModel> findAll();
	boolean delete(Long id);
	List<SaleModel> search(String string);
	ProductModel getByDiscount(Long id);
}

