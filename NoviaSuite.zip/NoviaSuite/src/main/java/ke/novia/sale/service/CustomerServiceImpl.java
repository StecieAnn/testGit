package ke.novia.sale.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import ke.novia.sale.dao.CustomerDao;
import ke.novia.sale.model.CustomerModel;

@Service
public class CustomerServiceImpl implements CustomerService {
	@Autowired
	CustomerDao customerDao;
	@Override
	public CustomerModel save(CustomerModel entity) {
		// TODO Auto-generated method stub
		if(entity.getId()==null || entity.getId()<1){
			entity.setId(ke.novia.helpers.UniqueID.get());
			List<CustomerModel> dups = customerDao.findBycustomerName(entity.getCustomerName());
			if(dups==null || dups.size()>0){
				return null;
			}
		}
	
		return customerDao.save(entity);
	}

	@Override
	public CustomerModel findById(Long id) {
		// TODO Auto-generated method stub
		return customerDao.findOne(id);
	}

	@Override
	public List<CustomerModel> findAll() {
		// TODO Auto-generated method stub
		return customerDao.findAll();
	}

	@Override
	public List<CustomerModel> search(String query) {
		// TODO Auto-generated method stub
		return customerDao.search(query,new PageRequest(0, 100));
	}

	@Override
	public boolean delete(Long id) {
		customerDao.delete(id);
		return customerDao.findOne(id)==null;
	}



}

