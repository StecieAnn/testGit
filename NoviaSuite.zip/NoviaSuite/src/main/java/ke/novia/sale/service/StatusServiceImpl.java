package ke.novia.sale.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import ke.novia.sale.dao.StatusDao;
import ke.novia.sale.model.StatusModel;



@Service
public class StatusServiceImpl implements StatusService {
	@Autowired
	StatusDao statusDao;
	@Override
	public StatusModel save(StatusModel entity) {
		// TODO Auto-generated method stub
		if(entity.getId()==null || entity.getId()<1){
			entity.setId(ke.novia.helpers.UniqueID.get());
			List<StatusModel> dups = statusDao.findBydescription(entity.getDescription());
			if(dups==null || dups.size()>0){
				return null;
			}
		}
	
		return statusDao.save(entity);
	}

	@Override
	public StatusModel findById(Long id) {
		// TODO Auto-generated method stub
		return statusDao.findOne(id);
	}

	@Override
	public List<StatusModel> findAll() {
		// TODO Auto-generated method stub
		return statusDao.findAll();
	}

	@Override
	public List<StatusModel> search(String query) {
		// TODO Auto-generated method stub
		return statusDao.search(query,new PageRequest(0, 100));
	}

	@Override
	public boolean delete(Long id) {
		statusDao.delete(id);
		return statusDao.findOne(id)==null;
	}



}

