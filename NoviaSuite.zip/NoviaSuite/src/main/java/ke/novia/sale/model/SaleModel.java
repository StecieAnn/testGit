package ke.novia.sale.model;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import ke.novia.setup.model.SaleTaxModel;
import ke.novia.stock.model.ProductCategoryModel;
import ke.novia.stock.model.ProductModel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="stock_sales")
@Getter @Setter @ToString
public class SaleModel {
	@Id
	private Long id;
	@ManyToOne
    @JoinColumn(name="stock_item_id")
	ProductModel product;	
	@ManyToOne
	@JoinColumn(name="customer_id")
	CustomerModel customer;
	@Column(name="receipt_number")
	private String receiptNumber;
	@ManyToOne
    @JoinColumn(name="sales_status_id")
	StatusModel status;	
	@Column(name="quantity")
	private double quantity;
	@ManyToOne
    @JoinColumn(name="stock_item_category_id")
	ProductCategoryModel productCategory;
	@ManyToOne
    @JoinColumn(name="sales_tax_id")
	SaleTaxModel saleTax;	
	@Column(name="sales_date")
	private Date salesDate;
	@Column(name="barcode")
	private String barcode;
	@Column(name="served_by")
	private String servedBy;
	@Column(name="discount")
	private double discount;
	@Column(name="unit_price")
	private String unitPrice;
	@Column(name="total")
	private double total;

	
}
