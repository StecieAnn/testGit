package ke.novia.sale.service;

import java.util.List;
import ke.novia.sale.model.SaleReturnModel;


public interface SaleReturnService {
	SaleReturnModel save(SaleReturnModel entity);
	SaleReturnModel findById(Long id);
	List<SaleReturnModel> findAll();
	boolean delete(Long id);
	List<SaleReturnModel> search(String string);
	
}

