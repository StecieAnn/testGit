package ke.novia.sale.dao;
import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ke.novia.dao.BaseRepository;
import ke.novia.sale.model.SaleReturnModel;
import ke.novia.stock.model.ProductModel;


@Repository
public interface SaleReturnDao extends BaseRepository<SaleReturnModel, Long> {
	List<SaleReturnModel> findByproduct(ProductModel productModel);
	@Query("SELECT t FROM SaleReturnModel t where t.product.displayName LIKE %:product%")
    public List<SaleReturnModel> search(@Param("product") String productModel, Pageable pageable);
}

