package ke.novia;

//https://mifosforge.jira.com/wiki/display/MIFOSX/A+Possible+accounting+Spec

//https://mifosforge.jira.com/wiki/display/docs/Loan+Products

//http://mifos.cloud.answerhub.com/questions/152/what-are-the-features-of-chart-of-accounts-in-mifo.html


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
//http://javarticles.com/2016/01/spring-component-annotation-example.html
//https://www.mkyong.com/spring/spring-caching-and-ehcache-example/
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
@Configuration
@ComponentScan({"ke.novia.core.boot","ke.novia.core.config"})// ,"ke.novia.jobs.config"
@SpringBootApplication

public class WebApplication {
    public static void main(String[] args) {
    	ConfigurableApplicationContext ctx = SpringApplication.run(WebApplication.class, args);
        try {
			ApplicationExitUtil.waitForKeyPressToCleanlyExit(ctx);
		} catch (IOException e) {
			//e.printStackTrace();
		}
    }
}

abstract class ApplicationExitUtil {

    private ApplicationExitUtil() {}

    public static void waitForKeyPressToCleanlyExit(ConfigurableApplicationContext ctx) throws IOException {

        // NOTE: In Eclipse, the Shutdown Hooks are not invoked on exit (red
        // button).. In the case of MariaDB4j that's a problem because then the
        // mysqld won't be stopped, so:
        // (@see https://bugs.eclipse.org/bugs/show_bug.cgi?id=38016)
        System.out.println("\nHit Enter to quit...");
        // NOTE: In Eclipse, System.console() is not available.. so:
        // (@see https://bugs.eclipse.org/bugs/show_bug.cgi?id=122429)
        BufferedReader d = new BufferedReader(new InputStreamReader(System.in));
        d.readLine();

        ctx.stop();
        ctx.close();
    }
}
