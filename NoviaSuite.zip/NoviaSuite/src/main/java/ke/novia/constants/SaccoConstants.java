package ke.novia.constants;

public class SaccoConstants {

}
