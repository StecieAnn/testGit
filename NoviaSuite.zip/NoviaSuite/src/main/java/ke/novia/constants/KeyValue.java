package ke.novia.constants;

public class KeyValue {
	int id;
	String value;
	KeyValue(int id,String value){
		this.id=id;
		this.value=value;
	}
}
