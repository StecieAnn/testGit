
package ke.novia.constants;
/*
import java.util.ArrayList;
import java.util.List;
*/
//http://www.studytonight.com/java/enumerations.php
public class SaccoEnums {
	/*
	public static List<KeyValue> AccountTypes() {//
		List<KeyValue> data = new ArrayList<KeyValue>();
		data.add(new KeyValue(1, "Asset"));
		data.add(new KeyValue(2, "Liability"));
		data.add(new KeyValue(3, "Equity"));
		data.add(new KeyValue(4, "Income"));
		data.add(new KeyValue(5, "Expense"));
		return data;
	}
	*/
	
	public enum Products{
		Office(0,"Office"),
		Loan(1,"Loan Product"),
		Shares(2,"Shares Product"),
		Savings(3,"Savings Product"),
		Expense(4,"Fixed Deposit Savings Product");
		
		int id;
		String value;
		
		Products(int id,String value){
			this.id=id; this.value=value;
		}
		public int getId() {
			return id;
		}
		public String getValue() {
			return value;
		}
	}
	
	public enum AccountTypes{
		Asset(1,"Asset"),
		Liability(2,"Liability"),
		Equity(3,"Equity"),
		Income(4,"Income"),
		Expense(5,"Expense");
		
		int id;
		String value;
		
		AccountTypes(int id,String value){
			this.id=id; this.value=value;
		}
		public int getId() {
			return id;
		}
		public String getValue() {
			return value;
		}
	}
	
	public enum RecordStatuses {
		Active(1,"Active"),
		Inactive(2,"Inactive"),
		Open(3,"Open"),
		Closed(4,"Closed"),
		Deleted(5,"Deleted");
		
		int id;
		String value;
		
		RecordStatuses(int id,String value){
			this.id=id; this.value=value;
		}
		public int getId() {
			return id;
		}
		public String getValue() {
			return value;
		}
	}
	
	public enum ShareAccountTransactions {
		Deposit(1,"Deposit Shares"),
		Withdraw(2,"Withdrawal Shares"),
		TransferShares(3,"Transfer Shares to Member"),
		AdjustSharesUp(4,"Adjust Shares Up"),
		AdjustSharesDown(5,"Adjust Shares Down");
		
		int id;
		String value;
		
		ShareAccountTransactions(int id,String value){
			this.id=id; this.value=value;
		}
		public int getId() {
			return id;
		}
		public String getValue() {
			return value;
		}
	}
	
	public enum SavingsAccountTransactions {
		Deposit(1,"Deposit"),
		Withdraw(2,"Withdraw"),
		TransferShares(3,"Transfer Savings to Member"),
		AdjustSharesUp(4,"Adjust Savings Up"),
		AdjustSharesDown(5,"Adjust Savings Down");
		
		int id;
		String value;
		
		SavingsAccountTransactions(int id,String value){
			this.id=id; this.value=value;
		}
		public int getId() {
			return id;
		}
		public String getValue() {
			return value;
		}
	}
	
	public enum LoanAccountTransactions {
		Disbursal(1,"Loan Disbursement"),
		Repayment(2,"Loan Repayment"),
		RecoverableInterestAndInsurance(3,"Loan Recoverable Interest and Insurance"),
		AdjustLoanUp(4,"Adjust Loan Up"),
		AdjustLoanDown(5,"Adjust Loan Down"),
		OffsetLoanWithShares(6,"Offset Loan With Shares"),
		WriteOff(7,"Write Off Loan");
		
		int id;
		String value;
		
		LoanAccountTransactions(int id,String value){
			this.id=id; this.value=value;
		}
		public int getId() {
			return id;
		}
		public String getValue() {
			return value;
		}
	}
	
	//http://javabeginnerstutorial.com/core-java-tutorial/java-enum-enumerations/
	//http://www.studytonight.com/java/enumerations.php
}
