package ke.novia.setup.controller;


import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import ke.novia.setup.model.StockTransferModel;
import ke.novia.setup.service.StockTransferService;



@RestController
@RequestMapping({"StockTransfer","/StockTransfer"})
public class StockTransferController {
	private final Logger logger = LoggerFactory.getLogger(StockTransferModel.class);
	@Autowired
	StockTransferService stockTransferService;
	
	@RequestMapping("/stockTransfers")//Grid Data no search term
	public List<StockTransferModel> stockTransfers() {
		return stockTransferService.search("");
	}
	@RequestMapping("/stockTransfers/{searchterm}")//Grid Data via search term
	public List<StockTransferModel> entitySearch(@PathVariable String searchterm) {
		return stockTransferService.search(searchterm);
	}
	@RequestMapping("/findOne/{id}")//
	public StockTransferModel findOne(@PathVariable Long id) {
		return stockTransferService.findById(id);
	} 
	@RequestMapping("/delete")
	public boolean delete(@Valid @RequestBody StockTransferModel obj,Errors errors) {
		return stockTransferService.delete(obj.getId());//Change THis
	}
	@RequestMapping(value = "/save", method = RequestMethod.POST)//Save
	public @ResponseBody Object saveOrUpdateStockTransfer(@Valid @RequestBody StockTransferModel obj,Errors errors) {//Locale locale, Model model
		logger.error("saveOrUpdateStockTransfer() : {}", obj);
		if (errors.hasErrors()) {
    		return errors;
    	}
    	else{
    		return stockTransferService.save(obj);
    	}
	}

}
