package ke.novia.setup.service;

import java.util.List;
import ke.novia.setup.model.NonReturnableItemModel;
import ke.novia.stock.model.ProductModel;


public interface NonReturnableItemService {
	NonReturnableItemModel save(NonReturnableItemModel entity);
	NonReturnableItemModel findById(Long id);
	List<NonReturnableItemModel> findAll();
	boolean delete(Long id);
	List<NonReturnableItemModel> search(String string);
	List<NonReturnableItemModel> findByproduct(ProductModel productModel);
}

