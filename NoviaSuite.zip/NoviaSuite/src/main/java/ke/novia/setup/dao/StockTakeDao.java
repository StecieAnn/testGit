package ke.novia.setup.dao;
import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ke.novia.dao.BaseRepository;
import ke.novia.setup.model.StockTakeModel;
import ke.novia.stock.model.ProductModel;


@Repository
public interface StockTakeDao extends BaseRepository<StockTakeModel, Long> {
	List<StockTakeModel> findByproduct(ProductModel product);
	@Query("SELECT t FROM StockTakeModel t where t.product.displayName = :product")
	//@Query("SELECT s FROM StockTakeModel s WHERE lower(s.product) LIKE :query% ORDER BY s.product DESC")
    public List<StockTakeModel> search(@Param("product") ProductModel product, Pageable pageable);
}

