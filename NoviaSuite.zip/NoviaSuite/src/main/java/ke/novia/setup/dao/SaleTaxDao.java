package ke.novia.setup.dao;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ke.novia.dao.BaseRepository;
import ke.novia.setup.model.SaleTaxModel;




@Repository
public interface SaleTaxDao extends BaseRepository<SaleTaxModel,Long> {
	
List<SaleTaxModel> findBytaxName(String taxName);
@Query("SELECT s FROM SaleTaxModel s WHERE lower(s.taxName) LIKE :query% ORDER BY s.taxName DESC")
public List<SaleTaxModel> search(@Param("query") String query, Pageable pageable);
}
