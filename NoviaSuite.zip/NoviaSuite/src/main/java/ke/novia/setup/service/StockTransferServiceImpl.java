package ke.novia.setup.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import ke.novia.setup.dao.ConsumerStoreModeDao;
import ke.novia.setup.dao.StockTranferDao;
import ke.novia.setup.model.StockTransferModel;
import ke.novia.stock.dao.ProductDao;




@Service
public class StockTransferServiceImpl implements StockTransferService {
	
	@Autowired
	StockTranferDao stockTranferDao;
	
	@Autowired
	ConsumerStoreModeDao consumerStoreModeDao;
	
	@Autowired
	ProductDao productDao;
	
	@Override
	public StockTransferModel save(StockTransferModel entity) {
		// TODO Auto-generated method stub
		if(entity.getId()==null || entity.getId()<1){
			entity.setId(ke.novia.helpers.UniqueID.get());
			List<StockTransferModel> dups = stockTranferDao.findByproduct(entity.getProduct());
			StockTransferModel stockTransferModel=stockTranferDao.save(entity);
			if(stockTransferModel!= null && stockTransferModel.getId()>0){
				//increment stock
				consumerStoreModeDao.incrementStock(stockTransferModel.getConsumerStoreMode().getId(), stockTransferModel.getQuantity());
				productDao.decrementStock(stockTransferModel.getProduct().getId(), stockTransferModel.getQuantity());
			}
			if(dups==null || dups.size()>0){
				return null;
			}
			return stockTransferModel ;
		}
	
		return stockTranferDao.save(entity);
	}

	@Override
	public StockTransferModel findById(Long id) {
		return stockTranferDao.findOne(id);
	}

	@Override
	public List<StockTransferModel> findAll() {
		return stockTranferDao.findAll();
	}

	@Override
	public boolean delete(Long id) {
		stockTranferDao.delete(id);
		return stockTranferDao.findOne(id)==null;
	}

	@Override
	public List<StockTransferModel> search(String string) {
		return stockTranferDao.search(string,new PageRequest(0, 100));
	}



}

