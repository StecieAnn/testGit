package ke.novia.setup.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import ke.novia.stock.model.ProductModel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="consumer_stores")
@Getter @Setter @ToString
public class ConsumerStoreModeModel {
	@Id
	private Long id;
	@ManyToOne
	@JoinColumn(name = "stock_item_id")
	ProductModel product;
	@Column(name="store_name")
	private String storeName;
	@Column(name="quantity")
	private double quantity;
	
}
