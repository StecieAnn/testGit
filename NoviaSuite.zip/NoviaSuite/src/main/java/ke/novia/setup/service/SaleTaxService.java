package ke.novia.setup.service;

import java.util.List;

import ke.novia.setup.model.SaleTaxModel;


public interface SaleTaxService {
	SaleTaxModel save(SaleTaxModel entity);
	SaleTaxModel findById(Long id);
	List<SaleTaxModel> findAll();
	List<SaleTaxModel> search(String query);
	boolean delete(Long id);
}

