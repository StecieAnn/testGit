package ke.novia.setup.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import ke.novia.setup.dao.ConsumerStoreModeDao;
import ke.novia.setup.dao.StockTranferDao;
import ke.novia.setup.model.ConsumerStoreModeModel;
import ke.novia.setup.model.StockTransferModel;
import ke.novia.stock.model.ProductModel;



@Service
public class ConsumerStoreModeServiceImpl implements ConsumerStoreModeService {
	@Autowired
	ConsumerStoreModeDao consumerStoreModeDao;
	
	@Autowired
	StockTranferDao stockTranferDao;
	
	@Override
	public ConsumerStoreModeModel save(ConsumerStoreModeModel entity) {
		// TODO Auto-generated method stub
		if(entity.getId()==null || entity.getId()<1){
			entity.setId(ke.novia.helpers.UniqueID.get());
			List<ConsumerStoreModeModel> dups = consumerStoreModeDao.findByProduct(entity.getProduct());
			if(dups==null || dups.size()>0){
				return null;
			}		
		
		}
	
		return consumerStoreModeDao.save(entity);
	}
	@Override
	public ConsumerStoreModeModel findById(Long id) {
		// TODO Auto-generated method stub
		return consumerStoreModeDao.findOne(id);
	}

	@Override
	public List<ConsumerStoreModeModel> findAll() {
		// TODO Auto-generated method stub
		return consumerStoreModeDao.findAll();
	}

	public List<ConsumerStoreModeModel> findByProduct(ProductModel productModel){
		return consumerStoreModeDao.findByProduct(productModel);
	}
	@Override
	public boolean delete(Long id) {
		consumerStoreModeDao.delete(id);
		return consumerStoreModeDao.findOne(id)==null;
	}

	@Override
	public List<ConsumerStoreModeModel> search(String query) {
		
		return consumerStoreModeDao.search(query, new PageRequest(0, 100));
	}
	@Override
	public StockTransferModel getByQuantity(Long id) {
		// TODO Auto-generated method stub
		return stockTranferDao.findOne(id);
	}

}

