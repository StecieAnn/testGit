package ke.novia.setup.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import ke.novia.setup.dao.MainStoreModeDao;
import ke.novia.setup.model.MainStoreModeModel;
import ke.novia.stock.dao.ProductDao;


@Service
public class MainStoreModeServiceImpl implements MainStoreModeService {
	
	@Autowired
	MainStoreModeDao mainStoreModeDao;
			
	@Autowired
	ProductDao productDao;
	
	@Override
	public MainStoreModeModel save(MainStoreModeModel entity) {
		if(entity.getId()==null || entity.getId()<1){
			entity.setId(ke.novia.helpers.UniqueID.get());
			List<MainStoreModeModel> dups = mainStoreModeDao.findByproduct(entity.getProduct());
			if(dups==null || dups.size()>0){
				return null;
			}
			
		}
	
		return mainStoreModeDao.save(entity);
	}

	@Override
	public MainStoreModeModel findById(Long id) {
		return mainStoreModeDao.findOne(id);
	}

	@Override
	public List<MainStoreModeModel> findAll() {
		return mainStoreModeDao.findAll();
	}

	@Override
	public List<MainStoreModeModel> search(String query) {
		return mainStoreModeDao.search(query,new PageRequest(0, 100));
	}
	@Override
	public boolean delete(Long id) {
		mainStoreModeDao.delete(id);
		return mainStoreModeDao.findOne(id)==null;
	}


}

