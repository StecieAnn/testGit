package ke.novia.setup.controller;


import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import ke.novia.setup.model.SaleTaxModel;
import ke.novia.setup.service.SaleTaxService;







@RestController
@RequestMapping({"SaleTax","/SaleTax"})
public class SaleTaxController {
	private final Logger logger = LoggerFactory.getLogger(SaleTaxModel.class);
	@Autowired
	SaleTaxService saleTaxService;
	
	@RequestMapping("/saleTaxes")
	public List<SaleTaxModel> saleTaxes() {
		return saleTaxService.search("");
	}
	@RequestMapping("/saleTaxes/{searchterm}")
	public List<SaleTaxModel> entitySearch(@PathVariable String searchterm) {
		return saleTaxService.search(searchterm);
	}
	@RequestMapping("/findOne/{id}")
	public SaleTaxModel findOne(@PathVariable Long id) {
		return saleTaxService.findById(id);
	} 
	@RequestMapping("/delete/{id}")
	public boolean delete(@PathVariable Long id) {
		return saleTaxService.delete(id);
	}
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public @ResponseBody Object saveOrUpdateSaleTax(@Valid @RequestBody SaleTaxModel obj,Errors errors) {
		logger.error("saveOrUpdateSaleTax() : {}", obj);
		if (errors.hasErrors()) {
    		return errors;
    	}
    	else{
    		return saleTaxService.save(obj);
    	}
	}
}
