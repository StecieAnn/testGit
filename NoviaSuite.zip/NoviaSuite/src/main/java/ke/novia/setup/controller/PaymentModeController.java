package ke.novia.setup.controller;


import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import ke.novia.setup.model.PaymentModeModel;
import ke.novia.stock.service.PaymentModeService;




@RestController
@RequestMapping({"PaymentMode","/PaymentMode"})
public class PaymentModeController {
	private final Logger logger = LoggerFactory.getLogger(PaymentModeModel.class);
	@Autowired
	PaymentModeService paymentModeService;
	
	@RequestMapping("/paymentModes")
	public List<PaymentModeModel> paymentModes() {
		return paymentModeService.search("");
	}
	@RequestMapping("/paymentModes/{searchterm}")
	public List<PaymentModeModel> entitySearch(@PathVariable String searchterm) {
		return paymentModeService.search(searchterm);
	}
	@RequestMapping("/findOne/{id}")
	public PaymentModeModel findOne(@PathVariable Long id) {
		return paymentModeService.findById(id);
	} 
	@RequestMapping("/delete/{id}")
	public boolean delete(@PathVariable Long id) {
		return paymentModeService.delete(id);
	}
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public @ResponseBody Object saveOrUpdatePaymentMode(@Valid @RequestBody PaymentModeModel obj,Errors errors) {
		logger.error("saveOrUpdatePaymentMode() : {}", obj);
		if (errors.hasErrors()) {
    		return errors;
    	}
    	else{
    		return paymentModeService.save(obj);
    	}
	}
}
