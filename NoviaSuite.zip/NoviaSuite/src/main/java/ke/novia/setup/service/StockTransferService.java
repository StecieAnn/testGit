package ke.novia.setup.service;

import java.util.List;
import ke.novia.setup.model.StockTransferModel;


public interface StockTransferService {
	StockTransferModel save(StockTransferModel entity);
	StockTransferModel findById(Long id);
	List<StockTransferModel> findAll();
	boolean delete(Long id);
	List<StockTransferModel> search(String string);

}

