package ke.novia.setup.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import ke.novia.setup.dao.NonReturnableItemDao;
import ke.novia.setup.model.NonReturnableItemModel;
import ke.novia.stock.dao.ProductDao;
import ke.novia.stock.model.ProductModel;



@Service
public class NonReturnableItemServiceImpl implements NonReturnableItemService {
	@Autowired
	NonReturnableItemDao nonReturnableItemDao;
	
	@Autowired
	ProductDao productDao;
	
	@Override
	public NonReturnableItemModel save(NonReturnableItemModel entity) {
		// TODO Auto-generated method stub
		if(entity.getId()==null || entity.getId()<1){
			entity.setId(ke.novia.helpers.UniqueID.get());
			List<NonReturnableItemModel> dups = nonReturnableItemDao.findByproduct(entity.getProduct());
			NonReturnableItemModel nonReturnableItemModel=nonReturnableItemDao.save(entity);
			if(nonReturnableItemModel!= null && nonReturnableItemModel.getId()>0){
				productDao.decrementStock(nonReturnableItemModel.getProduct().getId(), nonReturnableItemModel.getQuantity());
			}
			if(dups==null || dups.size()>0){
				return null;
			}
			return nonReturnableItemModel;
		}
				
		return nonReturnableItemDao.save(entity);
	}

	@Override
	public NonReturnableItemModel findById(Long id) {
		return nonReturnableItemDao.findOne(id);
	}

	@Override
	public List<NonReturnableItemModel> findAll() {
		return nonReturnableItemDao.findAll();
	}

	@Override
	public boolean delete(Long id) {
		nonReturnableItemDao.delete(id);
		return nonReturnableItemDao.findOne(id)==null;
	}

	@Override
	public List<NonReturnableItemModel> search(String query) {
		return nonReturnableItemDao.search(query,new PageRequest(0, 100));
	}

	public List<NonReturnableItemModel> findByproduct(ProductModel productModel){
	return nonReturnableItemDao.findByproduct(productModel);
}
}

