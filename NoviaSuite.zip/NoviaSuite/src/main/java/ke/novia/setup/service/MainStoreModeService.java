package ke.novia.setup.service;

import java.util.List;
import ke.novia.setup.model.MainStoreModeModel;



public interface MainStoreModeService {
	MainStoreModeModel save(MainStoreModeModel entity);
	MainStoreModeModel findById(Long id);
	List<MainStoreModeModel> findAll();
	boolean delete(Long id);
	List<MainStoreModeModel> search(String string);
}

