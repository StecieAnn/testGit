package ke.novia.setup.controller;


import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import ke.novia.setup.model.ConsumerStoreModeModel;
import ke.novia.setup.service.ConsumerStoreModeService;





@RestController
@RequestMapping({"ConsumerStoreMode","/ConsumerStoreMode"})
public class ConsumerStoreModeController {
	private final Logger logger = LoggerFactory.getLogger(ConsumerStoreModeModel.class);
	@Autowired
	ConsumerStoreModeService consumerStoreModeService;
	
	@RequestMapping("/consumerStoreModes")//Grid Data no search term
	public List<ConsumerStoreModeModel> consumerStoreModes() {
		return consumerStoreModeService.search("");
	}
	@RequestMapping("/consumerStoreModes/{searchterm}")
	public List<ConsumerStoreModeModel> entitySearch(@PathVariable String searchterm) {
		return consumerStoreModeService.search(searchterm);
	}
	@RequestMapping("/findOne/{id}")//Find by id
	public ConsumerStoreModeModel findOne(@PathVariable Long id) {
		return consumerStoreModeService.findById(id);
	} 
	@RequestMapping("/delete/{id}")//Delete by id
	public boolean delete(@PathVariable Long id) {
		return consumerStoreModeService.delete(id);//Change THis
	}
	@RequestMapping(value = "/save", method = RequestMethod.POST)//Save
	public @ResponseBody Object saveOrUpdateConsumerStoreMode(@Valid @RequestBody ConsumerStoreModeModel obj,Errors errors) {//Locale locale, Model model
		logger.error("saveOrUpdateConsumerStoreMode() : {}", obj);
		if (errors.hasErrors()) {
    		return errors;
    	}
    	else{
    		return consumerStoreModeService.save(obj);
    	}
	}

}
