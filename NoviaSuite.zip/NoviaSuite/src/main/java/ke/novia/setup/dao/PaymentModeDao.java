package ke.novia.setup.dao;
import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ke.novia.dao.BaseRepository;
import ke.novia.setup.model.PaymentModeModel;


@Repository
public interface PaymentModeDao extends BaseRepository<PaymentModeModel, Long> {
	List<PaymentModeModel> findBydescription(String description);
	@Query("SELECT s FROM PaymentModeModel s WHERE lower(s.description) LIKE :query% ORDER BY s.description DESC")
    public List<PaymentModeModel> search(@Param("query") String query, Pageable pageable);
}

