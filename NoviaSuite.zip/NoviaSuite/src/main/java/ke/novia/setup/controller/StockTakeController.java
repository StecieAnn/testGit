package ke.novia.setup.controller;


import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import ke.novia.setup.model.StockTakeModel;
import ke.novia.setup.service.StockTakeService;
import ke.novia.stock.model.ProductModel;




@RestController
@RequestMapping({"StockTake","/StockTake"})
public class StockTakeController {
	private final Logger logger = LoggerFactory.getLogger(StockTakeModel.class);
	@Autowired
	StockTakeService stockTakeService;
	
	@RequestMapping("/stockTakes")//Grid Data no search term
	public List<StockTakeModel> stockTakes() {
		return stockTakeService.search("");
	}
	@RequestMapping("/stockTakes/{searchterm}")//Grid Data via search term
	public List<StockTakeModel> entitySearch(@PathVariable ProductModel searchterm) {
		return stockTakeService.search(searchterm);
	}
	@RequestMapping("/findOne/{id}")//Find by is
	public StockTakeModel findOne(@PathVariable Long id) {
		return stockTakeService.findById(id);
	} 
	@RequestMapping("/delete/{id}")//Delete by id
	public boolean delete(@PathVariable Long id) {
		return stockTakeService.delete(id);//Change THis
	}
	@RequestMapping(value = "/save", method = RequestMethod.POST)//Save
	public @ResponseBody Object saveOrUpdateStockTake(@Valid @RequestBody StockTakeModel obj,Errors errors) {//Locale locale, Model model
		logger.error("saveOrUpdateStockTake() : {}", obj);
		if (errors.hasErrors()) {
    		return errors;
    	}
    	else{
    		return stockTakeService.save(obj);
    	}
	}

}
