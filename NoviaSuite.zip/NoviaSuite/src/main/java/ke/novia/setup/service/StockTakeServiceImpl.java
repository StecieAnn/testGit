package ke.novia.setup.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import ke.novia.setup.dao.StockTakeDao;
import ke.novia.setup.model.StockTakeModel;
import ke.novia.stock.dao.ProductDao;
import ke.novia.stock.model.ProductModel;



@Service
public class StockTakeServiceImpl implements StockTakeService {
	@Autowired
	StockTakeDao stockTakeDao;
	
	@Autowired
	 ProductDao productDao;
	
	@Override
	public StockTakeModel save(StockTakeModel entity) {
		// TODO Auto-generated method stub
		if(entity.getId()==null || entity.getId()<1){
			entity.setId(ke.novia.helpers.UniqueID.get());
			List<StockTakeModel> dups = stockTakeDao.findByproduct(entity.getProduct());
			StockTakeModel stockTakeModel=stockTakeDao.save(entity);
			if(stockTakeModel!=null && stockTakeModel.getId()>0){
			productDao.decrementStock(stockTakeModel.getProduct().getId(), stockTakeModel.getQuantity());
			if(dups==null || dups.size()>0){
				return null;
			}
			}
			return stockTakeModel;
		}
	
		return stockTakeDao.save(entity);
	}

	@Override
	public StockTakeModel findById(Long id) {
		return stockTakeDao.findOne(id);
	}

	@Override
	public List<StockTakeModel> findAll() {
		return stockTakeDao.findAll();
	}

	@Override
	public List<StockTakeModel> search(ProductModel query) {	
		return stockTakeDao.search(query,new PageRequest(0, 100));
	}
	@Override
	public boolean delete(Long id) {
		stockTakeDao.delete(id);
		return stockTakeDao.findOne(id)==null;
	}

	@Override
	public List<StockTakeModel> search(String string) {
		return null;
	}

	/*@Override
	public StockTakeModel findByproduct(Long id) {
		return stockTakeDao.findOne(id);
	}*/



}

