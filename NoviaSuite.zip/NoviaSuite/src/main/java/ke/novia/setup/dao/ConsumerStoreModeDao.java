package ke.novia.setup.dao;
import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import ke.novia.dao.BaseRepository;
import ke.novia.setup.model.ConsumerStoreModeModel;
import ke.novia.stock.model.ProductModel;


@Repository
public interface ConsumerStoreModeDao extends BaseRepository<ConsumerStoreModeModel, Long> {
	List<ConsumerStoreModeModel> findByProduct(ProductModel productModel);
	@Query("SELECT t FROM ConsumerStoreModeModel t where t.product.displayName LIKE %:product%")
    public List<ConsumerStoreModeModel> search(@Param("product") String productModel, Pageable pageable);
	
	@Modifying
	@Transactional
	@Query("UPDATE ConsumerStoreModeModel s SET s.quantity=s.quantity+:quantity WHERE s.id = :consumerStoreModeId")
    public void incrementStock(@Param("consumerStoreModeId") long id,@Param("quantity") double quantity);
	
}

