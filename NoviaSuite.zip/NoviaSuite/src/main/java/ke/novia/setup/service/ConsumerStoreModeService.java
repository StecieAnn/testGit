package ke.novia.setup.service;

import java.util.List;
import ke.novia.setup.model.ConsumerStoreModeModel;
import ke.novia.setup.model.StockTransferModel;
import ke.novia.stock.model.ProductModel;


public interface ConsumerStoreModeService {
	ConsumerStoreModeModel save(ConsumerStoreModeModel entity);
	ConsumerStoreModeModel findById(Long id);
	List<ConsumerStoreModeModel> findAll();
	List<ConsumerStoreModeModel> findByProduct(ProductModel productModel);
	boolean delete(Long id);
	List<ConsumerStoreModeModel> search(String string);
	StockTransferModel  getByQuantity(Long id);

	
}

