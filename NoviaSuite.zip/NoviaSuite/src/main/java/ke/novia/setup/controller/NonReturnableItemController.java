package ke.novia.setup.controller;


import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import ke.novia.setup.model.NonReturnableItemModel;
import ke.novia.setup.service.NonReturnableItemService;




@RestController
@RequestMapping({"NonReturnableItem","/NonReturnableItem"})
public class NonReturnableItemController {
	private final Logger logger = LoggerFactory.getLogger(NonReturnableItemModel.class);
	@Autowired
	NonReturnableItemService nonReturnableItemService;
	
	@RequestMapping("/nonReturnableItems")//Grid Data no search term
	public List<NonReturnableItemModel> nonReturnableItems() {
		return nonReturnableItemService.search("");
	}
	@RequestMapping("/nonReturnableItems/{searchterm}")//Grid Data via search term
	public List<NonReturnableItemModel> entitySearch(@PathVariable String searchterm) {
		return nonReturnableItemService.search(searchterm);
	}
	@RequestMapping("/findOne/{id}")//Find by is
	public NonReturnableItemModel findOne(@PathVariable Long id) {
		return nonReturnableItemService.findById(id);
	} 
	@RequestMapping("/delete/{id}")//Delete by id
	public boolean delete(@PathVariable Long id) {
		return nonReturnableItemService.delete(id);//Change THis
	}
	@RequestMapping(value = "/save", method = RequestMethod.POST)//Save
	public @ResponseBody Object saveOrUpdateNonReturnableItem(@Valid @RequestBody NonReturnableItemModel obj,Errors errors) {//Locale locale, Model model
		logger.error("saveOrUpdateNonReturnableItem() : {}", obj);
		if (errors.hasErrors()) {
    		return errors;
    	}
    	else{
    		return nonReturnableItemService.save(obj);
    	}
	}
}
