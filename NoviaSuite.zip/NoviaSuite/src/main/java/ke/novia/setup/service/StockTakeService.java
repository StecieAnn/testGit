package ke.novia.setup.service;

import java.util.List;

import ke.novia.setup.model.StockTakeModel;
import ke.novia.stock.model.ProductModel;


public interface StockTakeService {
	StockTakeModel save(StockTakeModel entity);
	StockTakeModel findById(Long id);
	//StockTakeModel findByproduct(Long id);
	List<StockTakeModel> findAll();
	List<StockTakeModel> search(ProductModel query);
	boolean delete(Long id);
	List<StockTakeModel> search(String string);
	
}

