package ke.novia.setup.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import ke.novia.setup.dao.SaleTaxDao;
import ke.novia.setup.model.SaleTaxModel;

@Service
public class SaleTaxServiceImpl implements SaleTaxService {
	
	@Autowired
	SaleTaxDao saleTaxDao;
	
	@Override
	public SaleTaxModel save(SaleTaxModel entity) {
		// TODO Auto-generated method stub
		if(entity.getId()==null || entity.getId()<1){
			entity.setId(ke.novia.helpers.UniqueID.get());
			List<SaleTaxModel> dups = saleTaxDao.findBytaxName(entity.getTaxName());
			if(dups==null || dups.size()>0){
				return null;
			}
		}
	
		return saleTaxDao.save(entity);
	}

	@Override
	public SaleTaxModel findById(Long id) {
		// TODO Auto-generated method stub
		return saleTaxDao.findOne(id);
	}

	@Override
	public List<SaleTaxModel> findAll() {
		// TODO Auto-generated method stub
		return saleTaxDao.findAll();
	}

	@Override
	public List<SaleTaxModel> search(String query) {
		// TODO Auto-generated method stub
		return saleTaxDao.search(query,new PageRequest(0, 100));
	}

	@Override
	public boolean delete(Long id) {
		saleTaxDao.delete(id);
		return saleTaxDao.findOne(id)==null;
	}



}

