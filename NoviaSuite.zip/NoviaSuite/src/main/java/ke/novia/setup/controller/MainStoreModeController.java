package ke.novia.setup.controller;


import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import ke.novia.setup.model.MainStoreModeModel;
import ke.novia.setup.service.MainStoreModeService;





@RestController
@RequestMapping({"MainStoreMode","/MainStoreMode"})
public class MainStoreModeController {
	private final Logger logger = LoggerFactory.getLogger(MainStoreModeModel.class);
	@Autowired
	MainStoreModeService mainStoreModeService;
	
	@RequestMapping("/mainStoreModes")//Grid Data no search term
	public List<MainStoreModeModel> mainStoreModes() {
		return mainStoreModeService.search("");
	}
	@RequestMapping("/mainStoreModes/{searchterm}")//Grid Data via search term
	public List<MainStoreModeModel> entitySearch(@PathVariable String searchterm) {
		return mainStoreModeService.search(searchterm);
	}
	@RequestMapping("/findOne/{id}")//Find by is
	public MainStoreModeModel findOne(@PathVariable Long id) {
		return mainStoreModeService.findById(id);
	} 
	@RequestMapping("/delete/{id}")//Delete by id
	public boolean delete(@PathVariable Long id) {
		return mainStoreModeService.delete(id);//Change THis
	}
	@RequestMapping(value = "/save", method = RequestMethod.POST)//Save
	public @ResponseBody Object saveOrUpdateMainStoreMode(@Valid @RequestBody MainStoreModeModel obj,Errors errors) {//Locale locale, Model model
		logger.error("saveOrUpdateMainStoreMode() : {}", obj);
		if (errors.hasErrors()) {
    		return errors;
    	}
    	else{
    		return mainStoreModeService.save(obj);
    	}
	}

}
