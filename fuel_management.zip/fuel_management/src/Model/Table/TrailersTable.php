<?php
namespace App\Model\Table;
use Cake\ORM\Table;
use Cake\Validation\Validator;

class TrailersTable extends Table {
	public function initialize(array $config){            
		parent::initialize($config);
                $this->table('fleet_trailers');
		$this->primaryKey("id");
		$this->addBehavior('Timestamp',[
			'events'=>[
				'Model.beforeSave'=>[
					'created_at'=>'new','updated_at'=>'always'
				]
			]
		]);
	}
	
    public function validationDefault(Validator $validator)
    {
		$validator->requirePresence(['trailer_type','trailer_make','registration_number'], 'create');
        return $validator;
    }
	
}
?>