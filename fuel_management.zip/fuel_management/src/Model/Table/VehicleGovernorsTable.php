<?php
namespace App\Model\Table;
use Cake\ORM\Table;
use Cake\Validation\Validator;

class VehicleGovernorsTable extends Table {
	public function initialize(array $config){            
		parent::initialize($config);
                $this->table('fleet_vehicle_governors');
		$this->primaryKey("id");
		$this->addBehavior('Timestamp',[
			'events'=>[
				'Model.beforeSave'=>[
					'created_at'=>'new','updated_at'=>'always'
				]
			]
		]);
	}
	
    public function validationDefault(Validator $validator)
    {
		$validator->requirePresence(['vehicle_id','governor_name','governor_vendor','governor_no','governor_date_of_issue','governor_expire_date','is_current_governor'], 'create');
        return $validator;
    }
	
}
?>