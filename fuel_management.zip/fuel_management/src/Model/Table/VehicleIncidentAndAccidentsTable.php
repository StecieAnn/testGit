<?php
namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;

class VehicleIncidentAndAccidentsTable extends Table {
	public function initialize(array $config){            
		parent::initialize($config);
                $this->table('fleet_vehicle_incident_and_accident');
		$this->primaryKey("id");
		$this->addBehavior('Timestamp',[
			'events'=>[
				'Model.beforeSave'=>[
					'created_at'=>'new','updated_at'=>'always'
				]
			]
		]);
	}
	
    public function validationDefault(Validator $validator)
    {
		$validator->requirePresence(['vehicle_id','driver_id','incident_or_accident_id'], 'create');
        return $validator;
    }
	
}
?>