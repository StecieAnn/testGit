<?php
namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;

class DriverDrivingLicensesTable extends Table {
	public function initialize(array $config){            
		parent::initialize($config);
                $this->table('fleet_driver_driving_licenses');
		$this->primaryKey("id");
		$this->addBehavior('Timestamp',[
			'events'=>[
				'Model.beforeSave'=>[
					'created_at'=>'new','updated_at'=>'always'
				]
			]
		]);
	}
	
    public function validationDefault(Validator $validator)
    {
		$validator->requirePresence(['dl_type','dl_class','dl_number','dl_isssue_date','dl_expiry_date','is_current_dl'], 'create');
        return $validator;
    }
	
}
?>