<?php
namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;

class VehicleDriverAssignmentsTable extends Table {
	public function initialize(array $config){            
		parent::initialize($config);
                $this->table('fleet_vehicle_driver_assignment');
		$this->primaryKey("id");
		$this->addBehavior('Timestamp',[
			'events'=>[
				'Model.beforeSave'=>[
					'created_at'=>'new','updated_at'=>'always'
				]
			]
		]);
	}
	
    public function validationDefault(Validator $validator)
    {
		$validator->requirePresence(['vehicle_id','driver_id','assingment_date','comment','is_current_assingment'], 'create');
        return $validator;
    }
	
}
?>