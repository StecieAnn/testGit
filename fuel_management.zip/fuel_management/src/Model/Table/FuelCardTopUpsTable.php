<?php
namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;

class FuelCardTopUpsTable extends Table {
	public function initialize(array $config){
		parent::initialize($config);
                 $this->table('fleet_fuel_card_top_ups');
		$this->primaryKey("id");
		$this->addBehavior('Timestamp',[
			'events'=>[
				'Model.beforeSave'=>[
					'created_at'=>'new','updated_at'=>'always'
				]
			]
		]);
	}
	
    public function validationDefault(Validator $validator)
    {
		$validator->requirePresence(['fuel_card_amount_available','fuel_card_amount_topped_up','name_of_fuel_station','location_of_fuel_station'], 'create');
        return $validator;
    }
	
}
?>