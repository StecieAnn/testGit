<?php
namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;

class VehicleModelsTable extends Table {
	public function initialize(array $config){            
		parent::initialize($config);
                $this->table('fleet_vehicle_models');
		$this->primaryKey("id");
		$this->addBehavior('Timestamp',[
			'events'=>[
				'Model.beforeSave'=>[
					'created_at'=>'new','updated_at'=>'always'
				]
			]
		]);
	}
	
    public function validationDefault(Validator $validator)
    {
		$validator->requirePresence(['v_make','v_type','v_model'], 'create');
        return $validator;
    }
	
}
?>