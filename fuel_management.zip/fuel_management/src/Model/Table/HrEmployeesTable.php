<?php

namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;

class HrEmployeesTable extends Table {
	public function initialize(array $config){
		parent::initialize($config);
		$this->primaryKey("id");
		$this->addBehavior('Timestamp',[
			'events'=>[
				'Model.beforeSave'=>[
					'created_at'=>'new',
                                        'updated_at'=>'always'
				]
			]
		]);
	}
	
    public function validationDefault(Validator $validator)
    {
		$validator->requirePresence(['pf_number','first_name','other_names'], 'create');
        return $validator;
    }
	
}
?>
