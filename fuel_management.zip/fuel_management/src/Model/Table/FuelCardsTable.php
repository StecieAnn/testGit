<?php
namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;

class FuelCardsTable extends Table {
	public function initialize(array $config){            
		parent::initialize($config);
                $this->table('fleet_fuel_cards');
		$this->primaryKey("id");
		$this->addBehavior('Timestamp',[
			'events'=>[
				'Model.beforeSave'=>[
					'created_at'=>'new','updated_at'=>'always'
				]
			]
		]);
	}
	
    public function validationDefault(Validator $validator)
    {
		$validator->requirePresence(['card_number','provider','amount_available'], 'create');
        return $validator;
    }
	
}
?>