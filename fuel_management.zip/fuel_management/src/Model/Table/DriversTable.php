<?php

namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;

class DriversTable extends Table {
	public function initialize(array $config){
		parent::initialize($config);
                $this->table('fleet_drivers');
		$this->primaryKey("id");
		$this->addBehavior('Timestamp',[
			'events'=>[
				'Model.beforeSave'=>[
					'created_at'=>'new',
                                        'updated_at'=>'always'
				]
			]
		]);
	}
	
    public function validationDefault(Validator $validator)
    {
		$validator->requirePresence(['employee_id','pf_number','first_name','other_names','driver_class'], 'create');
        return $validator;
    }
	
}
?>
