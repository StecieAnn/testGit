<?php

namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;

class FuelPurchasesTable extends Table {
	public function initialize(array $config){
		parent::initialize($config);
                $this->table('fleet_fuel_purchases');
		$this->primaryKey("id");
		$this->addBehavior('Timestamp',[
			'events'=>[
				'Model.beforeSave'=>[
					'created_at'=>'new',
                                        'updated_at'=>'always'
				]
			]
		]);
	}
	
    public function validationDefault(Validator $validator)
    {
		$validator->requirePresence(['name_of_fuel_station','location_of_fuel_station','units','unit_price','total_amount'], 'create');
        return $validator;
    }
	
}
?>
