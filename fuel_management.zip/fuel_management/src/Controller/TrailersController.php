<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;

class TrailersController extends AppController {

    public function initialize() {
        parent::initialize();
        $this->loadComponent('Flash');
    }

    public function index() {
        $this->set('trailers', $this->Trailers->find('all'));
    }
    public function form($id = null) {
        $trailerTable = TableRegistry::get("Trailers");
        $trailer = $trailerTable->newEntity();
        if ($this->request->is(['get']) && $id != null) {
            $trailer = $trailerTable->get($id);
        }
        $this->set(compact('trailer'));
    }

    public function save() {
        $trailerTable = TableRegistry::get("Trailers");
        $trailer = $trailerTable->newEntity();
        if ($this->request->is(['post', 'put'])) {
            $data = $this->request->getData();
            $id = $data['id'];

            if ($id != null) {
                $trailer = $trailerTable->get($id);
                $this->Trailers->patchEntity($trailer, $this->request->getData());
            } else {
                $trailerTable->patchEntity($trailer, $this->request->getData());
            }

            if ($trailer->errors()) {
                // print_r($trailer->errors());
                $this->Flash->error(__('Unable to add your trailer.'));
            } else if ($this->Trailers->save($trailer)) {
                $this->Flash->success(__('Your trailer has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
        }
        $this->set(compact('trailer'));
    }

    public function delete($id) {
        $trailer = $this->Trailers->get($id);
        if ($this->Trailers->delete($trailer)) {
            $this->Flash->success(__('The trailer with id: {0} has been deleted.', h($id)));
            return $this->redirect(['action' => 'index']);
        }
    }

}

?>