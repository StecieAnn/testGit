<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;

class VehiclesController extends AppController {

    public function initialize() {
        parent::initialize();
        $this->loadComponent('Flash');
    }
    public function index() {
        $this->set('vehicles', $this->Vehicles->find('all'));
    }

    public function form($id = null) {
        $vehicleTable = TableRegistry::get("Vehicles");
        $vehicle = $vehicleTable->newEntity();
        if ($this->request->is(['get']) && $id != null) {
            $vehicle = $vehicleTable->get($id);
        }
        $this->set(compact('vehicle'));
    }

    public function save() {
        $vehicleTable = TableRegistry::get("Vehicles");
        $vehicle = $vehicleTable->newEntity();
        if ($this->request->is(['post', 'put'])) {
            $data = $this->request->getData();
            $id = $data['id'];

            if ($id != null) {
                $vehicle = $vehicleTable->get($id);
                $this->Vehicles->patchEntity($vehicle, $this->request->getData());
            } else {
                $vehicleTable->patchEntity($vehicle, $this->request->getData());
            }

            if ($vehicle->errors()) {
                // print_r($vehicle->errors());
                $this->Flash->error(__('Unable to add your vehicle.'));
            } else if ($this->Vehicles->save($vehicle)) {
                $this->Flash->success(__('Your vehicle has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
        }
        $this->set(compact('vehicle'));
    }

    public function delete($id) {
        $vehicle = $this->Vehicles->get($id);
        if ($this->Vehicles->delete($vehicle)) {
            $this->Flash->success(__('The vehicle with id: {0} has been deleted.', h($id)));
            return $this->redirect(['action' => 'index']);
        }
    }

}

?>