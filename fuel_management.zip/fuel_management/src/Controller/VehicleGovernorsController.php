<?php

namespace App\Controller;
use App\Controller\AppController;
use Cake\ORM\TableRegistry;

class VehicleGovernorsController extends AppController {

    public function initialize() {
        parent::initialize();
        $this->loadComponent('Flash');
    }

    public function index() {
        $this->set('vehicleGovernors', $this->VehicleGovernors->find('all'));
    }
    public function form($id = null) {
        $vehicleGovernorTable = TableRegistry::get("VehicleGovernors");
        $vehicleGovernor = $vehicleGovernorTable->newEntity();
        if ($this->request->is(['get']) && $id != null) {
            $vehicleGovernor = $vehicleGovernorTable->get($id);
        }
        $this->set(compact('vehicleGovernor'));
    }

    public function save() {
        $vehicleGovernorTable = TableRegistry::get("VehicleGovernors");
        $vehicleGovernor = $vehicleGovernorTable->newEntity();
        if ($this->request->is(['post', 'put'])) {
            $data = $this->request->getData();
            $id = $data['id'];

            if ($id != null) {
                $vehicleGovernor = $vehicleGovernorTable->get($id);
                $this->VehicleGovernors->patchEntity($vehicleGovernor, $this->request->getData());
            } else {
                $vehicleGovernorTable->patchEntity($vehicleGovernor, $this->request->getData());
            }

            if ($vehicleGovernor->errors()) {
                // print_r($vehicleGovernor->errors());
                $this->Flash->error(__('Unable to add your vehicleGovernor.'));
            } else if ($this->VehicleGovernors->save($vehicleGovernor)) {
                $this->Flash->success(__('Your vehicleGovernor has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
        }
        $this->set(compact('vehicleGovernor'));
    }

    public function delete($id) {
        $vehicleGovernor = $this->VehicleGovernors->get($id);
        if ($this->VehicleGovernors->delete($vehicleGovernor)) {
            $this->Flash->success(__('The vehicleGovernor with id: {0} has been deleted.', h($id)));
            return $this->redirect(['action' => 'index']);
        }
    }

}

?>