<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;

class VehicleModelsController extends AppController {

    public function initialize() {
        parent::initialize();
        $this->loadComponent('Flash'); 
    }

    public function index() {
        $this->set('vehicleModels', $this->VehicleModels->find('all'));
    }

    public function form($id = null) {
        $vehicleModelTable = TableRegistry::get("VehicleModels");
        $vehicleModel = $vehicleModelTable->newEntity();
        if ($this->request->is(['get']) && $id != null) {
            $vehicleModel = $vehicleModelTable->get($id);
        }
        $this->set(compact('vehicleModel'));
    }

    public function save() {
        $vehicleModelTable = TableRegistry::get("VehicleModels");
        $vehicleModel = $vehicleModelTable->newEntity();
        if ($this->request->is(['post', 'put'])) {
            $data = $this->request->getData();
            $id = $data['id'];
            if ($id != null) {
                $vehicleModel = $vehicleModelTable->get($id);
                $this->VehicleModels->patchEntity($vehicleModel, $this->request->getData());
            } else {
                $vehicleModelTable->patchEntity($vehicleModel, $this->request->getData());
            }
            if ($vehicleModel->errors()) {
                $this->Flash->error(__('Unable to add your Record.'));
            } else if ($this->VehicleModels->save($vehicleModel)) {
                $this->Flash->success(__('Your Record(s) has been successively saved.'));
                return $this->redirect(['action' => 'index']);
            }
        }
        $this->set(compact('vehicleModel'));
    }

    public function delete($id) {
        $vehicleModel = $this->VehicleModels->get($id);
        if ($this->VehicleModels->delete($vehicleModel)) {
            $this->Flash->success(__('The vehicleModel with id: {0} has been deleted.', h($id)));
            return $this->redirect(['action' => 'index']);
        }
    }

}

?>