<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;

class FuelPurchasesController extends AppController {

    public function initialize() {
        parent::initialize();
        $this->loadComponent('Flash');
    }

    public function index() {
        $this->set('fuelPurchases', $this->FuelPurchases->find('all'));
    }

    public function form($id = null) {
        $fuelPurchasesTable = TableRegistry::get("FuelPurchases");
        $fuelPurchase = $fuelPurchasesTable->newEntity();
        if ($this->request->is(['get']) && $id != null) {
            $fuelPurchase = $fuelPurchasesTable->get($id);
        }
        $this->set(compact('fuelPurchase'));
    }

    public function save() {
        $fuelPurchaseTable = TableRegistry::get("FuelPurchases");
        $fuelPurchase = $fuelPurchaseTable->newEntity();
        if ($this->request->is(['post', 'put'])) {
            $data = $this->request->getData();
            $id = $data['id'];
            if ($id != null) {
                $fuelPurchase = $fuelPurchaseTable->get($id);
                $this->FuelPurchases->patchEntity($fuelPurchase, $this->request->getData());
            } else {
                $fuelPurchaseTable->patchEntity($fuelPurchase, $this->request->getData());
            }
            if ($fuelPurchase->errors()) {
                $this->Flash->error(__('Unable to add your Record.'));
            } else if ($this->FuelPurchases->save($fuelPurchase)) {
                $this->Flash->success(__('Your Record(s) has been successively saved.'));
                return $this->redirect(['action' => 'index']);
            }
        }
        $this->set(compact('fuelPurchase'));
    }

    public function delete($id) {
        $fuelPurchase = $this->FuelPurchases->get($id);
        if ($this->FuelPurchases->delete($fuelPurchase)) {
            $this->Flash->success(__('The fuelPurchases with id: {0} has been deleted.', h($id)));
            return $this->redirect(['action' => 'index']);
        }
    }

}

?>