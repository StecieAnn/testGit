<?php

namespace App\Controller;
use App\Controller\AppController;
use Cake\ORM\TableRegistry;

class VehicleDriverAssignmentsController extends AppController {

    public function initialize() {
        parent::initialize();
        $this->loadComponent('Flash');
    }

    public function index() {
        $this->set('vehicleDriverAssignments', $this->VehicleDriverAssignments->find('all'));
    }
    public function form($id = null) {
        $vehicleDriverAssignmentTable = TableRegistry::get("VehicleDriverAssignments");
        $vehicleDriverAssignment = $vehicleDriverAssignmentTable->newEntity();
        if ($this->request->is(['get']) && $id != null) {
            $vehicleDriverAssignment = $vehicleDriverAssignmentTable->get($id);
        }
        $this->set(compact('vehicleDriverAssignment'));
    }

    public function save() {
        $vehicleDriverAssignmentTable = TableRegistry::get("VehicleDriverAssignments");
        $vehicleDriverAssignment = $vehicleDriverAssignmentTable->newEntity();
        if ($this->request->is(['post', 'put'])) {
            $data = $this->request->getData();
            $id = $data['id'];

            if ($id != null) {
                $vehicleDriverAssignment = $vehicleDriverAssignmentTable->get($id);
                $this->VehicleDriverAssignments->patchEntity($vehicleDriverAssignment, $this->request->getData());
            } else {
                $vehicleDriverAssignmentTable->patchEntity($vehicleDriverAssignment, $this->request->getData());
            }

            if ($vehicleDriverAssignment->errors()) {
                // print_r($vehicleDriverAssignment->errors());
                $this->Flash->error(__('Unable to add your vehicleDriverAssignment.'));
            } else if ($this->VehicleDriverAssignments->save($vehicleDriverAssignment)) {
                $this->Flash->success(__('Your vehicleDriverAssignment has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
        }
        $this->set(compact('vehicleDriverAssignment'));
    }

    public function delete($id) {
        $vehicleDriverAssignment = $this->VehicleDriverAssignments->get($id);
        if ($this->VehicleDriverAssignments->delete($vehicleDriverAssignment)) {
            $this->Flash->success(__('The vehicleDriverAssignment with id: {0} has been deleted.', h($id)));
            return $this->redirect(['action' => 'index']);
        }
    }

}

?>