<?php

namespace App\Controller;
use App\Controller\AppController;
use Cake\ORM\TableRegistry;

class TrailerInsurancesController extends AppController {

    public function initialize() {
        parent::initialize();
        $this->loadComponent('Flash');
    }

    public function index() {
        $this->set('trailerInsurances', $this->TrailerInsurances->find('all'));
    }
    public function form($id = null) {
        $trailerInsuranceTable = TableRegistry::get("TrailerInsurances");
        $trailerInsurance = $trailerInsuranceTable->newEntity();
        if ($this->request->is(['get']) && $id != null) {
            $trailerInsurance = $trailerInsuranceTable->get($id);
        }
        $this->set(compact('trailerInsurance'));
    }

    public function save() {
        $trailerInsuranceTable = TableRegistry::get("TrailerInsurances");
        $trailerInsurance = $trailerInsuranceTable->newEntity();
        if ($this->request->is(['post', 'put'])) {
            $data = $this->request->getData();
            $id = $data['id'];

            if ($id != null) {
                $trailerInsurance = $trailerInsuranceTable->get($id);
                $this->TrailerInsurances->patchEntity($trailerInsurance, $this->request->getData());
            } else {
                $trailerInsuranceTable->patchEntity($trailerInsurance, $this->request->getData());
            }

            if ($trailerInsurance->errors()) {
                //print_r($trailerInsurance->errors());
                $this->Flash->error(__('Unable to add your trailerInsurance.'));
            } else if ($this->TrailerInsurances->save($trailerInsurance)) {
                $this->Flash->success(__('Your trailerInsurance has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
        }
        $this->set(compact('trailerInsurance'));
    }

    public function delete($id) {
        $trailerInsurance = $this->TrailerInsurances->get($id);
        if ($this->TrailerInsurances->delete($trailerInsurance)) {
            $this->Flash->success(__('The trailerInsurance with id: {0} has been deleted.', h($id)));
            return $this->redirect(['action' => 'index']);
        }
    }

}

?>