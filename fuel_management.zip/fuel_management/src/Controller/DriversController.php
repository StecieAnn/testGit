<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;

class DriversController extends AppController {

    public function initialize() {
        parent::initialize();
        $this->loadComponent('Flash');
    }

    public function index() {
        $this->set('drivers', $this->Drivers->find('all'));
    }

    public function form($id = null) {
        $driverTable = TableRegistry::get("Drivers");
        $driver = $driverTable->newEntity();
        if ($this->request->is(['get']) && $id != null) {
            $driver = $driverTable->get($id);
        }
        $this->set(compact('driver'));
    }

    public function save() {
        $driverTable = TableRegistry::get("Drivers");
        $driver = $driverTable->newEntity();
        if ($this->request->is(['post', 'put'])) {
            $data = $this->request->getData();
            $id = $data['id'];
            if ($id != null) {
                $driver = $driverTable->get($id);
                $this->Drivers->patchEntity($driver, $this->request->getData());
            } else {
                $driverTable->patchEntity($driver, $this->request->getData());
            }

            if ($driver->errors()) {
                $this->Flash->error(__('Unable to add your  driver.'));
            } else if ($this->Drivers->save($driver)) {
                $this->Flash->success(__('Your  driver has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
        }
        $this->set(compact(' driver'));
    }

    public function delete($id) {
        $driver = $this->Drivers->get($id);
        if ($this->Drivers->delete($driver)) {
            $this->Flash->success(__('The drivers with id: {0} has been deleted.', h($id)));
            return $this->redirect(['action' => 'index']);
        }
    }

}

?>