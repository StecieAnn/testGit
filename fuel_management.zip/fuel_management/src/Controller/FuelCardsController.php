<?php

namespace App\Controller;
use App\Controller\AppController;
use Cake\ORM\TableRegistry;

class FuelCardsController extends AppController {

    public function initialize() {
        parent::initialize();
        $this->loadComponent('Flash');
    }

    public function index() {
        $this->set('fuelCards', $this->FuelCards->find('all'));
    }
    public function form($id = null) {
        $fuelCardTable = TableRegistry::get("FuelCards");
        $fuelCard = $fuelCardTable->newEntity();
        if ($this->request->is(['get']) && $id != null) {
            $fuelCard = $fuelCardTable->get($id);
        }
        $this->set(compact('fuelCard'));
    }

    public function save() {
        $fuelCardTable = TableRegistry::get("FuelCards");
        $fuelCard = $fuelCardTable->newEntity();
        if ($this->request->is(['post', 'put'])) {
            $data = $this->request->getData();
            $id = $data['id'];

            if ($id != null) {
                $fuelCard = $fuelCardTable->get($id);
                $this->FuelCards->patchEntity($fuelCard, $this->request->getData());
            } else {
                $fuelCardTable->patchEntity($fuelCard, $this->request->getData());
            }

            if ($fuelCard->errors()) {
                // print_r($fuelCard->errors());
                $this->Flash->error(__('Unable to add your fuelCard.'));
            } else if ($this->FuelCards->save($fuelCard)) {
                $this->Flash->success(__('Your fuelCard has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
        }
        $this->set(compact('fuelCard'));
    }

    public function delete($id) {
        $fuelCard = $this->FuelCards->get($id);
        if ($this->FuelCards->delete($fuelCard)) {
            $this->Flash->success(__('The fuelCard with id: {0} has been deleted.', h($id)));
            return $this->redirect(['action' => 'index']);
        }
    }

}

?>