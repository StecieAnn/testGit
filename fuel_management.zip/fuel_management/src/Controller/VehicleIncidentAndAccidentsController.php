<?php

namespace App\Controller;
use App\Controller\AppController;
use Cake\ORM\TableRegistry;

class VehicleIncidentAndAccidentsController extends AppController {

    public function initialize() {
        parent::initialize();
        $this->loadComponent('Flash');
    }

    public function index() {
        $this->set('vehicleIncidentAndAccidents', $this->VehicleIncidentAndAccidents->find('all'));
    }
    public function form($id = null) {
        $vehicleIncidentAndAccidentTable = TableRegistry::get("VehicleIncidentAndAccidents");
        $vehicleIncidentAndAccident = $vehicleIncidentAndAccidentTable->newEntity();
        if ($this->request->is(['get']) && $id != null) {
            $vehicleIncidentAndAccident = $vehicleIncidentAndAccidentTable->get($id);
        }
        $this->set(compact('vehicleIncidentAndAccident'));
    }

    public function save() {
        $vehicleIncidentAndAccidentTable = TableRegistry::get("VehicleIncidentAndAccidents");
        $vehicleIncidentAndAccident = $vehicleIncidentAndAccidentTable->newEntity();
        if ($this->request->is(['post', 'put'])) {
            $data = $this->request->getData();
            $id = $data['id'];

            if ($id != null) {
                $vehicleIncidentAndAccident = $vehicleIncidentAndAccidentTable->get($id);
                $this->VehicleIncidentAndAccidents->patchEntity($vehicleIncidentAndAccident, $this->request->getData());
            } else {
                $vehicleIncidentAndAccidentTable->patchEntity($vehicleIncidentAndAccident, $this->request->getData());
            }

            if ($vehicleIncidentAndAccident->errors()) {
                // print_r($vehicleIncidentAndAccident->errors());
                $this->Flash->error(__('Unable to add your vehicleIncidentAndAccident.'));
            } else if ($this->VehicleIncidentAndAccidents->save($vehicleIncidentAndAccident)) {
                $this->Flash->success(__('Your vehicleIncidentAndAccident has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
        }
        $this->set(compact('vehicleIncidentAndAccident'));
    }

    public function delete($id) {
        $vehicleIncidentAndAccident = $this->VehicleIncidentAndAccidents->get($id);
        if ($this->VehicleIncidentAndAccidents->delete($vehicleIncidentAndAccident)) {
            $this->Flash->success(__('The vehicleIncidentAndAccident with id: {0} has been deleted.', h($id)));
            return $this->redirect(['action' => 'index']);
        }
    }

}

?>