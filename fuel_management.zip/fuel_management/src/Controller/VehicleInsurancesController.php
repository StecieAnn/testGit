<?php

namespace App\Controller;
use App\Controller\AppController;
use Cake\ORM\TableRegistry;

class VehicleInsurancesController extends AppController {

    public function initialize() {
        parent::initialize();
        $this->loadComponent('Flash');
    }

    public function index() {
        $this->set('vehicleInsurances', $this->VehicleInsurances->find('all'));
    }
    public function form($id = null) {
        $vehicleInsuranceTable = TableRegistry::get("VehicleInsurances");
        $vehicleInsurance = $vehicleInsuranceTable->newEntity();
        if ($this->request->is(['get']) && $id != null) {
            $vehicleInsurance = $vehicleInsuranceTable->get($id);
        }
        $this->set(compact('vehicleInsurance'));
    }

    public function save() {
        $vehicleInsuranceTable = TableRegistry::get("VehicleInsurances");
        $vehicleInsurance = $vehicleInsuranceTable->newEntity();
        if ($this->request->is(['post', 'put'])) {
            $data = $this->request->getData();
            $id = $data['id'];

            if ($id != null) {
                $vehicleInsurance = $vehicleInsuranceTable->get($id);
                $this->VehicleInsurances->patchEntity($vehicleInsurance, $this->request->getData());
            } else {
                $vehicleInsuranceTable->patchEntity($vehicleInsurance, $this->request->getData());
            }

            if ($vehicleInsurance->errors()) {
                print_r($vehicleInsurance->errors());
                $this->Flash->error(__('Unable to add your vehicleInsurance.'));
            } else if ($this->VehicleInsurances->save($vehicleInsurance)) {
                $this->Flash->success(__('Your vehicleInsurance has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
        }
        $this->set(compact('vehicleInsurance'));
    }

    public function delete($id) {
        $vehicleInsurance = $this->VehicleInsurances->get($id);
        if ($this->VehicleInsurances->delete($vehicleInsurance)) {
            $this->Flash->success(__('The vehicleInsurance with id: {0} has been deleted.', h($id)));
            return $this->redirect(['action' => 'index']);
        }
    }

}

?>