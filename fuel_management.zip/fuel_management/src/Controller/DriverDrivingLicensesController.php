<?php

namespace App\Controller;
use App\Controller\AppController;
use Cake\ORM\TableRegistry;

class DriverDrivingLicensesController extends AppController {

    public function initialize() {
        parent::initialize();
        $this->loadComponent('Flash');
    }

    public function index() {
        $this->set('driverDrivingLicenses', $this->DriverDrivingLicenses->find('all'));
    }
    public function form($id = null) {
        $driverDrivingLicenseTable = TableRegistry::get("DriverDrivingLicenses");
        $driverDrivingLicense = $driverDrivingLicenseTable->newEntity();
        if ($this->request->is(['get']) && $id != null) {
            $driverDrivingLicense = $driverDrivingLicenseTable->get($id);
        }
        $this->set(compact('driverDrivingLicense'));
    }

    public function save() {
        $driverDrivingLicenseTable = TableRegistry::get("DriverDrivingLicenses");
        $driverDrivingLicense = $driverDrivingLicenseTable->newEntity();
        if ($this->request->is(['post', 'put'])) {
            $data = $this->request->getData();
            $id = $data['id'];

            if ($id != null) {
                $driverDrivingLicense = $driverDrivingLicenseTable->get($id);
                $this->DriverDrivingLicenses->patchEntity($driverDrivingLicense, $this->request->getData());
            } else {
                $driverDrivingLicenseTable->patchEntity($driverDrivingLicense, $this->request->getData());
            }

            if ($driverDrivingLicense->errors()) {
                $this->Flash->error(__('Unable to add Driver Driving License.'));
            } else if ($this->DriverDrivingLicenses->save($driverDrivingLicense)) {
                $this->Flash->success(__('Driver Driving License has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
        }
        $this->set(compact('driverDrivingLicense'));
    }

    public function delete($id) {
        $driverDrivingLicense = $this->DriverDrivingLicenses->get($id);
        if ($this->DriverDrivingLicenses->delete($driverDrivingLicense)) {
            $this->Flash->success(__('The driverDrivingLicense with id: {0} has been deleted.', h($id)));
            return $this->redirect(['action' => 'index']);
        }
    }

}

?>