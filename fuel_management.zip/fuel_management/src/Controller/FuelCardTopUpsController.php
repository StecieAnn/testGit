<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;

class FuelCardTopUpsController extends AppController {

    public function initialize() {
        parent::initialize();
        $this->loadComponent('Flash');
    }

    public function index() {
        $this->set('fuelCardTopUps', $this->FuelCardTopUps->find('all'));
    }

    public function form($id = null) {
        $fuelCardTopUpTable = TableRegistry::get("FuelCardTopUps");
        $fuelCardTopUp = $fuelCardTopUpTable->newEntity();
        if ($this->request->is(['get']) && $id != null) {
            $fuelCardTopUp = $fuelCardTopUpTable->get($id);
        }
        $this->set(compact('fuelCardTopUp'));
    }

    public function save() {
        $fuelCardTopUpTable = TableRegistry::get("FuelCardTopUps");
        $fuelCardTopUp = $fuelCardTopUpTable->newEntity();
        if ($this->request->is(['post', 'put'])) {
            $data = $this->request->getData();
            $id = $data['id'];

            if ($id != null) {
                $fuelCardTopUp = $fuelCardTopUpTable->get($id);
                $this->FuelCardTopUps->patchEntity($fuelCardTopUp, $this->request->getData());
            } else {
                $fuelCardTopUpTable->patchEntity($fuelCardTopUp, $this->request->getData());
            }
            if ($fuelCardTopUp->errors()) {
                $this->Flash->error(__('Unable to add your fuelCardTopUp.'));
            } else if ($this->FuelCardTopUps->save($fuelCardTopUp)) {
                $this->Flash->success(__('Your fuelCardTopUp has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
        }
        $this->set(compact('fuelCardTopUp'));
    }

    public function delete($id) {
        $fuelCardTopUp = $this->FuelCardTopUps->get($id);
        if ($this->FuelCardTopUps->delete($fuelCardTopUp)) {
            $this->Flash->success(__('The fuelCardTopUp with id: {0} has been deleted.', h($id)));
            return $this->redirect(['action' => 'index']);
        }
    }

}

?>