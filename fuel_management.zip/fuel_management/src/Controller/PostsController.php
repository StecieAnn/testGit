<?php


namespace App\Controller;
use App\Controller\AppController;

class PostsController extends AppController
{
		var $name = 'Posts';

	function search() {
		// the page we will redirect to
		$url['action'] = 'index';
		
		// build a URL will all the search elements in it
		// the resulting URL will be 
		// example.com/cake/posts/index/Search.keywords:mykeyword/Search.tag_id:3
		foreach ($this->data as $k=>$v){ 
			foreach ($v as $kk=>$vv){ 
				if ($vv) {
					$url[$k.'.'.$kk]=$vv; 
				}
			} 
		}

		// redirect the user to the url
		$this->redirect($url, null, true);
	}
	public function initialize()
    {
        parent::initialize();
        $this->loadComponent('Flash'); // Include the FlashComponent
    }

   /* public function index()
    {
       $this->set ('posts',$this->Posts->find('all'));
       // $this->set(compact('posts'));
    }*/
	
	
	 public function index(){
	$this->set ('posts',$this->Posts->find('all'));		 
		
		$title = array();
	

		//
		// filter by title
		//
		if(isset($this->passedArgs['Search.title'])) {
			$this->paginate['conditions'][]['Post.title LIKE'] = str_replace('*','%',$this->passedArgs['Search.title']);
			$this->data['Search']['title'] = $this->passedArgs['Search.title'];
			$title[] = __('Title',true).': '.$this->passedArgs['Search.title'];
		}
	 }
	
	
	public function add()
	{
		$post = $this->Posts->newEntity();
       if ($this->request->is('post')) {
			
            $post = $this->Posts->patchEntity($post, $this->request->getData());
			
			if ($this->Posts->save($post)) {

                $this->Flash->success(__('Your post added successfully.',['key'=>'message']));

			return $this->redirect(['action' => 'index']);

            }

            $this->Flash->error(__('Unable to add your post.'));

        }
		$this->set('post', $post);
	}
	public function view($id=Null)
    {

        $posts = $this->Posts->get($id);

        $this->set('post',$posts);

    }
	
	public function edit($id = null)
    {

        $post = $this->Posts->get($id);

        if ($this->request->is(['post', 'put'])) {

            $this->Posts->patchEntity($post, $this->request->data);

            if ($this->Posts->save($post)) {

                $this->Flash->success(__('Your post has been updated.'));

                return $this->redirect(['action' => 'index']);

            }

            $this->Flash->error(__('Unable to update your post.'));

        }    

        $this->set('post', $post);

    }


    public function delete($id)

    {

		
        $post = $this->Posts->get($id);

        if ($this->Posts->delete($post)) {

            $this->Flash->success(__('The post with id: {0} has been deleted.', h($id)));

            return $this->redirect(['action' => 'index']);

        }

    }
	

}
?>