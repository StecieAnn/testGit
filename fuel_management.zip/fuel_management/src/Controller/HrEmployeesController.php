<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;

class HrEmployeesController extends AppController {

    public function initialize() {
        parent::initialize();
        $this->loadComponent('Flash');
    }

    public function index() {
        $this->set('hrEmployees', $this->HrEmployees->find('all'));
    }
    public function form($id = null) {
        $hrEmployeeTable = TableRegistry::get("HrEmployees");
        $hrEmployee = $hrEmployeeTable->newEntity();
        if ($this->request->is(['get']) && $id != null) {
            $hrEmployee = $hrEmployeeTable->get($id);
        }
        $this->set(compact('hrEmployee'));
    }

    public function save() {
        $hrEmployeeTable = TableRegistry::get("HrEmployees");
        $hrEmployee = $hrEmployeeTable->newEntity();
        if ($this->request->is(['post', 'put'])) {
            $data = $this->request->getData();
            $id = $data['id'];

            if ($id != null) {
                $hrEmployee = $hrEmployeeTable->get($id);
                $this->HrEmployees->patchEntity($hrEmployee, $this->request->getData());
            } else {
                $hrEmployeeTable->patchEntity($hrEmployee, $this->request->getData());
            }

            if ($hrEmployee->errors()) {
                 print_r($hrEmployee->errors());
                $this->Flash->error(__('Unable to add your hrEmployee.'));
            } else if ($this->HrEmployees->save($hrEmployee)) {
                $this->Flash->success(__('Your hrEmployee has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
        }
        $this->set(compact('hrEmployee'));
    }

    public function delete($id) {
        $hrEmployee = $this->HrEmployees->get($id);
        if ($this->HrEmployees->delete($hrEmployee)) {
            $this->Flash->success(__('The hrEmployee with id: {0} has been deleted.', h($id)));
            return $this->redirect(['action' => 'index']);
        }
    }

}

?>