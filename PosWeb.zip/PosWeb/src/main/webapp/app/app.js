novia.selectedRecord = {};
/*
novia.loadMenu = function(){
    network.get("./Users/", {}, function(data){
        if(data!==undefined){
            if(data.user!==undefined){
                novia.displayUserInfo(data.user);               
            }
            if(data.permissions!==undefined){
                novia.displayModuleMenu(data.permissions);                
            }
        }
    }, true);
};
*/
novia.showHelp = function(help){
  if(help.length>0){
      var text = '<div class="well"><div class="list-group">';
      for (var i = help.length - 1; i >= 0; i--){
        text+='<a href="javascript:void(0)" class="list-group-item">'+help[i]+'</a>';//
      };
      text+='</div></div>';
      novia.showAlert(text);
  }  
};

novia.displayUserInfo = function(info){
    q("#display_name").html(info.display_name+" ");
};

novia.package=null;
novia.class=null;
novia.classText = null;
novia.loadJS=function(){
    network.get(network.rootpath+"/loadJS/"+novia.package+"$"+novia.class, {}, function(data){
        if(data!==undefined){
            var mainContent=q("#mainContent");
            mainContent.empty().html(data);
        }
    }, false);
};

novia.loadHTML=function(callBack){
    novia.createModalWindow(network.rootpath+"/loadHTML/"+novia.package+"$"+novia.class,novia.classText,callBack);
};

novia.afterFormInit=function(formObject){
    novia.populateForm(formObject,novia.selectedRecord);
    try {
        var func = eval(formId+"_after_fill");
        if(jQuery.isFunction(func)) {
            func(formObject);
        }                  
    } 
    catch (e){}
};

novia.loadHTMLNoModal=function(callBack){
    network.get(network.rootpath+"/loadHTML/"+novia.package+"$"+novia.class, {}, function(html) {
        var mainContent=q("#mainContent");
        mainContent.empty().html(html);
        setTimeout(function(){
            var func = eval(callBack);
            if(jQuery.isFunction(func)) {
                func(html);
            }  
        },200);
    });
};

novia.displayModuleMenu = function(menu){
    //https://bootsnipp.com/snippets/OVVM
    var mainContent=q("#mainContent");
    var m='';
    if(menu.length>0){
        var currentMenu="";
        m+='<div class="panel panel-default">';
        for(i=0; i<menu.length; i++){
            if(i==0){
                currentMenu=menu[i].menuid;
            }
            
            if(i==0||currentMenu!=menu[i].menuid){
                currentMenu=menu[i].menuid;
                if(i>0){
                    m+='</table>';
                    m+='</div>';
                    m+='</div>';                    
                }
                m+='<div class="panel-heading">';
                m+='<h4 class="panel-title">';
                m+='<a data-toggle="collapse" data-parent="#accordion" href="#'+currentMenu+'"><span class="glyphicon glyphicon-folder-close"></span>'+menu[i].menutext+'</a>';
                m+='</h4>';
                m+='</div>';
                var collapsein = (i==0)?" in":"";
                m+='<div id="'+currentMenu+'" class="panel-collapse collapse '+collapsein+'">';
                m+='<div class="panel-body">';
                m+='<table class="table">';                
                m+='<tr class="menuItem"><td><span class="glyphicon glyphicon-chevron-right text-primary"></span><a menuid="'+menu[i].menuid+'" unitid="'+menu[i].unitid+'" href="javascript:void(0);">'+menu[i].unit+'</a></td></tr>';
            }
            else{
                
                m+='<tr class="menuItem"><td><span class="glyphicon glyphicon-chevron-right text-primary"></span><a menuid="'+menu[i].menuid+'" unitid="'+menu[i].unitid+'" href="javascript:void(0);">'+menu[i].unit+'</a></td></tr>';
                
            }
            if(i==(menu.length-1)){
                    m+='</table>';
                    m+='</div></div></div>'; 
            }
            
            q("#accordion").html(m).find('.menuItem').click(function() {
                var moduleComponent = q(this).find('a').attr("menuid");
                var moduleUnit = q(this).find('a').attr("unitid");
                var moduleUnitText = q(this).find('a').text();
                novia.package=moduleComponent;
                novia.class=moduleUnit;
                novia.classText=moduleUnitText;
                novia.loadJS();
            });
        }
        var r='<div class="panel panel-default">'; 
            r+='<div class="panel-heading">'; 
            r+='<h4 class="panel-title" id="appReports">'; 
            r+='<a data-toggle="collapse" data-parent="#accordion" href="#collapseFour"><span class="glyphicon glyphicon-file">'; 
            r+='</span>Reports</a>'; 
            r+='</h4>'; 
            r+='</div>';
            r+='</div>'; 
        q("#accordion").append(r).find('#appReports').click(function() {
            novia.package='reports';
            novia.class='viewReport';
            novia.classText='Module Reports';
            network.get(network.rootpath+"/loadHTML/reports$viewReport",'Module Reports',function (htm) {
              q("#mainContent").empty().html(htm);
            });
        });
    }
};
novia.createMainContentGrid = function(obj) {
    var mainContent=q("#mainContent"); 
    network.get(network.rootpath+"/loadHTML/grid$list", {}, function(htmlData){
        mainContent.empty().html(htmlData);
        setTimeout(function(){
           initGrid(obj); 
        },200);
    }, false);
};

//LOAD DASHBOARD
network.get("dashboard", {}, function(htmlData){
	var mainContent=q("#mainContent"); 
	mainContent.empty().html(htmlData);
}, false);

//novia.loadMenu();