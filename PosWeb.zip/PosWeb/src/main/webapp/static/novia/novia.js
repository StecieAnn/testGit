var novia={};
novia.appName = "Novia Sacco Soft Suite";
novia.vueFormViewModel = function(objForm,component_name,extraData,extraMethods) {// ,selectfields selectfields syntax {select_id:value,selectobj:value,selectarrayitems:value}
    var defaults = {};
    if(objForm!==null && objForm !== undefined){
        jQuery.each(objForm.find("input,select,textarea"), function() {
            switch (jQuery(this).prop('tagName').toLowerCase()) {
                case "input":{defaults[jQuery(this).attr("name")] = "";break;}
                case "select":{defaults[jQuery(this).attr("name")] = 0;break;}
                case "textarea":{defaults[jQuery(this).attr("name")] = "";break;}
            }
        });        
    }
    
    extraMethods.reset=function(){
        // Fetch the initialState object locally, so we do not have to call the function again
        var initialData = defaults;
        // Iterate through the props
        for (var prop in initialData) {
            // Reset the prop locally.
            this[prop] = "";//initialData[prop];
        }
    };
    
    extraMethods.load=function(json){
        if(json!=null && json!==undefined){
            for (var property in json) {
                if (json.hasOwnProperty(property)) {
                    defaults[property] = json[property];
                }
            }
        }
    };
    
    extraMethods.json=function(json){
        return defaults;
    };    
    
    if(extraData!=null && extraData!==undefined){
        for (var property in extraData) {
            if (extraData.hasOwnProperty(property)) {
                defaults[property] = extraData[property];
            }
        }
    }    
    var cc = Vue.component(component_name, {
      data: function() {
        return defaults;
      },
      methods: extraMethods,
    });
    new cc().init(); 
    app = new Vue({
        el: '#'+objForm.attr("id")
    });
    return app;
};






novia.createTable = function(gridName,gridURL,cols, onEditCallBack) {   
    if (w2ui[gridName]) {
        w2ui[gridName].destroy();
    }
    var targetDiv = jQuery("#" + gridName); //.find("." + gridName);
    var currentw2grid = targetDiv.w2grid({
        name: gridName,
        multiSelect: false,
        columns: cols,
        show: {
            header: false,
            footer: false,
            toolbar: true,
            lineNumbers: true,
            toolbarSearch: true,
            //footer : true,
            //toolbarEdit: true ,
            lineNumbers: true,
            //selectColumn: true
        },
        recid: 'id',
        records: [],
        onSearch: function(target, eventData) {
            getGridData(jQuery.trim(eventData.searchValue));
        },
        toolbar: {
            onClick: function(target, eventData) {
                //alert(target);
                if (target == 'w2ui-reload') {
                    onSearchCallBack(jQuery.trim(eventData.searchValue));
                }
            }
        },

    });
    
    var getGridData=function(st){
        w2ui[gridName].clear();
        network.get(network.basepath + gridURL+"/"+st,"",function(data){
            if(data!==null && data!==undefined && data.length>0){
                jQuery.each(data, function(i, elem) {
                    data[i].recid = data[i].id;
                });
                w2ui[gridName].clear();
                w2ui[gridName].add(data);   
            }
        },true);
    };    
    
    getGridData(" ");
    currentw2grid.on('select', function(event) {
        //novia.w2gridactions(obj, gridName, event.recid);
        var rowData = currentw2grid.get(event.recid, false);
        onEditCallBack(rowData);
    });
    currentw2grid.on('unselect', function(event) {
        //console.log(event);
        //novia.w2gridactions(obj, gridName, 0);
    });
    currentw2grid.on('click', function(event) {
        var grid = this;
        event.onComplete = function() {
            var sel = grid.getSelection();
            if (sel.length > 0) {
                //Edit
                //var rowData = currentw2grid.get(event.recid, false);
                //onEditCallBack(rowData);
                //obj.rowData = rowData;
                //novia.w2gridactions(obj, gridName, event.recid);
            } else {
                //novia.w2gridactions(obj, gridName, 0);
                //obj.rowData = null;
               currentw2grid.selectNone();
            }
        };
    });
    //novia.w2gridactions(obj, gridName, 0);
    return currentw2grid;
};





















var network = {};
network.basepath = "./";
network.ajax = function(uri, method, data, datatype, callback) {
    var callbackfunc = null;
    try {
        callbackfunc = eval(callback);
        if (!jQuery.isFunction(callbackfunc)) {
            alert("Ajax Requests With no Callbacks not allowed! Hakuna kurusha mawe hapa!");
            return;
        }
    } catch (e) { alert("Ajax Requests Not Understood!" + e.message); return; }

    /*
     contentType: 'application/x-www-form-urlencoded; charset=UTF-8' //default
     //or choose from one below
     contentType: 'application/atom+xml' //Atom
     contentType: 'text/css' //CSS
     contentType: 'text/javascript' //JavaScript
     contentType: 'image/jpeg' //JPEG Image
     contentType: 'application/json' //JSON
     contentType: 'application/pdf' //PDF
     contentType: 'application/rss+xml; charset=ISO-8859-1' //RSS
     contentType: 'text/plain' //Text (Plain)
     contentType: 'text/xml' //XML
     */

    var contenttype = 'text/plain';
    switch (datatype) { //https://www.sitepoint.com/5-jquery-ajax-examples/
        case 'atom':
            {
                contenttype = 'application/atom+xml';
                break;
            }
        case 'css':
            {
                contenttype = 'text/css';
                break;
            }
        case 'javascript':
            {
                contenttype = 'text/javascript';
                break;
            }
        case 'image':
            {
                contenttype = 'image/jpeg';
                break;
            }
        case 'json':
            {
                contenttype = 'application/json; charset=utf-8';
                break;
            }
        case 'pdf':
            {
                contenttype = 'application/pdf';
                break;
            }
        case 'rss':
            {
                contenttype = 'application/rss+xml';
                break;
            }
        case 'plain':
            {
                contenttype = 'text/plain; charset=utf-8';
                break;
            }
        case 'xml':
            {
                contenttype = 'application/xml,text/xml; charset=utf-8';
                break;
            }
        default:
            {
                contenttype = 'application/x-www-form-urlencoded; charset=UTF-8';
                break;
            }
    }
    var options = {};
    options.url = uri;
    options.type = method;
    options.dataType = datatype;
    if (options.dataType == 'xml') {
        options.crossDomain = true;
        options.cache = false;
        options.async = true;
    }
    options.contentType = contenttype;
    if (datatype === 'json' || datatype == 'jsonp') {
        data = JSON.stringify(data);
    }
    options.data = data;
    options.beforeSend = function(xhr) {
        // xhr.setRequestHeader("custom_header", "value");
    };
    options.headers = {
        /*
        "Accept": "text/plain; charset=utf-8",         
        "Content-Type": "text/plain; charset=utf-8"
        */
    };

    var jqXHR = jQuery.ajax(options).done(function(responsedata, status, jqXHR) {
        /*
         if (typeof(responsedata) === "object") {
            return;
         }
         */
        callbackfunc(responsedata);
    }).fail(function(jqXHR, status, err) {
        console.log(err);
        /*
        var error="";
        try{
            error=JSON.parse(jqXHR.responseText);
            BootstrapDialog.alert("Error : " + error.error+" </br>Message : " + error.message+"</br><textarea style='width:100%; height:auto; resize:none;' name='errors' readonly='readonly'>"+jqXHR.responseText+"</textarea>");//);
        }
        catch(e){
            error=jqXHR.responseText;
            BootstrapDialog.alert(error);
        }
        */
        callback(null);
    }).always(function() {
        //"Promise completion callback. Usually indicates that ajax request is complete.";
    });
};

network.upload = function(uri, formData, callback, isjson) {
    //Keenly check :   http://hayageek.com/jquery-ajax-form-submit/
    jQuery.ajax({
        url: network.basepath + uri,
        type: 'POST',
        data: formData,
        mimeType: "multipart/form-data",
        async: false,
        cache: false,
        contentType: false,
        processData: false,
        success: callback(returndata),
        error: function(jqXHR, textStatus, errorThrown) {
            console.log(errorThrown);
            callback(null);
        }
    });
};

network.post = function(path, data, callback, isjson) {
    var datatype = (isjson) ? "json" : "html"; //network.basepath+
    network.ajax(network.basepath + path, "post", data, datatype, callback); //network.ajax=function(uri,method,data,datatype,callback)   
};

network.get = function(path, data, callback, isjson) {
    var datatype = (isjson) ? "json" : "html"; //network.basepath+
    network.ajax(network.basepath + path, "get", data, datatype, callback); //network.ajax=function(uri,method,data,datatype,callback)   
};

network.getScript = function(path, onLoadCallback) {
    //var datatype = (isjson) ? "json" : "html"; //network.basepath+
    //network.ajax(path, "get", data, datatype, callback); //network.ajax=function(uri,method,data,datatype,callback)  
    jQuery.getScript(network.basepath + "load/script/?path=" + path).done(function() {
            try { var func = eval(onLoadCallback); if (jQuery.isFunction(func)) { func(); } } catch (e) {}
        })
        .fail(function(jqXHR, status, err) {
            //if(jqXHR.responseText===""||jqXHR.responseText===undefined){jqXHR.responseText="Request Failed! Please Try Again.";}
            //BootstrapDialog.alert(err + "  " + jqXHR.responseText);
            callback(undefined);
        });
};

network.getHTML = function(path,displayObject) {
    network.ajax(network.basepath + path, "get", {}, "html", function(htm)
    {
        jQuery("#"+displayObject).html(htm);
    }); //network.ajax=function(uri,method,data,datatype,callback)   
};