package ke.novia.dao.purchase;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ke.novia.dao.BaseRepository;
import ke.novia.models.purchase.PurchaseReceiptItemModel;

public interface PurchaseReceiptItemDao extends BaseRepository<PurchaseReceiptItemModel,Long> {	
	@Query("SELECT t FROM PurchaseReceiptItemModel t where t.stockItemCategory.description = :stockItemCategory ")
   public List<PurchaseReceiptItemModel>findBystockItemCategory(@Param("stockItemCategory") String stockItemCategory, Pageable pageable);
}

