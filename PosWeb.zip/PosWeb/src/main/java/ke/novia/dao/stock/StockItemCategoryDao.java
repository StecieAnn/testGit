package ke.novia.dao.stock;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ke.novia.dao.BaseRepository;
import ke.novia.models.stock.StockItemCategoryModel;

public interface StockItemCategoryDao extends BaseRepository<StockItemCategoryModel,Long> {	
	@Query("SELECT s FROM StockItemCategoryModel s WHERE s.description LIKE :query% ORDER BY s.description DESC")
    public List<StockItemCategoryModel> findBydescription(@Param("query") String LoanProduct, Pageable pageable);
}
