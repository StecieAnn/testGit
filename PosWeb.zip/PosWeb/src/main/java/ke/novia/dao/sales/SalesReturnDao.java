package ke.novia.dao.sales;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import ke.novia.dao.BaseRepository;
import ke.novia.models.sales.SalesReturnModel;


public interface SalesReturnDao extends BaseRepository<SalesReturnModel,Long> {	
	@Query("SELECT s FROM SalesReturnModel s WHERE s.customer.customerName=:customer")
    public List<SalesReturnModel> findBycustomer(@Param("customer") String customer, Pageable pageable);
}

