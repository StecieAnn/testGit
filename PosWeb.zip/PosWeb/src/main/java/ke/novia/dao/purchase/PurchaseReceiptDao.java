package ke.novia.dao.purchase;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import ke.novia.dao.BaseRepository;
import ke.novia.models.purchase.PurchaseReceiptModel;




public interface PurchaseReceiptDao extends BaseRepository<PurchaseReceiptModel,Long> {	
	//@Query("SELECT t FROM PurchaseReceiptModel t WHERE t.supplier.supplierName= :supplier")
  // public List<PurchaseReceiptModel> findBysupplier(@Param("supplier") String supplier, Pageable pageable);
	@Query("SELECT s FROM PurchaseReceiptModel s WHERE s.comment LIKE :query% ORDER BY s.comment DESC")
    public List<PurchaseReceiptModel> findBycomment(@Param("query") String comment, Pageable pageable);
}
