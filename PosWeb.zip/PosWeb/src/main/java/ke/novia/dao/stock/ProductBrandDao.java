package ke.novia.dao.stock;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ke.novia.dao.BaseRepository;
import ke.novia.models.stock.ProductBrandModel;

public interface ProductBrandDao extends BaseRepository<ProductBrandModel,Long> {	
	@Query("SELECT s FROM ProductBrandModel s WHERE s.description LIKE :query% ORDER BY s.description DESC")
    public List<ProductBrandModel> findBydescription(@Param("query") String description, Pageable pageable);
}

//http://recursivechaos.com/blog/spring-boot-jpa-mysql/