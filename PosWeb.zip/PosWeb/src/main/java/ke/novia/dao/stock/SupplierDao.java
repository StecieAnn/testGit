package ke.novia.dao.stock;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ke.novia.dao.BaseRepository;
import ke.novia.models.stock.SupplierModel;

public interface SupplierDao extends BaseRepository<SupplierModel,Long> {	
	@Query("SELECT s FROM SupplierModel s WHERE s.supplierName LIKE :query% ORDER BY s.supplierName DESC")
    public List<SupplierModel> findBysupplierName(@Param("query") String supplierName, Pageable pageable);

}

