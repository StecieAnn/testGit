package ke.novia.dao.stock;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ke.novia.dao.BaseRepository;
import ke.novia.models.stock.ProductTypeModel;

public interface ProductTypeDao extends BaseRepository<ProductTypeModel,Long> {	
		@Query("SELECT s FROM ProductTypeModel s WHERE s.description LIKE :query% ORDER BY s.description DESC")
	    public List<ProductTypeModel> findBydescription(@Param("query") String LoanProduct, Pageable pageable);
}
