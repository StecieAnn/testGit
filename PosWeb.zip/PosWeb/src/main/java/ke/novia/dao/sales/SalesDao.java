package ke.novia.dao.sales;

import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import ke.novia.dao.BaseRepository;
import ke.novia.models.sales.SalesModel;


public interface SalesDao extends BaseRepository<SalesModel,Long> {	
	@Query("SELECT s FROM SalesModel s WHERE s.stockItem.displayName=:stockItem")
    public List<SalesModel> findBystockItem(@Param("stockItem") String stockItem, Pageable pageable);
	
	@Modifying 
	@Transactional
	@Query("UPDATE SalesModel s SET s.quantity=s.quantity-:quantity WHERE s.id= :salesId")
	public void decrementQuantity (@Param("salesId") long id,@Param("quantity") double quantity);
}