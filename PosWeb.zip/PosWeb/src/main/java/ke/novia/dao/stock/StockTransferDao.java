package ke.novia.dao.stock;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import ke.novia.dao.BaseRepository;
import ke.novia.models.stock.StockTransferModel;

public interface StockTransferDao extends BaseRepository<StockTransferModel,Long> {	
	
	@Query("SELECT t FROM StockTransferModel t WHERE t.stockItem.displayName=:stockItem")
    public List<StockTransferModel> findBystockItem(@Param("stockItem") String stockItem, Pageable pageable);

	}

