package ke.novia.dao.sales;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ke.novia.dao.BaseRepository;
import ke.novia.models.sales.PaymentModeModel;

public interface PaymentModeDao extends BaseRepository<PaymentModeModel,Long> {	
	@Query("SELECT s FROM PaymentModeModel s WHERE s.description LIKE :query% ORDER BY s.description DESC")
    public List<PaymentModeModel> findBydescription(@Param("query") String description, Pageable pageable);
}
