package ke.novia.dao.sales;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ke.novia.dao.BaseRepository;
import ke.novia.models.sales.SalesTaxModel;

public interface SalesTaxDao extends BaseRepository<SalesTaxModel,Long> {	
	@Query("SELECT s FROM SalesTaxModel s WHERE s.taxName LIKE :query% ORDER BY s.taxName DESC")
    public List<SalesTaxModel> findBytaxName(@Param("query") String taxName, Pageable pageable);
}

