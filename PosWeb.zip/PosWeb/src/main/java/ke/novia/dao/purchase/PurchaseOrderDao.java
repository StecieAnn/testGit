package ke.novia.dao.purchase;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ke.novia.dao.BaseRepository;
import ke.novia.models.purchase.PurchaseOrderModel;

public interface PurchaseOrderDao extends BaseRepository<PurchaseOrderModel,Long> {	
	@Query("SELECT s FROM PurchaseOrderModel s WHERE s.orderNumber LIKE :query% ORDER BY s.orderNumber DESC")
    public List<PurchaseOrderModel> findByorderNumber(@Param("query") String orderNumber, Pageable pageable);
}

