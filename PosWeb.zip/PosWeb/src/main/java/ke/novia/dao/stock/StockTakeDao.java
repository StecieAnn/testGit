package ke.novia.dao.stock;



import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import ke.novia.dao.BaseRepository;
import ke.novia.models.stock.StockTakeModel;


public interface StockTakeDao extends BaseRepository<StockTakeModel,Long> {	

	@Query("SELECT t FROM StockTakeModel t where t.stockItem.displayName = :stockItem")
	public List<StockTakeModel> findBystockItem(@Param("stockItem") String stockItem, Pageable pageable);

	
}


                                                