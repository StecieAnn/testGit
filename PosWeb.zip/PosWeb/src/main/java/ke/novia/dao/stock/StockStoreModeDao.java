package ke.novia.dao.stock;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ke.novia.dao.BaseRepository;
import ke.novia.models.stock.StockStoreModeModel;

public interface StockStoreModeDao extends BaseRepository<StockStoreModeModel,Long> {	
	@Query("SELECT t FROM StockStoreModeModel t WHERE t.description LIKE :query% ORDER BY t.description DESC")
    public List<StockStoreModeModel> findBydescription(@Param("query") String LoanProduct, Pageable pageable);
}
