package ke.novia.dao.stock;



import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import ke.novia.dao.BaseRepository;
import ke.novia.models.stock.ConsumerStoreModel;



public interface ConsumerStoreDao extends BaseRepository<ConsumerStoreModel,Long> {	
	@Query("SELECT t FROM ConsumerStoreModel t where t.stockItem.displayName = :stockItem ")
	public List<ConsumerStoreModel> findBystockItem(@Param("stockItem") String stockItem, Pageable pageable);
}
