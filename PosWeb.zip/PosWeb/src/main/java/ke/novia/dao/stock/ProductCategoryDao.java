package ke.novia.dao.stock;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ke.novia.dao.BaseRepository;
import ke.novia.models.stock.ProductCategoryModel;

public interface ProductCategoryDao extends BaseRepository<ProductCategoryModel,Long> {	
	@Query("SELECT s FROM ProductCategoryModel s WHERE s.description LIKE %:query% ORDER BY s.id DESC")
    public List<ProductCategoryModel> findBydescription(@Param("query") String LoanProduct, Pageable pageable);
}
//http://recursivechaos.com/blog/spring-boot-jpa-mysql/