package ke.novia.dao.stock;

import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import ke.novia.dao.BaseRepository;
import ke.novia.models.stock.ProductModel;

public interface ProductDao extends BaseRepository<ProductModel,Long> {	
	@Query("SELECT s FROM ProductModel s WHERE s.displayName LIKE :query% ORDER BY s.displayName DESC")
    public List<ProductModel> findBydisplayName(@Param("query") String displayName, Pageable pageable);
	
	@Modifying
	@Transactional
	@Query("UPDATE ProductModel s SET s.onHandQuantity=s.onHandQuantity+:quantity WHERE s.id = :productId")
    public void incrementStock(@Param("productId") long id,@Param("quantity") double quantity);
	
	@Modifying
	@Transactional
	@Query("UPDATE ProductModel s SET s.onHandQuantity=s.onHandQuantity-:quantity WHERE s.id= :productId")
	public void decrementStock (@Param("productId") long id,@Param("quantity") double quantity);
	
	@Modifying
	@Transactional
	@Query("UPDATE ProductModel t SET t.lastStockTakeQuantity=:quantity WHERE t.id= :productId")
	public void incrementQuantity(@Param("productId") long id,@Param("quantity") double quantity);

}
