 package ke.novia.mvvm.purchase;

import java.util.HashMap;
import java.util.Map;
import org.zkoss.bind.annotation.BindingParam;
import org.zkoss.bind.annotation.Command;
import org.zkoss.bind.annotation.ContextParam;
import org.zkoss.bind.annotation.ContextType;
import org.zkoss.bind.annotation.Init;
import org.zkoss.bind.annotation.NotifyChange;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zk.ui.select.annotation.WireVariable;
import org.zkoss.zul.ListModel;
import org.zkoss.zul.ListModelList;
import ke.novia.models.purchase.PurchaseOrderModel;
import ke.novia.models.purchase.PurchaseReceiptModel;
import ke.novia.models.sales.PaymentModeModel;
import ke.novia.models.stock.SupplierModel;
import ke.novia.services.purchase.PurchaseOrderService;
import ke.novia.services.purchase.PurchaseReceiptService;
import ke.novia.services.sales.PaymentModeService;
import ke.novia.services.stock.SupplierService;
import lombok.Getter;
import lombok.Setter;

@VariableResolver(org.zkoss.zkplus.spring.DelegatingVariableResolver.class)
public class PurchaseReceiptViewModel {
	
	@WireVariable
	PurchaseReceiptService purchaseReceiptService;
	
	@WireVariable
	SupplierService supplierService;
	
	@WireVariable
	PurchaseOrderService purchaseOrderService;
	
	@WireVariable
	PaymentModeService paymentModeService;
	
	
	private  @Getter @Setter String dateformat;
	
	//Form variable
	private @Getter @Setter PurchaseReceiptModel receipt;
	//category getter and setter

	//Product Supplier
	private ListModel<SupplierModel> sups = new ListModelList<>();
	public ListModel<SupplierModel> getSups(){		
	return sups;
	}

	// Purchase Order
	private ListModel<PurchaseOrderModel> purchorders = new ListModelList<>();
	public ListModel<PurchaseOrderModel> getPurchorders() {
		return purchorders;
	}
	
	// Purchase Order
	private ListModel<PaymentModeModel> pays = new ListModelList<>();

	public ListModel<PaymentModeModel> getPays() {
		return pays;
	}
	//Grid data
	private ListModel<PurchaseReceiptModel> receipts;
	//Grid data getter (NO setter)
	public ListModel<PurchaseReceiptModel> getReceipts(){
		return receipts;
	}
	//Search keyword
	private @Setter String searchTerm="";
	//Search keyword setter (No getter)
	
	@Init
	public void init(@BindingParam("parentModel")PurchaseReceiptModel receipt ) {
    	this.receipt =(receipt!= null)?receipt: new PurchaseReceiptModel();
    	if(supplierService!=null){
    		sups = new ListModelList<SupplierModel>(supplierService.findAll());
    	}
    	if(purchaseOrderService!=null){
    		purchorders = new ListModelList<PurchaseOrderModel>(purchaseOrderService.findAll());
    	}
    	if(paymentModeService!=null){
    		pays = new ListModelList<PaymentModeModel>(paymentModeService.findAll());
    	}
    	receipts = new ListModelList<PurchaseReceiptModel>(purchaseReceiptService.search(""));
	}
	
	@Command ("cancel")
    public void cancel(@ContextParam(ContextType.VIEW) Component comp){
    comp.detach();

	}
	
	@Command("submit")
	@NotifyChange({"receipt","receipts","searchTerm"})
	public void submit(@ContextParam(ContextType.VIEW) Component comp) {
		if(this.receipt.getId()==null){
			long now = new java.util.Date().getTime();
			this.receipt.setId(now);
		}
		this.receipt=purchaseReceiptService.save(this.receipt);
		this.setSearchTerm("");
		this.receipts = new ListModelList<PurchaseReceiptModel>(purchaseReceiptService.search(""));
		ke.novia.helpers.Windows.showAlert("Records insert successfully");
		 comp.detach();
	}
	
	@Command("search")
	@NotifyChange({"receipts"})
	public void search() {
		receipts = new ListModelList<PurchaseReceiptModel>(purchaseReceiptService.search(searchTerm));
	}
	
	
	@Command("newItem")
	public void newItem() {
	Map <String, Object> params = new HashMap<String, Object>();
	params.put("parentModel", null);
	ke.novia.helpers.Windows.createWindow("purchase/PurchaseReceipt.zul", params);
	
	}
	
	@Command("editItem")
	public void editItem() {
		if(this.receipt.getId()!= null){
		Map <String, Object> params = new HashMap<String, Object>();
		params.put("parentModel", this.receipt);
		ke.novia.helpers.Windows.createWindow("purchase/PurchaseReceipt.zul", params);
	}
		else{
			ke.novia.helpers.Windows.showAlert("Select first to Edit!");
		}
	}
	
	@Command("deleteItem")
	@NotifyChange({"receipt","receipts"})
	public void delete() {
		if(this.receipt.getId()!=null){
			if(ke.novia.helpers.Windows.showConfirm("You are about to delete a record. Continue?")){
			if(purchaseReceiptService.delete(this.receipt)){
				this.receipt = new PurchaseReceiptModel();
				receipts = new ListModelList<PurchaseReceiptModel>(purchaseReceiptService.search(""));
				}
			}
		}
		else{
			ke.novia.helpers.Windows.showAlert("Select first to Delete!");
		}
		
	}


}
