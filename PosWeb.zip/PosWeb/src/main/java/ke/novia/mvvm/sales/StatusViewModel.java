package ke.novia.mvvm.sales;

import java.util.HashMap;
import java.util.Map;

import org.zkoss.bind.annotation.BindingParam;
import org.zkoss.bind.annotation.Command;
import org.zkoss.bind.annotation.ContextParam;
import org.zkoss.bind.annotation.ContextType;
import org.zkoss.bind.annotation.Init;
import org.zkoss.bind.annotation.NotifyChange;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zk.ui.select.annotation.WireVariable;
import org.zkoss.zul.ListModel;
import org.zkoss.zul.ListModelList;
import ke.novia.models.sales.StatusModel;
import ke.novia.services.sales.StatusService;
import lombok.Getter;
import lombok.Setter;


@VariableResolver(org.zkoss.zkplus.spring.DelegatingVariableResolver.class)
public class StatusViewModel {
	
	@WireVariable
	StatusService statusService;
	
	//Form variable
	private @Getter @Setter StatusModel status;
	//status getter and setter
	
	//Grid data
	private @Getter ListModel<StatusModel> statuss;
	//Grid data getter (NO setter)

	//Search keyword
	private @Setter String searchTerm="";
	//Search keyword setter (No getter)

	@Init
	public void init(@BindingParam("parentModel") StatusModel status) {//View Initialization Data
    	this.status =(status!=null)?status: new StatusModel();
    	statuss = new ListModelList<StatusModel>(statusService.search(""));
	}
	
	@Command ("cancel")
    public void cancel(@ContextParam(ContextType.VIEW) Component comp){
    comp.detach();

	}

	@Command("submit")
	@NotifyChange({ "status", "statuss", "searchTerm" })
	public void submit(@ContextParam(ContextType.VIEW) Component comp) {
		if (this.status.getId() == null) {
			long now = new java.util.Date().getTime();
			this.status.setId(now);
		}
		this.status = statusService.save(this.status);
		this.setSearchTerm("");
		this.statuss = new ListModelList<StatusModel>(statusService.search(""));
		ke.novia.helpers.Windows.showAlert("Records insert successfully");
		comp.detach();
	}
	
	@Command("search")
	@NotifyChange({"statuss"})
	public void search() {
		statuss = new ListModelList<StatusModel>(statusService.search(searchTerm));
	}
	
	@Command("newItem")
	public void newItem() {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("parentModel", null);
		ke.novia.helpers.Windows.createWindow("sales/Status.zul", params);
	}
	
	@Command("editItem")
	public void editItem() {
		if(this.status.getId()!=null){
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("parentModel", this.status);
			ke.novia.helpers.Windows.createWindow("sales/Status.zul", params);
		}
		else{
			ke.novia.helpers.Windows.showAlert("Select first to Edit!");
		}
	}
	
	@Command("deleteItem")
	@NotifyChange({"status","statuss"})
	public void delete() {
		if(this.status.getId()!=null){
			if(ke.novia.helpers.Windows.showConfirm("You are about to delete a record. Continue?")){
			if(statusService.delete(this.status)){
				this.status = new StatusModel();
				statuss = new ListModelList<StatusModel>(statusService.search(""));
			}
		}
	}
		else{
			ke.novia.helpers.Windows.showAlert("Select first to Edit!");
		}
		
	}

}
