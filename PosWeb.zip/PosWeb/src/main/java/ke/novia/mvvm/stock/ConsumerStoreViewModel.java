package ke.novia.mvvm.stock;

import java.util.HashMap;
import java.util.Map;

import org.zkoss.bind.annotation.BindingParam;
import org.zkoss.bind.annotation.Command;
import org.zkoss.bind.annotation.ContextParam;
import org.zkoss.bind.annotation.ContextType;
import org.zkoss.bind.annotation.Init;
import org.zkoss.bind.annotation.NotifyChange;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zk.ui.select.annotation.WireVariable;
import org.zkoss.zul.ListModel;
import org.zkoss.zul.ListModelList;
import ke.novia.models.stock.ConsumerStoreModel;
import ke.novia.models.stock.ProductModel;
import ke.novia.services.stock.ConsumerStoreService;
import ke.novia.services.stock.ProductService;
import lombok.Getter;
import lombok.Setter;


@VariableResolver(org.zkoss.zkplus.spring.DelegatingVariableResolver.class)
public class ConsumerStoreViewModel {
	
	@WireVariable
	ConsumerStoreService consumerStoreService;
	
	@WireVariable
	ProductService productService;
	
	//Form variable
	private @Getter @Setter ConsumerStoreModel consumer;
	//brand getter and setter
	
	//Grid data
	private @Getter ListModel<ConsumerStoreModel> consumers;
	//Grid data getter (NO setter)
	
	// Stock Category Items
	private ListModel<ProductModel> items;
	public ListModel<ProductModel> getItems() {
		return items;
	}
		
	//Search keyword
	private @Setter String searchTerm="";
	//Search keyword setter (No getter)
	
	
	@Init
	public void init(@BindingParam("parentMdel")ConsumerStoreModel consumer) {//View Initialization Data
    	this.consumer = (consumer!= null)?consumer:new ConsumerStoreModel();
    	if(productService!=null){
    		items= new ListModelList<ProductModel>(productService.findAll());
    	}
    	consumers = new ListModelList<ConsumerStoreModel>(consumerStoreService.search(""));
	}
	
	@Command ("cancel")
    public void cancel(@ContextParam(ContextType.VIEW) Component comp){
    comp.detach();

	}
	
	@Command("submit")
	@NotifyChange({"consumer","consumers","searchTerm"})
	public void submit(@ContextParam(ContextType.VIEW) Component comp) {
		if(this.consumer.getId()==null){
			long now = new java.util.Date().getTime();
			this.consumer.setId(now);
		}
		this.consumer=consumerStoreService.save(this.consumer);
		this.setSearchTerm("");
		this.consumers = new ListModelList<ConsumerStoreModel>(consumerStoreService.search(""));
		ke.novia.helpers.Windows.showAlert("Records insert successfully");
		comp.detach();
	}
	
	@Command("search")
	@NotifyChange({"consumers"})
	public void search() {
		consumers = new ListModelList<ConsumerStoreModel>(consumerStoreService.search(searchTerm));
	}
	
	@Command("newItem")
	public void newItem() {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("parentModel", null);
		ke.novia.helpers.Windows.createWindow("stock/ConsumerStore.zul", params);
	}
	
	@Command("editItem")
	public void editItem() {
		if(this.consumer.getId()!=null){
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("parentModel", this.consumer);
			ke.novia.helpers.Windows.createWindow("stock/ConsumerStore.zul", params);
		}
		else{
			ke.novia.helpers.Windows.showAlert("Select first to Edit!");
		}
	}
	
	@Command("deleteItem")
	@NotifyChange({"consumer","consumers"})
	public void delete() {
		if(this.consumer.getId()!=null){
			if(ke.novia.helpers.Windows.showConfirm("Question is pressed.You are about to Delete a record, Continue?")){
			if(consumerStoreService.delete(this.consumer)){
				this.consumer = new ConsumerStoreModel();
				consumers = new ListModelList<ConsumerStoreModel>(consumerStoreService.search(""));
				}
			}
		} 
		else {
			ke.novia.helpers.Windows.showAlert("Select first to Delete!");
		}

	}

}
