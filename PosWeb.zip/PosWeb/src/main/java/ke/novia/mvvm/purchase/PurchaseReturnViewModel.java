package ke.novia.mvvm.purchase;

import java.util.HashMap;
import java.util.Map;

import org.zkoss.bind.annotation.BindingParam;
import org.zkoss.bind.annotation.Command;
import org.zkoss.bind.annotation.ContextParam;
import org.zkoss.bind.annotation.ContextType;
import org.zkoss.bind.annotation.Init;
import org.zkoss.bind.annotation.NotifyChange;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zk.ui.select.annotation.WireVariable;
import org.zkoss.zul.ListModel;
import org.zkoss.zul.ListModelList;
import ke.novia.models.purchase.PurchaseReceiptModel;
import ke.novia.models.purchase.PurchaseReturnModel;
import ke.novia.models.stock.ProductModel;
import ke.novia.models.stock.StockItemCategoryModel;
import ke.novia.models.stock.SupplierModel;
import ke.novia.services.stock.ProductService;
import ke.novia.services.purchase.PurchaseReceiptService;
import ke.novia.services.purchase.PurchaseReturnService;
import ke.novia.services.stock.StockItemCategoryService;
import ke.novia.services.stock.SupplierService;
import lombok.Getter;
import lombok.Setter;

@VariableResolver(org.zkoss.zkplus.spring.DelegatingVariableResolver.class)
public class PurchaseReturnViewModel {
	
	@WireVariable
	PurchaseReturnService purchaseReturnService;	
	
	@WireVariable
	StockItemCategoryService stockItemCategoryService;
	
	@WireVariable
	ProductService productService;
	
	@WireVariable
	PurchaseReceiptService purchaseReceiptService;
	
	@WireVariable
	SupplierService supplierService;
	
	//Form variable
	private  @Getter @Setter PurchaseReturnModel retun;
	//retun getter and setter
	
	//Stock Items
	private ListModel<StockItemCategoryModel> categories;
	public ListModel<StockItemCategoryModel> getCategories(){
	   return categories;
	}
	//Stock Category Items
	private ListModel<ProductModel>items;
	public ListModel<ProductModel> getItems(){
		return items;
	}
	//PurchaseReceipt	
	private ListModel<PurchaseReceiptModel> receipts;
	public ListModel<PurchaseReceiptModel> getReceipts(){
	   return receipts;
	}
	//Product Supplier
	private ListModel<SupplierModel> supps = new ListModelList<>();
	public ListModel<SupplierModel> getSupps(){
		return supps;
	}
	
	//Grid data
	private ListModel<PurchaseReturnModel> retuns;
	//Grid data getter (NO setter)
	public ListModel<PurchaseReturnModel> getRetuns(){
		return retuns;
	}
	//Search keyword
	private @Setter String searchTerm="";
	//Search keyword setter (No getter)
	
	@Init
	public void init(@BindingParam("parentModel")PurchaseReturnModel retun) {//View Initialization Data
    	this.retun =(retun!=null)?retun: new PurchaseReturnModel();
    	if(stockItemCategoryService!=null){
    		categories = new ListModelList<StockItemCategoryModel>(stockItemCategoryService.findAll());
    	}
    	if(productService!=null){
    		items= new ListModelList<ProductModel>(productService.findAll());
    	}
    	if(purchaseReceiptService!=null){
    		receipts = new ListModelList<PurchaseReceiptModel>(purchaseReceiptService.findAll());
    	}
    	if(supplierService!=null){
    		supps = new ListModelList<SupplierModel>(supplierService.findAll());
    	}
    	retuns = new ListModelList<PurchaseReturnModel>(purchaseReturnService.search(""));
	}
	
	@Command ("cancel")
    public void cancel(@ContextParam(ContextType.VIEW) Component comp){
    comp.detach();

	}
	
	@Command("submit")
	@NotifyChange({"retun","retuns","searchTerm"})
	public void submit(@ContextParam(ContextType.VIEW) Component comp) {
		if(this.retun.getId()==null){
			long now = new java.util.Date().getTime();
			this.retun.setId(now);
		}
		this.retun=purchaseReturnService.save(this.retun);
		this.setSearchTerm("");
		this.retuns = new ListModelList<PurchaseReturnModel>(purchaseReturnService.search(""));
		ke.novia.helpers.Windows.showAlert("Records insert successfully");
		comp.detach();
	}
	
	@Command("search")
	@NotifyChange({"retuns"})
	public void search() {
		retuns = new ListModelList<PurchaseReturnModel>(purchaseReturnService.search(searchTerm));
	}
	@Command("newItem")
	public void newItem() {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("parentModel", null);
		ke.novia.helpers.Windows.createWindow("purchase/PurchaseReturn.zul", params);
	}

	@Command("editItem")
	public void editItem() {
		if(this.retun.getId()!=null){
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("parentModel", this.retun);
			System.err.println("parentModel : "+retun);
			ke.novia.helpers.Windows.createWindow("purchase/PurchaseReturn.zul", params);
		}
		else{
			ke.novia.helpers.Windows.showAlert("Select first to Edit!");
		}
	}
	
	@Command("deleteItem")
	@NotifyChange({"retun","retuns"})
	public void delete() {
		if(this.retun.getId()!=null){
			if(ke.novia.helpers.Windows.showConfirm("You are about to delete a record. Continue?")){
			if(purchaseReturnService.delete(this.retun)){
				this.retun = new PurchaseReturnModel();
				retuns = new ListModelList<PurchaseReturnModel>(purchaseReturnService.search(""));
				}
			}
		}
		else {
			ke.novia.helpers.Windows.showAlert("Select first to Delete!");
		}

	}
}
