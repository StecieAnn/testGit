package ke.novia.mvvm.stock;

import java.util.HashMap;
import java.util.Map;
import org.zkoss.bind.annotation.BindingParam;
import org.zkoss.bind.annotation.Command;
import org.zkoss.bind.annotation.ContextParam;
import org.zkoss.bind.annotation.ContextType;
import org.zkoss.bind.annotation.Init;
import org.zkoss.bind.annotation.NotifyChange;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zk.ui.select.annotation.WireVariable;
import org.zkoss.zul.ListModel;
import org.zkoss.zul.ListModelList;
import ke.novia.models.stock.StockItemCategoryModel;
import ke.novia.services.stock.StockItemCategoryService;
import lombok.Getter;
import lombok.Setter;

@VariableResolver(org.zkoss.zkplus.spring.DelegatingVariableResolver.class)
public class StockItemCategoryViewModel {
	
	@WireVariable
	StockItemCategoryService stockItemCategoryService;
	
	//Form variable
	private @Getter @Setter StockItemCategoryModel itemCategory;
	//ItemCategory getter and setter

	//Grid data
	private ListModel<StockItemCategoryModel> itemCategories;
	//Grid data getter (NO setter)
	public ListModel<StockItemCategoryModel> getItemCategories(){
		return itemCategories;
	}
	//Search keyword
	private @Setter String searchTerm="";
	//Search keyword setter (No getter)
	
	@Init
	public void init(@BindingParam("parentModel") StockItemCategoryModel itemCategory) {//View Initialization Data

		this.itemCategory = (itemCategory!=null)?itemCategory:new StockItemCategoryModel();
    	
    	itemCategories = new ListModelList<StockItemCategoryModel>(stockItemCategoryService.search(""));
	}
	
	@Command ("cancel")
    public void cancel(@ContextParam(ContextType.VIEW) Component comp){
    comp.detach();

	}
	
	@Command("submit")
	@NotifyChange({"itemCategory","itemCategories","searchTerm"})
	public void submit(@ContextParam(ContextType.VIEW) Component comp) {
		if(this.itemCategory.getId()==null){
			long now = new java.util.Date().getTime();
			this.itemCategory.setId(now);
		}
		this.itemCategory=stockItemCategoryService.save(this.itemCategory);
		this.setSearchTerm("");
		this.itemCategories = new ListModelList<StockItemCategoryModel>(stockItemCategoryService.search(""));
		ke.novia.helpers.Windows.showAlert("Records insert successfully");
		comp.detach();
	}
	
	@Command("search")
	@NotifyChange({"itemCategories"})
	public void search() {
		itemCategories = new ListModelList<StockItemCategoryModel>(stockItemCategoryService.search(searchTerm));
	}
	
	@Command("newItem")
	public void newItem() {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("parentModel", null);
		ke.novia.helpers.Windows.createWindow("stock/StockItemCategory.zul", params);
	}

	@Command("editItem")
	public void editItem() {
		if(this.itemCategory.getId()!=null){
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("parentModel", this.itemCategory);
			System.err.println("parentModel : "+itemCategory);
			ke.novia.helpers.Windows.createWindow("stock/StockItemCategory.zul", params);
		}
		else{
			ke.novia.helpers.Windows.showAlert("Select first to Edit!");
		}
	}
	
	@Command("deleteItem")
	@NotifyChange({"itemCategory","itemCategories"})
	public void deleteItem() {
		if(this.itemCategory.getId()!=null){
			if(ke.novia.helpers.Windows.showConfirm("You are about to delete a record. Continue?")){
				if(stockItemCategoryService.delete(this.itemCategory)){
					this.itemCategory = new StockItemCategoryModel();
					itemCategories = new ListModelList<StockItemCategoryModel>(stockItemCategoryService.search(""));
				}				
			}
		}
		else{
			ke.novia.helpers.Windows.showAlert("Select first to Delete!");
		}
		
	}


}
