package ke.novia.mvvm.sales;

import java.util.HashMap;
import java.util.Map;

import org.zkoss.bind.annotation.BindingParam;
import org.zkoss.bind.annotation.Command;
import org.zkoss.bind.annotation.ContextParam;
import org.zkoss.bind.annotation.ContextType;
import org.zkoss.bind.annotation.Init;
import org.zkoss.bind.annotation.NotifyChange;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zk.ui.select.annotation.WireVariable;
import org.zkoss.zul.ListModel;
import org.zkoss.zul.ListModelList;
import ke.novia.models.sales.SalesTaxModel;
import ke.novia.services.sales.SalesTaxService;
import lombok.Getter;
import lombok.Setter;


@VariableResolver(org.zkoss.zkplus.spring.DelegatingVariableResolver.class)
public class SalesTaxViewModel {
	
	@WireVariable
	SalesTaxService salesTaxService;
	
	//Form variable
	private @Getter @Setter SalesTaxModel tax;
	//salesTax getter and setter
	
	//Grid data
	private @Getter ListModel<SalesTaxModel> taxes;
	//Grid data getter (NO setter)

	//Search keyword
	private @Setter String searchTerm="";
	//Search keyword setter (No getter)

	@Init
	public void init(@BindingParam("parentModel") SalesTaxModel tax) {//View Initialization Data
    	this.tax =(tax!=null)?tax: new SalesTaxModel();
    	taxes = new ListModelList<SalesTaxModel>(salesTaxService.search(""));
	}
	@Command ("cancel")
    public void cancel(@ContextParam(ContextType.VIEW) Component comp){
    comp.detach();

	}
	@Command("submit")
	@NotifyChange({"tax","taxes","searchTerm"})
	public void submit(@ContextParam(ContextType.VIEW) Component comp) {
		if(this.tax.getId()==null){
			long now = new java.util.Date().getTime();
			this.tax.setId(now);
		}
		this.tax=salesTaxService.save(this.tax);
		this.setSearchTerm("");
		this.taxes = new ListModelList<SalesTaxModel>(salesTaxService.search(""));
		ke.novia.helpers.Windows.showAlert("Records insert successfully!");
		 comp.detach();
	}
	
	@Command("search")
	@NotifyChange({"taxes"})
	public void search() {
		taxes = new ListModelList<SalesTaxModel>(salesTaxService.search(searchTerm));
	}
	

	@Command("newItem")
	public void newItem() {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("parentModel", null);
		ke.novia.helpers.Windows.createWindow("sales/SalesTax.zul", params);
	}
	
	@Command("editItem")
	public void editItem() {
		if(this.tax.getId()!=null){
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("parentModel", this.tax);
			ke.novia.helpers.Windows.createWindow("sales/SalesTax.zul", params);
		}
		else{
			ke.novia.helpers.Windows.showAlert("Select first to Edit!");
		}
	}
	
	@Command("deleteItem")
	@NotifyChange({"tax","taxes"})
	public void delete() {
		if(this.tax.getId()!=null){
			if(ke.novia.helpers.Windows.showConfirm("You are about to delete a record. Continue?")){
			if(salesTaxService.delete(this.tax)){
				this.tax = new SalesTaxModel();
				taxes = new ListModelList<SalesTaxModel>(salesTaxService.search(""));
				}
			}
		} 
		else {
			ke.novia.helpers.Windows.showAlert("Select first to Delete!");
		}

	}

}
