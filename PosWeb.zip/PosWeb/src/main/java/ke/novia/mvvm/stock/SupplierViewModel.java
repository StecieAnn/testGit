package ke.novia.mvvm.stock;

import java.util.HashMap;
import java.util.Map;
import org.zkoss.bind.annotation.BindingParam;
import org.zkoss.bind.annotation.Command;
import org.zkoss.bind.annotation.ContextParam;
import org.zkoss.bind.annotation.ContextType;
import org.zkoss.bind.annotation.Init;
import org.zkoss.bind.annotation.NotifyChange;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zk.ui.select.annotation.WireVariable;
import org.zkoss.zul.ListModel;
import org.zkoss.zul.ListModelList;
import ke.novia.models.stock.SupplierModel;
import ke.novia.services.stock.SupplierService;
import lombok.Getter;
import lombok.Setter;

@VariableResolver(org.zkoss.zkplus.spring.DelegatingVariableResolver.class)
public class SupplierViewModel {
	
	@WireVariable
	SupplierService supplierService;

	//Form variable
	private @Getter @Setter SupplierModel supplier;
	//supplier getter and setter	
	
	//Grid data
	private @Getter ListModel<SupplierModel> suppliers;
	//Grid data getter (NO setter)

	//Search keyword
	private  @Setter String searchTerm="";
	//Search keyword setter (No getter)

	
	@Init
	public void init(@BindingParam("parentModel") SupplierModel supplier) {
		
		this.supplier = (supplier!=null)?supplier:new SupplierModel();
		
		suppliers = new ListModelList<SupplierModel>(supplierService.search(""));
	}

	@Command ("cancel")
    public void cancel(@ContextParam(ContextType.VIEW) Component comp){
    comp.detach();

	}
	
	@Command("submit")
	@NotifyChange({"supplier","suppliers","searchTerm"})
	public void submit(@ContextParam(ContextType.VIEW) Component comp) {
		if(this.supplier.getId()==null){
			long now = new java.util.Date().getTime();
			this.supplier.setId(now);

		}
		this.supplier=supplierService.save(this.supplier);
		this.setSearchTerm("");
		this.suppliers = new ListModelList<SupplierModel>(supplierService.search(""));
		ke.novia.helpers.Windows.showAlert("Records insert successfully");
		comp.detach();
	}
	
	@Command("search")
	@NotifyChange({"suppliers"})
	public void search() {
		suppliers = new ListModelList<SupplierModel>(supplierService.search(searchTerm));
	}
	
	@Command("newItem")
	public void newItem() {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("parentModel", null);
		ke.novia.helpers.Windows.createWindow("stock/Supplier.zul", params);
	}
	
	@Command("editItem")
	public void editItem() {
		if(this.supplier.getId()!=null){
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("parentModel", this.supplier);
			System.err.println("parentModel : "+supplier);
			ke.novia.helpers.Windows.createWindow("stock/Supplier.zul", params);
		}
		else{
			ke.novia.helpers.Windows.showAlert("Select first to Edit!");
		}
	}

	@Command("deleteItem")
	@NotifyChange({"supplier","suppliers"})
	public void delete() {
		if(this.supplier.getId()!=null){
			if(ke.novia.helpers.Windows.showConfirm("You are about to Delete a record, Continue?")){
			if(supplierService.delete(this.supplier)){
				this.supplier = new SupplierModel();
				suppliers = new ListModelList<SupplierModel>(supplierService.search(""));
				}
			}
		} 
		else {
			ke.novia.helpers.Windows.showAlert("Select first to Delete!");
		}

	}

}
