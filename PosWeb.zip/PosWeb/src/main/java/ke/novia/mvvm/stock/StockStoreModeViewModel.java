package ke.novia.mvvm.stock;

import java.util.HashMap;
import java.util.Map;

import org.zkoss.bind.annotation.BindingParam;
import org.zkoss.bind.annotation.Command;
import org.zkoss.bind.annotation.ContextParam;
import org.zkoss.bind.annotation.ContextType;
import org.zkoss.bind.annotation.Init;
import org.zkoss.bind.annotation.NotifyChange;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zk.ui.select.annotation.WireVariable;
import org.zkoss.zul.ListModel;
import org.zkoss.zul.ListModelList;
import ke.novia.models.stock.StockStoreModeModel;
import ke.novia.services.stock.StockStoreModeService;
import lombok.Getter;
import lombok.Setter;

@VariableResolver(org.zkoss.zkplus.spring.DelegatingVariableResolver.class)
public class StockStoreModeViewModel {
	
	@WireVariable
	StockStoreModeService stockStoreModeService;
	
	//Form variable
	private @Getter @Setter StockStoreModeModel storeMode;
	//order getter and setter
	
	//Grid data
	private ListModel<StockStoreModeModel> storeModes;
	//Grid data getter (NO setter)
	public ListModel<StockStoreModeModel> getStoreModes(){
		return storeModes;
	}
	//Search keyword
	private  @Setter String searchTerm="";
	//Search keyword setter (No getter)
	
	@Init
	public void init(@BindingParam("parentModel") StockStoreModeModel storeMode) {//View Initialization Data
    	this.storeMode = (storeMode!= null)?storeMode:new StockStoreModeModel();
    	storeModes = new ListModelList<StockStoreModeModel>(stockStoreModeService.search(""));
	}
	
	@Command ("cancel")
    public void cancel(@ContextParam(ContextType.VIEW) Component comp){
    comp.detach();

	}
	
	@Command("submit")
	@NotifyChange({"storeMode","storeModes","searchTerm"})
	public void submit(@ContextParam(ContextType.VIEW) Component comp) {
		if(this.storeMode.getId()==null){
			long now = new java.util.Date().getTime();
			this.storeMode.setId(now);
		}
		this.storeMode=stockStoreModeService.save(this.storeMode);
		this.setSearchTerm("");
		this.storeModes = new ListModelList<StockStoreModeModel>(stockStoreModeService.search(""));
		ke.novia.helpers.Windows.showAlert("Records insert successfully");
		comp.detach();
	}
	
	@Command("search")
	@NotifyChange({"storeModes"})
	public void search() {
		storeModes = new ListModelList<StockStoreModeModel>(stockStoreModeService.search(searchTerm));
	}
	

	@Command("newItem")
	public void newItem() {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("parentModel", null);
		ke.novia.helpers.Windows.createWindow("stock/StockStoreMode.zul", params);
	}
	
	@Command("editItem")
	public void editItem() {
		if(this.storeMode.getId()!=null){
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("parentModel", this.storeMode);
			System.err.println("parentModel : "+storeMode);
			ke.novia.helpers.Windows.createWindow("stock/StockStoreMode.zul", params);
		}
		else{
			ke.novia.helpers.Windows.showAlert("Select first to Edit!");
		}
	}
	
	@Command("deleteItem")
	@NotifyChange({"storeMode","storeModes"})
	public void delete() {
		if(this.storeMode.getId()!=null){
			if(ke.novia.helpers.Windows.showConfirm("You are about to Delete a record, Continue?")){
			if(stockStoreModeService.delete(this.storeMode)){
				this.storeMode = new StockStoreModeModel();
				storeModes = new ListModelList<StockStoreModeModel>(stockStoreModeService.search(""));
				}
			}
		} 
		else {
			ke.novia.helpers.Windows.showAlert("Select first to Delete!");
		}

	}

}
