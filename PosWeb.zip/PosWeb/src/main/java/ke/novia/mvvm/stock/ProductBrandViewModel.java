package ke.novia.mvvm.stock;

import java.util.HashMap;
import java.util.Map;

import org.zkoss.bind.annotation.BindingParam;
import org.zkoss.bind.annotation.Command;
import org.zkoss.bind.annotation.ContextParam;
import org.zkoss.bind.annotation.ContextType;
import org.zkoss.bind.annotation.Init;
import org.zkoss.bind.annotation.NotifyChange;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zk.ui.select.annotation.WireVariable;
import org.zkoss.zul.ListModel;
import org.zkoss.zul.ListModelList;
import ke.novia.models.stock.ProductBrandModel;
import ke.novia.services.stock.ProductBrandService;
import lombok.Getter;
import lombok.Setter;


@VariableResolver(org.zkoss.zkplus.spring.DelegatingVariableResolver.class)
public class ProductBrandViewModel {
	
	@WireVariable
	ProductBrandService productBrandService;
	
	//Form variable
	private @Getter @Setter ProductBrandModel brand;
	//brand getter and setter
	
	//Grid data
	private @Getter ListModel<ProductBrandModel> brands;
	//Grid data getter (NO setter)
	
	//Search keyword
	private @Setter String searchTerm="";
	//Search keyword setter (No getter)
	
	
	@Init
	public void init(@BindingParam("parentModel")ProductBrandModel brand) {//View Initialization Data
    	this.brand = (brand!= null)?brand: new ProductBrandModel();
    	brands = new ListModelList<ProductBrandModel>(productBrandService.search(""));
	}
	
	@Command ("cancel")
    public void cancel(@ContextParam(ContextType.VIEW) Component comp){
    comp.detach();

	}
	
	@Command("submit")
	@NotifyChange({"brand","brands","searchTerm"})
	public void submit(@ContextParam(ContextType.VIEW) Component comp) {
		if(this.brand.getId()==null){
			long now = new java.util.Date().getTime();
			this.brand.setId(now);
		}
		this.brand=productBrandService.save(this.brand);
		this.setSearchTerm("");
		this.brands = new ListModelList<ProductBrandModel>(productBrandService.search(""));
		ke.novia.helpers.Windows.showAlert("Records insert successfully");
		comp.detach();
	}
	
	@Command("search")
	@NotifyChange({"brands"})
	public void search() {
		brands = new ListModelList<ProductBrandModel>(productBrandService.search(searchTerm));
	}
	
	@Command("newItem")
	public void newItem() {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("parentModel", null);
		ke.novia.helpers.Windows.createWindow("stock/ProductBrand.zul", params);
	}

	@Command("editItem")
	public void editItem() {
		if(this.brand.getId()!=null){
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("parentModel", this.brand);
			System.err.println("parentModel : "+brand);
			ke.novia.helpers.Windows.createWindow("stock/ProductBrand.zul", params);
		}
		else{
			ke.novia.helpers.Windows.showAlert("Select first to Edit!");		}
	}
	
	@Command("deleteItem")
	@NotifyChange({"brand","brands"})
	public void delete() {
		if(this.brand.getId()!=null){
			if(ke.novia.helpers.Windows.showConfirm("You are about to Delete a record, Continue?")){
			if(productBrandService.delete(this.brand)){
				this.brand = new ProductBrandModel();
				brands = new ListModelList<ProductBrandModel>(productBrandService.search(""));
				}
			}
		}
		else {
			ke.novia.helpers.Windows.showAlert("Select first to Edit!");
		}

	}


}
