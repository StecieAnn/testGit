package ke.novia.mvvm.Validation;

/*import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.function.Supplier;
import java.util.HashSet;
import java.util.Set;
import javax.validation.ConstraintViolation;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.WrongValueException;
import org.zkoss.zk.ui.WrongValuesException;
import org.zkoss.zkplus.databind.Binding;
import org.zkoss.zkplus.databind.BindingValidateEvent;
import javax.validation.groups.Default;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;*/
import org.zkoss.bind.ValidationContext;
import org.zkoss.bind.validator.AbstractValidator;

 
public class FormValidator extends AbstractValidator{
    
    //private static final Validator _validator = Validation.buildDefaultValidatorFactory().getValidator();
	//ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
	//Validator validator = factory.getValidator();
	
	public void validate(ValidationContext ctx) {
        //all the bean properties
       // Map<String,Property> beanProps = ctx.getProperties(ctx.getProperty().getBase());
		
         String st =(String)ctx.getProperty().getValue();
        
         System.out.println("goood");   
   
   
         if(st.equals("")||st.isEmpty()) {
        	 this.addInvalidMessage(ctx,"ct",  "Field should  not be empty!"); 
         }

}

}
	/*
    public static void validate(BindingValidateEvent event, ViolationRunner runner) {
         
        Iterator<Component> refs = event.getReferences().iterator();
        Iterator<Binding> bindings = event.getBindings().iterator();
        Iterator<?> values = event.getValues().iterator();
         
        List<WrongValueException> wvelist = new ArrayList<WrongValueException>();
         
        while(refs.hasNext() && bindings.hasNext() && values.hasNext()) {
             
            Component ref = refs.next();
            Binding binding = bindings.next();
            Object value = values.next();
             
            Object bean = binding.getBean(ref);
            String expr = binding.getExpression();
            String ct = expr.substring(expr.lastIndexOf('.') + 1);
             
            Set<ConstraintViolation<?>> vs = validate(bean.getClass(), ct, value);
             
            // collect WrongValueException
            for(ConstraintViolation<?> v : vs)
                wvelist.add(new WrongValueException(ref, v.getMessage()));
             
            // call runner
            if(runner != null)
                runner.run(vs, bean, ref);
        }
         
        // this will interrupt binding value to bean, so bean is not modified
        if(!wvelist.isEmpty())
            throw new WrongValuesException(wvelist.toArray(new WrongValueException[0]));
    }
     
    // interface //
    public interface ViolationRunner {
        public void run(Set<ConstraintViolation<?>> violations, Object bean, Component ref);
    }
     
    // helper //
    private static Set validate(Class clazz, String propName, Object value) {
        return _validator.validateValue(clazz, propName, value);
    }
 
}
*/