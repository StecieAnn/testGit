package ke.novia.mvvm.sales;

import java.util.HashMap;
import java.util.Map;

import org.zkoss.bind.annotation.BindingParam;
import org.zkoss.bind.annotation.Command;
import org.zkoss.bind.annotation.ContextParam;
import org.zkoss.bind.annotation.ContextType;
import org.zkoss.bind.annotation.Init;
import org.zkoss.bind.annotation.NotifyChange;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zk.ui.select.annotation.WireVariable;
import org.zkoss.zul.ListModel;
import org.zkoss.zul.ListModelList;
import ke.novia.models.sales.CustomerModel;
import ke.novia.models.sales.SalesModel;
import ke.novia.models.sales.SalesTaxModel;
import ke.novia.models.sales.StatusModel;
import ke.novia.models.stock.ProductModel;
import ke.novia.models.stock.StockItemCategoryModel;
import ke.novia.services.sales.CustomerService;
import ke.novia.services.sales.SalesService;
import ke.novia.services.sales.SalesTaxService;
import ke.novia.services.sales.StatusService;
import ke.novia.services.stock.ProductService;
import ke.novia.services.stock.StockItemCategoryService;
import lombok.Getter;
import lombok.Setter;


@VariableResolver(org.zkoss.zkplus.spring.DelegatingVariableResolver.class)
public class SalesViewModel {
	
	@WireVariable
	SalesService salesService;
	@WireVariable
	SalesTaxService salesTaxService;
	@WireVariable
	ProductService productService;
	@WireVariable
	StockItemCategoryService stockItemCategoryService;
	@WireVariable
	StatusService statusService;
	@WireVariable
	CustomerService customerService;
	//Form variable
	private @Getter @Setter SalesModel sale;
	//sales getter and setter
	
	private  @Getter  String dateFormat;	
	
	// Stock Category Items
	private ListModel<ProductModel> items;

	public ListModel<ProductModel> getItems() {
		return items;
	}

	// Stock Items
	private ListModel<StockItemCategoryModel> categories;

	public ListModel<StockItemCategoryModel> getCategories() {
		return categories;
	}

	// Customer
	private ListModel<CustomerModel> custs;
	public ListModel<CustomerModel> getCusts() {
		return custs;
	}

	// Sales Status
	private ListModel<StatusModel> stas;

	public ListModel<StatusModel> getStas() {
		return stas;
	}

	// Sales Tax
	private ListModel<SalesTaxModel> taxes;

	public ListModel<SalesTaxModel> getTaxes() {
		return taxes;
	}
	//Grid data
	private @Getter ListModel<SalesModel> sales;
	//Grid data getter (NO setter)

	//Search keyword
	private @Setter String searchTerm="";
	//Search keyword setter (No getter)

	@Init
	public void init(@BindingParam("parentModel") SalesModel sale) {//View Initialization Data
    	this.sale =(sale!=null)?sale:new SalesModel();
    	if(stockItemCategoryService!=null){
    		categories = new ListModelList<StockItemCategoryModel>(stockItemCategoryService.findAll());
    	}
    	if(productService!=null){
    		items= new ListModelList<ProductModel>(productService.findAll());
    	}
    	if(customerService!=null){
    		custs= new ListModelList<CustomerModel>(customerService.findAll());
    	}
    	if(statusService!=null){
    		stas= new ListModelList<StatusModel>(statusService.findAll());
    	}
    	if(salesTaxService!=null){
    		taxes= new ListModelList<SalesTaxModel>(salesTaxService.findAll());
    	}
    	
    	sales = new ListModelList<SalesModel>(salesService.search(""));
	}
	
	@Command ("cancel")
    public void cancel(@ContextParam(ContextType.VIEW) Component comp){
    comp.detach();

	}
	@Command("submit")
	@NotifyChange({"sale","sales","searchTerm"})
	public void submit(@ContextParam(ContextType.VIEW) Component comp) {
		if(this.sale.getId()==null){
			long now = new java.util.Date().getTime();
			this.sale.setId(now);
		}
		this.sale=salesService.save(this.sale);
		this.setSearchTerm("");
		this.sales = new ListModelList<SalesModel>(salesService.search(""));
		ke.novia.helpers.Windows.showAlert("Records insert successfully!");
		comp.detach();
	}
	
	@Command("search")
	@NotifyChange({"sales"})
	public void search() {
		sales = new ListModelList<SalesModel>(salesService.search(searchTerm));
	}
	
	@Command("newItem")
	public void newItem() {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("parentModel", null);
		ke.novia.helpers.Windows.createWindow("sales/Sales.zul", params);
	}
	
	@Command("editItem")
	public void editItem() {
		if(this.sale.getId()!=null){
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("parentModel", this.sale);
			ke.novia.helpers.Windows.createWindow("sales/Sales.zul", params);
		}
		else{
			ke.novia.helpers.Windows.showAlert("Select first to Edit!");
		}
	}
	
	@Command("deleteItem")
	@NotifyChange({"sale","sales"})
	public void delete() {
		if(this.sale.getId()!=null){
			if(ke.novia.helpers.Windows.showConfirm("You are about to delete a record. Continue?")){
			if(salesService.delete(this.sale)){
				this.sale = new SalesModel();
				sales = new ListModelList<SalesModel>(salesService.search(""));
				}
			}
		} 
		else {
			ke.novia.helpers.Windows.showAlert("Select first to Delete!");
		}

	}

}
