package ke.novia.mvvm.stock;

import java.util.HashMap;
import java.util.Map;
import org.zkoss.bind.annotation.BindingParam;
import org.zkoss.bind.annotation.Command;
import org.zkoss.bind.annotation.ContextParam;
import org.zkoss.bind.annotation.ContextType;
import org.zkoss.bind.annotation.Init;
import org.zkoss.bind.annotation.NotifyChange;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zk.ui.select.annotation.WireVariable;
import org.zkoss.zul.ListModel;
import org.zkoss.zul.ListModelList;
import ke.novia.models.stock.ProductBrandModel;
import ke.novia.models.stock.ProductModel;
import ke.novia.models.stock.ProductTypeModel;
import ke.novia.models.stock.StockItemCategoryModel;
import ke.novia.models.stock.SupplierModel;
import ke.novia.services.stock.ProductBrandService;
import ke.novia.services.stock.ProductService;
import ke.novia.services.stock.ProductTypeService;
import ke.novia.services.stock.StockItemCategoryService;
import ke.novia.services.stock.SupplierService;
import lombok.Getter;
import lombok.Setter;

@VariableResolver(org.zkoss.zkplus.spring.DelegatingVariableResolver.class)
public class ProductViewModel {
	
	@WireVariable
	ProductService productService;	
	@WireVariable
	StockItemCategoryService stockItemCategoryService;
	@WireVariable
	ProductBrandService productBrandService;
	@WireVariable
	SupplierService supplierService;
	@WireVariable
	ProductTypeService productTypeService;
	
	private  @Getter @Setter String dateFormat;
	//Form variable
	private @Getter @Setter ProductModel prod  ;
	// getter and setter

	//Product Categories
	private ListModel<StockItemCategoryModel> categories = new ListModelList<>();
	public ListModel<StockItemCategoryModel> getCategories(){
		return categories;
	}
	//Product Brands
	private ListModel<ProductBrandModel> prodBs = new ListModelList<>();
	public ListModel<ProductBrandModel> getprodBs(){
		return prodBs;
	}

	// Product Brands
	private ListModel<ProductTypeModel> types = new ListModelList<>();
	public ListModel<ProductTypeModel> getTypes() {
		return types;
	}
	//Product Supplier
	private ListModel<SupplierModel> sups = new ListModelList<>();
	public ListModel<SupplierModel> getSups(){
		return sups;
	}
	
	//Grid data
	private ListModel<ProductModel> prods;
	//Grid data getter (NO setter)
	public ListModel<ProductModel> getProds(){
		return prods;
	}
	//Search keyword
	private @Setter String searchTerm="";
	//Search keyword setter (No getter)
	
	@Init
	public void init(@BindingParam("parentModel")ProductModel prod ) {//View Initialization Data
		
    	this.prod =(prod!=null)?prod:new ProductModel();
    	
    	if(stockItemCategoryService!=null){
    		categories = new ListModelList<StockItemCategoryModel>(stockItemCategoryService.findAll());
    	}
    	if(productBrandService!=null){
    		prodBs = new ListModelList<ProductBrandModel>(productBrandService.findAll());
    	}
    	if(supplierService!=null){
    		sups = new ListModelList<SupplierModel>(supplierService.findAll());
    	}
    	if(productTypeService!=null){
    		types= new ListModelList<ProductTypeModel>(productTypeService.findAll());
    	}
    	prods = new ListModelList<ProductModel>(productService.search(""));
	}
	
	@Command ("cancel")
    public void cancel(@ContextParam(ContextType.VIEW) Component comp){
    comp.detach();

	}
	
	@Command("submit")
	@NotifyChange({"prod","prods","searchTerm"})
	public void submit(@ContextParam(ContextType.VIEW) Component comp) {
		if(this.prod.getId()==null){
			long now = new java.util.Date().getTime();
			this.prod.setId(now);
		}
		this.prod=productService.save(this.prod);
		this.setSearchTerm("");
		this.prods = new ListModelList<ProductModel>(productService.search(""));
		ke.novia.helpers.Windows.showAlert("Records insert successfully");
		comp.detach();
	}
	
	@Command("search")
	@NotifyChange({"prods"})
	public void search() {
		prods = new ListModelList<ProductModel>(productService.search(searchTerm));
	}
	
	@Command("newItem")
	public void newItem() {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("parentModel", null);
		ke.novia.helpers.Windows.createWindow("stock/Product.zul", params);
	}
	
	@Command("editItem")
	public void editItem() {
		if(this.prod.getId()!=null){
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("parentModel", this.prod);
			System.err.println("parentModel : "+prod);
			ke.novia.helpers.Windows.createWindow("stock/Product.zul", params);
		}
		else{
			ke.novia.helpers.Windows.showAlert("Select first to Edit!");
		}
	}
	
	@Command("deleteItem")
	@NotifyChange({"prod","prods"})
	public void delete() {
		if(this.prod.getId()!=null){
			if(productService.delete(this.prod)){
				this.prod = new ProductModel();
				this.prods = new ListModelList<ProductModel>(productService.search(""));
			}
		}
		else{
			ke.novia.helpers.Windows.showAlert("Select first to Delete");
		}
		
	}


}
