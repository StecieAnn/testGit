package ke.novia.mvvm.purchase;

import java.util.HashMap;
import java.util.Map;

import org.zkoss.bind.annotation.BindingParam;
import org.zkoss.bind.annotation.Command;
import org.zkoss.bind.annotation.ContextParam;
import org.zkoss.bind.annotation.ContextType;
import org.zkoss.bind.annotation.Init;
import org.zkoss.bind.annotation.NotifyChange;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zk.ui.select.annotation.WireVariable;
import org.zkoss.zul.ListModel;
import org.zkoss.zul.ListModelList;
import ke.novia.models.purchase.PurchaseOrderModel;
import ke.novia.models.stock.ProductModel;
import ke.novia.models.stock.SupplierModel;
import ke.novia.services.purchase.PurchaseOrderService;
import ke.novia.services.stock.ProductService;
import ke.novia.services.stock.SupplierService;
import lombok.Getter;
import lombok.Setter;

@VariableResolver(org.zkoss.zkplus.spring.DelegatingVariableResolver.class)
public class PurchaseOrderViewModel {
	
	@WireVariable
	PurchaseOrderService purchaseOrderService;
	
	@WireVariable
	SupplierService supplierService;
	
	@WireVariable
	ProductService productService;
	
	//Form variable
	private @Getter @Setter PurchaseOrderModel order;
	//order getter and setter
	
	// Product Supplier
	private ListModel<SupplierModel> supps = new ListModelList<>();
	public ListModel<SupplierModel> getSupps() {
		return supps;
	}

	// Stock Category Items
	private ListModel<ProductModel> items;

	public ListModel<ProductModel> getItems() {
		return items;
	}
	//Grid data
	private ListModel<PurchaseOrderModel> orders;
	//Grid data getter (NO setter)
	public ListModel<PurchaseOrderModel> getOrders(){
		return orders;
	}
	//Search keyword
	private @Setter String searchTerm="";
	//Search keyword setter (No getter)
	
	@Init
	public void init(@BindingParam("parentModel")PurchaseOrderModel order ) {//View Initialization Data
    	this.order =(order!=null)?order: new PurchaseOrderModel();
    	if(supplierService!=null){
    		supps = new ListModelList<SupplierModel>(supplierService.findAll());
    	}
    	if(productService!=null){
    		items= new ListModelList<ProductModel>(productService.findAll());
    	}
    	orders = new ListModelList<PurchaseOrderModel>(purchaseOrderService.search(""));
	}
	
	@Command ("cancel")
    public void cancel(@ContextParam(ContextType.VIEW) Component comp){
    comp.detach();

	}
	
	@Command("submit")
	@NotifyChange({"order","orders","searchTerm"})
	public void submit(@ContextParam(ContextType.VIEW) Component comp) {
		if(this.order.getId()==null){
			long now = new java.util.Date().getTime();
			this.order.setId(now);
		}
		this.order=purchaseOrderService.save(this.order);
		this.setSearchTerm("");
		this.orders = new ListModelList<PurchaseOrderModel>(purchaseOrderService.search(""));
		ke.novia.helpers.Windows.showAlert("Records insert successfully");
		comp.detach();
	}
	
	@Command("search")
	@NotifyChange({"orders"})
	public void search() {
		orders = new ListModelList<PurchaseOrderModel>(purchaseOrderService.search(searchTerm));
	}
	
	@Command("newItem")
	public void newItem() {
	Map <String, Object> params = new HashMap<String, Object>();
	params.put("parentModel", null);
	ke.novia.helpers.Windows.createWindow("purchase/PurchaseOrder.zul", params);
	
	}
	
	@Command("editItem")
	public void editItem() {
		if(this.order.getId()!= null){
		Map <String, Object> params = new HashMap<String, Object>();
		params.put("parentModel", this.order);
		ke.novia.helpers.Windows.createWindow("purchase/PurchaseOrder.zul", params);
	}
		else{
			ke.novia.helpers.Windows.showAlert("Select first to Edit!");
		}
	}
	@Command("deleteItem")
	@NotifyChange({"order","orders"})
	public void delete() {
		if(this.order.getId()!=null){
			if(ke.novia.helpers.Windows.showConfirm("You are about to delete a record. Continue?")){
			if(purchaseOrderService.delete(this.order)){
				this.order = new PurchaseOrderModel();
			}
		}
		}
		else{
			ke.novia.helpers.Windows.showAlert("Select first to Delete!");
		}
		
	}


}
