package ke.novia.mvvm.stock;

import java.util.HashMap;
import java.util.Map;

import org.zkoss.bind.annotation.Command;
import org.zkoss.bind.annotation.ContextParam;
import org.zkoss.bind.annotation.ContextType;
import org.zkoss.bind.annotation.Init;
import org.zkoss.bind.annotation.NotifyChange;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zk.ui.select.annotation.WireVariable;
import org.zkoss.zul.ListModel;
import org.zkoss.zul.ListModelList;
import ke.novia.models.stock.StockTakeModel;
import ke.novia.models.stock.ProductModel;
import ke.novia.services.stock.StockTakeService;
import ke.novia.services.stock.ProductService;
import lombok.Getter;
import lombok.Setter;


@VariableResolver(org.zkoss.zkplus.spring.DelegatingVariableResolver.class)
public class StockTakeViewModel {
	
	@WireVariable
	StockTakeService stockTakeService;
	
	@WireVariable
	ProductService productService;
	
	//Form variable
	private @Getter @Setter StockTakeModel take;
	//brand getter and setter
	
	//Grid data
	private @Getter ListModel<StockTakeModel> takes;
	//Grid data getter (NO setter)
	
	// Stock Category Items
	private ListModel<ProductModel> items;
	public ListModel<ProductModel> getItems() {
		return items;
	}
		
	//Search keyword
	private @Setter String searchTerm="";
	//Search keyword setter (No getter)
	
	
	@Init
	public void init() {//View Initialization Data
    	this.take = (take!= null)?take:new StockTakeModel();
    	if(productService!=null){
    		items= new ListModelList<ProductModel>(productService.findAll());
    	}
    	takes = new ListModelList<StockTakeModel>(stockTakeService.search(""));
	}
	
	@Command ("cancel")
    public void cancel(@ContextParam(ContextType.VIEW) Component comp){
    comp.detach();

	}
	@Command("submit")
	@NotifyChange({"take","takes","searchTerm"})
	public void submit(@ContextParam(ContextType.VIEW) Component comp) {
		if(this.take.getId()==null){
			long now = new java.util.Date().getTime();
			this.take.setId(now);
		}
		this.take=stockTakeService.save(this.take);
		this.setSearchTerm("");
		this.takes = new ListModelList<StockTakeModel>(stockTakeService.search(""));
		ke.novia.helpers.Windows.showAlert("Records insert successfully");
		comp.detach();
	}
	
	@Command("search")
	@NotifyChange({"takes"})
	public void search() {
		takes = new ListModelList<StockTakeModel>(stockTakeService.search(searchTerm));
	}
	
	@Command("newItem")
	public void newItem() {
	Map <String, Object> params =new HashMap <String, Object>();
	params.put("parentModel", null);
	ke.novia.helpers.Windows.createWindow("stock/StockTake.zul", params);
	
	}
	@Command("editItem")
	public void editItem() {
	if(this.take.getId()!= null){
	Map <String, Object> params = new HashMap <String, Object>();
	params.put("parentModel", this.take);
	ke.novia.helpers.Windows.createWindow("stock/StockTake.zul", params);
	}
	else{
		ke.novia.helpers.Windows.showAlert("Select first to Edit!");
	}
	}
	@Command("deleteItem")
	@NotifyChange({"take","takes"})
	public void delete() {
		if(this.take.getId()!=null){
			if(ke.novia.helpers.Windows.showConfirm("You are about to Delete a record, Continue?")){
			if(stockTakeService.delete(this.take)){
				this.take = new StockTakeModel();
				takes = new ListModelList<StockTakeModel>(stockTakeService.search(""));
				}
			}
		} 
		else {
			ke.novia.helpers.Windows.showAlert("Select first to Delete");
		}

	}
}
