package ke.novia.mvvm.sales;

import java.util.HashMap;
import java.util.Map;

import org.zkoss.bind.annotation.BindingParam;
import org.zkoss.bind.annotation.Command;
import org.zkoss.bind.annotation.ContextParam;
import org.zkoss.bind.annotation.ContextType;
import org.zkoss.bind.annotation.Init;
import org.zkoss.bind.annotation.NotifyChange;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zk.ui.select.annotation.WireVariable;
import org.zkoss.zul.ListModel;
import org.zkoss.zul.ListModelList;
import ke.novia.models.sales.CustomerModel;
import ke.novia.models.sales.SalesModel;
import ke.novia.models.sales.SalesReturnModel;
import ke.novia.models.sales.StatusModel;
import ke.novia.models.stock.ProductModel;
import ke.novia.models.stock.StockItemCategoryModel;
import ke.novia.services.sales.CustomerService;
import ke.novia.services.sales.SalesReturnService;
import ke.novia.services.sales.SalesService;
import ke.novia.services.sales.StatusService;
import ke.novia.services.stock.ProductService;
import ke.novia.services.stock.StockItemCategoryService;
import lombok.Getter;
import lombok.Setter;


@VariableResolver(org.zkoss.zkplus.spring.DelegatingVariableResolver.class)
public class SalesReturnViewModel {
	
	@WireVariable
	SalesReturnService salesReturnService;
	
	@WireVariable
	ProductService productService;
	
	@WireVariable
	StockItemCategoryService stockItemCategoryService;
	
	@WireVariable
	StatusService statusService;
	
	@WireVariable
	CustomerService customerService;
	
	@WireVariable
	SalesService salesService;
	
	// Form date formatter getter & setter
	private  @Getter @Setter String dateFormat;
	
	//Form variable
	private @Getter @Setter SalesReturnModel retun;
	//salesReturn getter and setter
	
	// Stock Category Items
	private ListModel<ProductModel> items;
	public ListModel<ProductModel> getItems() {
		return items;
	}

	// Stock Items
	private ListModel<StockItemCategoryModel> categories;

	public ListModel<StockItemCategoryModel> getCategories() {
		return categories;
	}

	// Customer
	private ListModel<CustomerModel> custs;
	public ListModel<CustomerModel> getCusts() {
		return custs;
	}

	// Sales Status
	private ListModel<StatusModel> stas;

	public ListModel<StatusModel> getStas() {
		return stas;
	}

	// Sales Status
	private ListModel<SalesModel> sale;

	public ListModel<SalesModel> getSale() {
		return sale;
	}
	//Grid data
	private @Getter ListModel<SalesReturnModel> retuns;
	//Grid data getter (NO setter)

	//Search keyword
	private @Setter String searchTerm="";
	//Search keyword setter (No getter)

	@Init
	public void init(@BindingParam("parentModel") SalesReturnModel retun) {//View Initialization Data
    	this.retun =(retun!=null)?retun: new SalesReturnModel();
    	if(stockItemCategoryService!=null){
    		categories = new ListModelList<StockItemCategoryModel>(stockItemCategoryService.findAll());
    	}
    	
    	if(customerService!=null){
    		custs= new ListModelList<CustomerModel>(customerService.findAll());
    	}
    	if(statusService!=null){
    		stas= new ListModelList<StatusModel>(statusService.findAll());
    	}
    	if(salesService!=null){
    		sale =new ListModelList<SalesModel>(salesService.findAll());
    	}
    	
    	retuns = new ListModelList<SalesReturnModel>(salesReturnService.search(""));
	}
	@Command ("cancel")
    public void cancel(@ContextParam(ContextType.VIEW) Component comp){
    comp.detach();

	}
	@Command("submit")
	@NotifyChange({"retun","retuns","searchTerm"})
	public void submit(@ContextParam(ContextType.VIEW) Component comp) {
		if(this.retun.getId()==null){
			long now = new java.util.Date().getTime();
			this.retun.setId(now);
		}
		this.retun=salesReturnService.save(this.retun);
		this.setSearchTerm("");
		this.retuns = new ListModelList<SalesReturnModel>(salesReturnService.search(""));
		ke.novia.helpers.Windows.showAlert("Records insert successfully!");
		comp.detach();
	}
	
	@Command("search")
	@NotifyChange({"retuns"})
	public void search() {
		retuns = new ListModelList<SalesReturnModel>(salesReturnService.search(searchTerm));
	}	
	
	@Command("newItem")
	public void newItem() {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("parentModel", null);
		ke.novia.helpers.Windows.createWindow("sales/SalesReturn.zul", params);
	}
	
	@Command("editItem")
	public void editItem() {
		if(this.retun.getId()!=null){
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("parentModel", this.retun);
			ke.novia.helpers.Windows.createWindow("sales/SalesReturn.zul", params);
		}
		else{
			ke.novia.helpers.Windows.showAlert("Select first to Edit");
		}
	}
	
	@Command("deleteItem")
	@NotifyChange({"retun","retuns"})
	public void delete() {
		if(this.retun.getId()!=null){
			if(ke.novia.helpers.Windows.showConfirm("You are about to delete a record. Continue?")){
			if(salesReturnService.delete(this.retun)){
				this.retun = new SalesReturnModel();
				retuns = new ListModelList<SalesReturnModel>(salesReturnService.search(""));
				}
			}
		} 
		else {
			ke.novia.helpers.Windows.showAlert("Select first to Delete!");
		}

	}

}
