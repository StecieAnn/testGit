package ke.novia.mvvm.stock;

import java.util.HashMap;
import java.util.Map;

import org.zkoss.bind.annotation.BindingParam;
import org.zkoss.bind.annotation.Command;
import org.zkoss.bind.annotation.ContextParam;
import org.zkoss.bind.annotation.ContextType;
import org.zkoss.bind.annotation.Init;
import org.zkoss.bind.annotation.NotifyChange;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zk.ui.select.annotation.WireVariable;
import org.zkoss.zul.ListModel;
import org.zkoss.zul.ListModelList;
import ke.novia.models.stock.ProductTypeModel;
import ke.novia.services.stock.ProductTypeService;
import lombok.Getter;
import lombok.Setter;

@VariableResolver(org.zkoss.zkplus.spring.DelegatingVariableResolver.class)
public class ProductTypeViewModel {
	
	@WireVariable
	ProductTypeService productTypeService;
	
	//Form variable
	private @Getter @Setter ProductTypeModel type;
	//type getter and setter
	
	//Grid data
	private ListModel<ProductTypeModel> types;
	//Grid data getter (NO setter)
	public ListModel<ProductTypeModel> gettypes(){
		return types;
	}
	//Search keyword
	private @Setter String searchTerm="";
	//Search keyword setter (No getter)
	
	@Init
	public void init(@BindingParam("parentModel")ProductTypeModel type ) {//View Initialization Data
    	this.type =(type!= null)?type: new ProductTypeModel();
    	types = new ListModelList<ProductTypeModel>(productTypeService.search(""));
	}
	
	@Command ("cancel")
    public void cancel(@ContextParam(ContextType.VIEW) Component comp){
    comp.detach();

	}
	
	@Command("submit")
	@NotifyChange({"type","types","searchTerm"})
	public void submit(@ContextParam(ContextType.VIEW) Component comp) {
		if(this.type.getId()==null){
			long now = new java.util.Date().getTime();
			this.type.setId(now);
			
		}
		this.type=productTypeService.save(this.type);
		this.setSearchTerm("");
		this.types = new ListModelList<ProductTypeModel>(productTypeService.search(""));
		ke.novia.helpers.Windows.showAlert("Records insert successfully");
		comp.detach();
	}
	
	@Command("search")
	@NotifyChange({"types"})
	public void search() {
		types = new ListModelList<ProductTypeModel>(productTypeService.search(searchTerm));
	}
	@Command("newItem")
	public void newItem() {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("parentModel", null);
		ke.novia.helpers.Windows.createWindow("stock/ProductType.zul", params);
	}

	@Command("editItem")
	public void editItem() {
		if(this.type.getId()!=null){
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("parentModel", this.type);
			System.err.println("parentModel : "+type);
			ke.novia.helpers.Windows.createWindow("stock/ProductType.zul", params);
		}
		else{
			ke.novia.helpers.Windows.showAlert("You have selected nothing!");
		}
	}
	
	@Command("deleteItem")
	@NotifyChange({"type","types"})
	public void delete() {
		if(this.type.getId()!=null){
			if(ke.novia.helpers.Windows.showConfirm("You are about to Delete a record, Continue?")){
			if(productTypeService.delete(this.type)){
				this.type = new ProductTypeModel();
				types = new ListModelList<ProductTypeModel>(productTypeService.search(""));
				}
			}
		} 
		else {
			ke.novia.helpers.Windows.showAlert("Select first to Delete");
		}

	}

}
