package ke.novia.mvvm.stock;

import java.util.HashMap;
import java.util.Map;
import org.zkoss.bind.annotation.BindingParam;
import org.zkoss.bind.annotation.Command;
import org.zkoss.bind.annotation.ContextParam;
import org.zkoss.bind.annotation.ContextType;
import org.zkoss.bind.annotation.Init;
import org.zkoss.bind.annotation.NotifyChange;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zk.ui.select.annotation.WireVariable;
import org.zkoss.zul.ListModel;
import org.zkoss.zul.ListModelList;
import ke.novia.models.stock.ProductModel;
import ke.novia.models.stock.StockItemCategoryModel;
import ke.novia.models.stock.StockTransferModel;
import ke.novia.services.stock.ProductService;
import ke.novia.services.stock.StockItemCategoryService;
import ke.novia.services.stock.StockTransferService;
import lombok.Getter;
import lombok.Setter;

@VariableResolver(org.zkoss.zkplus.spring.DelegatingVariableResolver.class)
public class StockTransferViewModel {
	
	@WireVariable
	StockTransferService stockTransferService;
	@WireVariable
	ProductService productService;
	@WireVariable
	StockItemCategoryService stockItemCategoryService;
	
	// Form date formatter getter & setter
	private  @Getter @Setter String dateFormat;
	//Form variable
	private @Getter @Setter StockTransferModel transfer;
	
	// Stock Category Items
	private ListModel<ProductModel> items;
	public ListModel<ProductModel> getItems() {
		return items;
	}
	// Stock Items
	private ListModel<StockItemCategoryModel> categories;
	public ListModel<StockItemCategoryModel> getCategories() {
		return categories;
	}
	//Grid data
	private ListModel<StockTransferModel> transfers;
	//Grid data getter (NO setter)
	public ListModel<StockTransferModel> getTransfers(){
		return transfers;
	}
	//Search keyword
	private @Setter String searchTerm="";
	//Search keyword setter (No getter)
	
	
	@Init
	public void init(@BindingParam("parentModel") StockTransferModel transfer) {//View Initialization Data
    	this.transfer = (transfer!=null)?transfer:new StockTransferModel();
    	if(stockItemCategoryService!=null){
    		categories = new ListModelList<StockItemCategoryModel>(stockItemCategoryService.findAll());
    	}
    	if(productService!=null){
    		items= new ListModelList<ProductModel>(productService.findAll());
    	}
    	transfers = new ListModelList<StockTransferModel>(stockTransferService.search(""));
	}
	
	@Command ("cancel")
    public void cancel(@ContextParam(ContextType.VIEW) Component comp){
    comp.detach();

	}
	
	@Command("submit")
	@NotifyChange({"transfer","transfers","searchTerm"})
	public void submit(@ContextParam(ContextType.VIEW) Component comp) {
		if(this.transfer.getId()==null){
			long now = new java.util.Date().getTime();
			this.transfer.setId(now);
		}
		this.transfer=stockTransferService.save(this.transfer);
		this.setSearchTerm("");
		this.transfers = new ListModelList<StockTransferModel>(stockTransferService.search(""));
		ke.novia.helpers.Windows.showAlert("Records insert successfully");
		comp.detach();
	
	}
	
	@Command("search")
	@NotifyChange({"transfers"})
	public void search() {
		transfers = new ListModelList<StockTransferModel>(stockTransferService.search(searchTerm));
	}
	
	@Command("newItem")
	public void newItem() {
		Map<String, Object> params= new HashMap <String, Object>();
		params.put("parentModel", null);
		ke.novia.helpers.Windows.createWindow("stock/StockTransfer.zul", params);
	}
	@Command("editItem")
	public void editItem() {
	if(this.transfer.getId()!=null){
	Map<String, Object> params = new HashMap <String, Object>();
	params.put("parentModel", this.transfer);
	ke.novia.helpers.Windows.createWindow("stock/StockTransfer.zul", params);
	}
	else{
		ke.novia.helpers.Windows.showAlert("Select first to Edit!");
	}
}
  
	@Command("deleteItem")
	@NotifyChange({"transfer","transfers"})
	public void delete() {
		if(this.transfer.getId()!=null){
			if(ke.novia.helpers.Windows.showConfirm("You are about to Delete a record, Continue?")){
			if(stockTransferService.delete(this.transfer)){
				this.transfer = new StockTransferModel();
				transfers = new ListModelList<StockTransferModel>(stockTransferService.search(""));
				}
			}
		} 
		else {
			ke.novia.helpers.Windows.showAlert("Select first to Delete!");
		}

	}

}
