package ke.novia.helpers;

import java.util.Map;

import org.zkoss.zk.ui.Executions;
import org.zkoss.zk.ui.event.Event;
import org.zkoss.zk.ui.event.EventListener;
import org.zkoss.zk.ui.event.Events;
import org.zkoss.zk.ui.util.Clients;
import org.zkoss.zul.Messagebox;
import org.zkoss.zul.Window;

public class Windows {
	static boolean status = false;
	public static void createWindow(String url, Map<String, Object> params){
		// create a window programmatically and use it as a modal dialog.
		Window window = (Window) Executions.createComponents("/app/"+url, null, params);
		window.setBorder(true);//"/WEB-INF/app/"
		window.addEventListener(Events.ON_CLOSE, new OnCloseListener());
		window.doModal();
	}
	
	public static void showAlert(String message){
		Messagebox.show(message);
	}
	
	@SuppressWarnings("unchecked")
	public static boolean showConfirm(String message){
		Messagebox.show(message, "Confirm Dialog", Messagebox.OK | Messagebox.NO  | Messagebox.CANCEL, Messagebox.QUESTION, new org.zkoss.zk.ui.event.EventListener() {
		    public void onEvent(Event evt) throws InterruptedException {
		        if (evt.getName().equals("onOK")) {
		        	status = true;
		        }
		    }
		});
		return status;
	}
	
}

final class OnCloseListener implements EventListener {
	@Override
	public void onEvent(Event event) throws Exception {
		//System.err.println("Window Closed");
		Clients.evalJavaScript("location.reload();");
		//x.detach();
	}
}
