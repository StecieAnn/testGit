package ke.novia.helpers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import org.zkoss.bind.annotation.Default;

/**
 * A utility class for JSR 303 Bean Validation
 * 
 * @author simonpai
 */
public class Validations {
	private final ValidatorFactory factory;

	public Validations() {
		factory = Validation.buildDefaultValidatorFactory();
	}

	// private static final Validator _validator =
	// Validation.buildDefaultValidatorFactory().getValidator();
	public <T> HashSet<ConstraintViolation<?>> validate(final T instance) {
		final Validator validator = Validation.buildDefaultValidatorFactory().getValidator();// factory.getValidator();
		final Set<ConstraintViolation<T>> violations = validator.validate(instance);// ,																		// Default.class
		if (!violations.isEmpty()) {
			final Set<ConstraintViolation<?>> constraints = new HashSet<ConstraintViolation<?>>(violations.size());

			for (final ConstraintViolation<?> violation : violations) {
				constraints.add(violation);
			}

			return (HashSet<ConstraintViolation<?>>) constraints;
		}
		return null;
	}

	public static <T> boolean IsValidBean(final T instance) {

		List<ValidationMessage> vList = new ArrayList<ValidationMessage>();

		final Set<ConstraintViolation<?>> constraints = new Validations().validate(instance);
		if (constraints == null) {
			return true;
		}
		for (final ConstraintViolation<?> violation : constraints) {
			System.err.println(violation.getMessage());
			vList.add(new ValidationMessage(violation.getMessage()));
		}
		if (vList.size() > 0) {
			//final HashMap<String, Object> map = new HashMap<String, Object>();
			//map.put("vList", vList);

			// Executions.createComponents("ValidateWindow.zul",null, map);
			return false;
		} else
			return true;
	}
}
//http://hibernate.org/validator/documentation/getting-started/


//http://emrpms.blogspot.co.ke/2013/06/zk-mvvm-form-binding-crud-with-spring.html