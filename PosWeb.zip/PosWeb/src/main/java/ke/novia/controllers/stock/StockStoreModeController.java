package ke.novia.controllers.stock;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zkplus.spring.DelegatingVariableResolver;

import ke.novia.models.stock.StockStoreModeModel;
import ke.novia.services.stock.StockStoreModeService;

@RestController
@VariableResolver(DelegatingVariableResolver.class)
@SessionAttributes({"StockStoreModeViewModel"})
@RequestMapping("/stockStoreMode")
public class StockStoreModeController {
	@Autowired
	StockStoreModeService stockStoreMode;
    @RequestMapping({"","/"})
    public ModelAndView index(Model model) {
        return new ModelAndView("stock/StockStoreMode");
    }
    
    @RequestMapping({"/search","/search/{searchTerm}"})
    public List<StockStoreModeModel> search(Model model,@PathVariable String searchTerm) {
    	return stockStoreMode.search(searchTerm.trim());
    }
    
    @RequestMapping({"/save"})
    public StockStoreModeModel save(@RequestBody StockStoreModeModel storeMode) {
		if(storeMode.getId()==null){
			long now = new java.util.Date().getTime();
			storeMode.setId(now);
		}
    	return stockStoreMode.save(storeMode);
    }
}
