package ke.novia.controllers.sales;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zkplus.spring.DelegatingVariableResolver;

import ke.novia.models.sales.PaymentModeModel;
import ke.novia.services.sales.PaymentModeService;

@RestController
@VariableResolver(DelegatingVariableResolver.class)
@SessionAttributes({"PaymentModeViewModel"})
@RequestMapping("/paymentMode")
public class PaymentModeController {
	@Autowired
	PaymentModeService paymentMode;
    @RequestMapping({"","/"})
    public ModelAndView index(Model model) {
        return new ModelAndView("stock/PaymentMode");
    }
    
    @RequestMapping({"/search","/search/{searchTerm}"})
    public List<PaymentModeModel> search(Model model,@PathVariable String searchTerm) {
    	return paymentMode.search(searchTerm.trim());
    }
    
    @RequestMapping({"/save"})
    public PaymentModeModel save(@RequestBody PaymentModeModel receipt) {
		if(receipt.getId()==null){
			long now = new java.util.Date().getTime();
			receipt.setId(now);
		}
    	return paymentMode.save(receipt);
    }
}
