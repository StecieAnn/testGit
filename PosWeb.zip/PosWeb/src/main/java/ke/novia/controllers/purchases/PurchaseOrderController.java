package ke.novia.controllers.purchases;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zkplus.spring.DelegatingVariableResolver;

import ke.novia.models.purchase.PurchaseOrderModel;
import ke.novia.services.purchase.PurchaseOrderService;

@RestController
@VariableResolver(DelegatingVariableResolver.class)
@SessionAttributes({"PurchaseOrderViewModel"})
@RequestMapping("/purchaseOrder")
public class PurchaseOrderController {
	@Autowired
	PurchaseOrderService purchaseOrder;
    @RequestMapping({"","/"})
    public ModelAndView index(Model model) {
        return new ModelAndView("purchase/purchaseOrder");
    }
    
    @RequestMapping({"/search","/search/{searchTerm}"})
    public List<PurchaseOrderModel> search(Model model,@PathVariable String searchTerm) {
    	return purchaseOrder.search(searchTerm.trim());
    }
    
    @RequestMapping({"/save"})
    public PurchaseOrderModel save(@RequestBody PurchaseOrderModel order) {
		if(order.getId()==null){
			long now = new java.util.Date().getTime();
			order.setId(now);
		}
    	return purchaseOrder.save(order);
    }
}
