package ke.novia.controllers.stock;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zkplus.spring.DelegatingVariableResolver;

import ke.novia.models.stock.ProductCategoryModel;
import ke.novia.services.stock.ProductCategoryService;

@RestController
@VariableResolver(DelegatingVariableResolver.class)
@SessionAttributes({"ProductCategoryViewModel"})
@RequestMapping("/productCategory")
public class ProductCategoryController {
	@Autowired
	ProductCategoryService productCategory;
    @RequestMapping({"","/"})
    public ModelAndView index(Model model) {
    	System.out.println("Customer");
        return new ModelAndView("stock/ProductCategory");
    }
    
    @RequestMapping({"/search","/search/{searchTerm}"})
    public List<ProductCategoryModel> search(Model model,@PathVariable String searchTerm) {
    	return productCategory.search(searchTerm.trim());
    }
    /*
    @RequestMapping({"/save"})
    public ProductCategoryModel save(@RequestBody ProductCategoryModel category) {
		if(category.getId()==null){
			long now = new java.util.Date().getTime();
			category.setId(now);
			category.setCategoryId(now);
		}
    	return productCategory.save(category);
    }
    */
}
