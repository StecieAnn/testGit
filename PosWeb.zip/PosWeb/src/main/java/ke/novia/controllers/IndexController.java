package ke.novia.controllers;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
@RestController
public class IndexController {
    final static Log logger = LogFactory.getLog(IndexController.class);
    @RequestMapping({"","/"})
    public String index(HttpServletRequest request) {
    	String ret = ke.novia.helpers.MVC.getfile(request, "NoviaSuite", false);
    	ret+= "<script type='text/javascript'>"+ke.novia.helpers.MVC.getfile(request, "novia", true)+"</script>";
    	return ret+"<script type='text/javascript'>"+ke.novia.helpers.MVC.getfile(request, "app", true)+"</script>";
    }
    
    @RequestMapping({"dashboard","dashboard/"})
    public ModelAndView index(Model model) {
    	System.out.println("Index");
        return new ModelAndView("/app/Dashboard.zul");//PurchaseReceiptItem
    }
    @RequestMapping({"load","viewLoader/{path}"})
    public ModelAndView zulLoader(Model model,@PathVariable String path) {
    	path = path.replace("$","/");
        return new ModelAndView("/app/"+path+"List.zul");//PurchaseReceiptItem
    }    
}














/* package ke.novia.controllers;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
@RestController
public class IndexController {

    final static Log logger = LogFactory.getLog(IndexController.class);
    boolean isLogged = true;
    @RequestMapping("/")
    public ModelAndView index(Model model) {
    	System.out.println("Index");
        return new ModelAndView("index.html");
    }
}*/
