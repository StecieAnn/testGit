package ke.novia.controllers.stock;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zkplus.spring.DelegatingVariableResolver;
import ke.novia.models.stock.StockTakeModel;
import ke.novia.services.stock.StockTakeService;


@RestController
@VariableResolver(DelegatingVariableResolver.class)
@SessionAttributes({"StockTakeViewModel"})
@RequestMapping("/stockTake")
public class StockTakeController {
	
	
	@Autowired
	StockTakeService stockTake;

    @RequestMapping({"","/"})
    public ModelAndView index(Model model) {
        return new ModelAndView("/app/stock/StockTake");
        
    }
	 
    @RequestMapping({"/search","/search/{searchTerm}"})
    public List<StockTakeModel> search(Model model,@PathVariable String searchTerm) {
    	return stockTake.search(searchTerm.trim());
    }
    
    
    @RequestMapping({"/save"})
    public StockTakeModel save(@RequestBody StockTakeModel stock) {
		if(stock.getId()==null){
			long now = new java.util.Date().getTime();
			stock.setId(now);
		}
    	return stockTake.save(stock);
    }
}
