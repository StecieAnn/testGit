package ke.novia.controllers.sales;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zkplus.spring.DelegatingVariableResolver;

import ke.novia.models.sales.SalesModel;
import ke.novia.services.sales.SalesService;

@RestController
@VariableResolver(DelegatingVariableResolver.class)
@SessionAttributes({"SalesViewModel"})
@RequestMapping("/sales")
public class SalesController {
	@Autowired
	SalesService sales;
    @RequestMapping({"","/"})
    public ModelAndView index(Model model) {
    	return new ModelAndView("sales/Sales");
    }
    
    @RequestMapping({"/search","/search/{searchTerm}"})
    public List<SalesModel> search(Model model,@PathVariable String searchTerm) {
    	return sales.search(searchTerm.trim());
    }
    
    @RequestMapping({"/save"})
    public SalesModel save(@RequestBody SalesModel sal) {
		if(sal.getId()==null){
			long now = new java.util.Date().getTime();
			sal.setId(now);
		}
		return sales.save(sal);
    }
}
