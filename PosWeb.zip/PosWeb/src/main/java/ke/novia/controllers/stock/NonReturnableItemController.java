package ke.novia.controllers.stock;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zkplus.spring.DelegatingVariableResolver;
import ke.novia.models.stock.NonReturnableItemModel;
import ke.novia.services.stock.NonReturnableItemService;


@RestController
@VariableResolver(DelegatingVariableResolver.class)
@SessionAttributes({"NonReturnableItemViewModel"})
@RequestMapping("/nonReturnableItem")
public class NonReturnableItemController {
	@Autowired
	NonReturnableItemService nonReturnableItemService;
    @RequestMapping({"","/"})
    public ModelAndView index(Model model) {
        return new ModelAndView("stock/NonReturnableItem");
    }
    @RequestMapping(value="/get", method=RequestMethod.GET)
    public NonReturnableItemModel get(@RequestParam("id") Long id){
		try {
			return nonReturnableItemService.getById(id);
		} catch (Exception e) {
			//logger.error("", e);
		}
        return null;
    }
    
    @RequestMapping({"/search","/search/{searchTerm}"})
    public List<NonReturnableItemModel> search(Model model,@PathVariable String searchTerm) {
    	return nonReturnableItemService.search(searchTerm.trim());
    }
    
    @RequestMapping({"/save"})
    public NonReturnableItemModel save(@RequestBody NonReturnableItemModel nonreturnables ) {
		if(nonreturnables.getId()==null){
			long now = new java.util.Date().getTime();
			nonreturnables.setId(now);
		}
    	return nonReturnableItemService.save(nonreturnables);
    }
}
