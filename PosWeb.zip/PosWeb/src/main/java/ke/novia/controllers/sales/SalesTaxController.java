package ke.novia.controllers.sales;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zkplus.spring.DelegatingVariableResolver;

import ke.novia.models.sales.SalesTaxModel;
import ke.novia.services.sales.SalesTaxService;

@RestController
@VariableResolver(DelegatingVariableResolver.class)
@SessionAttributes({"SalesTaxViewModel"})
@RequestMapping("/salesTax")
public class SalesTaxController {
	@Autowired
	SalesTaxService salesTax;
    @RequestMapping({"","/"})
    public ModelAndView index(Model model) {
        return new ModelAndView("sales/SalesTax");
    }
    
    @RequestMapping({"/search","/search/{searchTerm}"})
    public List<SalesTaxModel> search(Model model,@PathVariable String searchTerm) {
    	return salesTax.search(searchTerm.trim());
    }
    
    @RequestMapping({"/save"})
    public SalesTaxModel save(@RequestBody SalesTaxModel sta) {
		if(sta.getId()==null){
			long now = new java.util.Date().getTime();
			sta.setId(now);
		}
    	return salesTax.save(sta);
    }
}
