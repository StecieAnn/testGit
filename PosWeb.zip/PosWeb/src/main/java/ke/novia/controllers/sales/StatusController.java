package ke.novia.controllers.sales;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zkplus.spring.DelegatingVariableResolver;

import ke.novia.models.sales.StatusModel;
import ke.novia.services.sales.StatusService;

@RestController
@VariableResolver(DelegatingVariableResolver.class)
@SessionAttributes({"StatusViewModel"})
@RequestMapping("/status")
public class StatusController {
	@Autowired
	StatusService status;
    @RequestMapping({"","/"})
    public ModelAndView index(Model model) {
        return new ModelAndView("sales/Status");
    }
    
    @RequestMapping({"/search","/search/{searchTerm}"})
    public List<StatusModel> search(Model model,@PathVariable String searchTerm) {
    	return status.search(searchTerm.trim());
    }
    
    @RequestMapping({"/save"})
    public StatusModel save(@RequestBody StatusModel sta) {
		if(sta.getId()==null){
			long now = new java.util.Date().getTime();
			sta.setId(now);
		}
    	return status.save(sta);
    }
}
