package ke.novia.controllers.purchases;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zkplus.spring.DelegatingVariableResolver;
import ke.novia.models.purchase.PurchaseReceiptItemModel;
import ke.novia.services.purchase.PurchaseReceiptItemService;

@RestController
@VariableResolver(DelegatingVariableResolver.class)
@SessionAttributes({"PurchaseReceiptItemViewModel"})
@RequestMapping("/purchaseReceiptItem")
public class PurchaseReceiptItemController {
	@Autowired
	PurchaseReceiptItemService purchaseReceiptItem;
    @RequestMapping({"","/"})
    public ModelAndView index(Model model) {
        return new ModelAndView("stock/PurchaseReceiptItem");
    }
    
    @RequestMapping("/PurchaseReceiptItem/{id}")
    public PurchaseReceiptItemModel PurchaseReceiptItemModel (@PathVariable Long id, Model model){
        //model.addAttribute(purchaseReceiptItem.findById(id));
        return null;//purchaseReceiptItem.findById(id);
    }
    
    @RequestMapping({"/search","/search/{searchTerm}"})
    public List<PurchaseReceiptItemModel> search(Model model,@PathVariable String searchTerm) {
    	return purchaseReceiptItem.search(searchTerm.trim());
    }
    
    @RequestMapping({"/save"})
    public PurchaseReceiptItemModel save(@RequestBody PurchaseReceiptItemModel receiptItem) {
		if(receiptItem.getId()==null){
			long now = new java.util.Date().getTime();
			receiptItem.setId(now);
		}
    	return purchaseReceiptItem.save(receiptItem);
    }
}
