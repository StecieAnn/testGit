package ke.novia.controllers.stock;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zkplus.spring.DelegatingVariableResolver;

import ke.novia.models.stock.ProductBrandModel;
import ke.novia.services.stock.ProductBrandService;

@RestController
@VariableResolver(DelegatingVariableResolver.class)
@SessionAttributes({"ProductBrandViewModel"})
@RequestMapping("/productBrand")
public class ProductBrandController {
	@Autowired
	ProductBrandService productBrand;
    @RequestMapping({"","/"})
    public ModelAndView index(Model model) {
        return new ModelAndView("stock/ProductBrand");
    }
    
    @RequestMapping({"/search","/search/{searchTerm}"})
    public List<ProductBrandModel> search(Model model,@PathVariable String searchTerm) {
    	return productBrand.search(searchTerm.trim());
    }
    
    @RequestMapping({"/save"})
    public ProductBrandModel save(@RequestBody ProductBrandModel brand) {
		if(brand.getId()==null){
			long now = new java.util.Date().getTime();
			brand.setId(now);
		}
    	return productBrand.save(brand);
    }
}
