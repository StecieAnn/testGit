package ke.novia.controllers.stock;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zkplus.spring.DelegatingVariableResolver;
import ke.novia.models.stock.ConsumerStoreModel;
import ke.novia.services.stock.ConsumerStoreService;


@RestController
@VariableResolver(DelegatingVariableResolver.class)
@SessionAttributes({"ConsumerStoreViewModel"})
@RequestMapping("/consumerStore")
public class ConsumerStoreController {
	@Autowired
	ConsumerStoreService consumerStore;
    @RequestMapping({"","/"})
    public ModelAndView index(Model model) {
        return new ModelAndView("stock/ConsumerStore");
    }
    @RequestMapping(value="/get", method=RequestMethod.GET)
    public ConsumerStoreModel get(@RequestParam("id") Long id){
		try {
			return consumerStore.getById(id);
		} catch (Exception e) {
			//logger.error("", e);
		}
        return null;
    }
    
    @RequestMapping({"/search","/search/{searchTerm}"})
    public List<ConsumerStoreModel> search(Model model,@PathVariable String searchTerm) {
    	return consumerStore.search(searchTerm.trim());
    }
    
    @RequestMapping({"/save"})
    public ConsumerStoreModel save(@RequestBody ConsumerStoreModel consumer ) {
		if(consumer.getId()==null){
			long now = new java.util.Date().getTime();
			consumer.setId(now);
		}
    	return consumerStore.save(consumer);
    }
}
