package ke.novia.controllers.sales;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zkplus.spring.DelegatingVariableResolver;
import ke.novia.models.sales.CustomerModel;
import ke.novia.services.sales.CustomerService;

@RestController
@VariableResolver(DelegatingVariableResolver.class)
@SessionAttributes({"CustomerViewModel"})
@RequestMapping("/customer")
public class CustomerController {
	@Autowired
	CustomerService customer;
    @RequestMapping({"","/"})
    public ModelAndView index(Model model) {
        return new ModelAndView("sales/Customer");
    }
    
    @RequestMapping({"/search","/search/{searchTerm}"})
    public List<CustomerModel> search(Model model,@PathVariable String searchTerm) {
    	return customer.search(searchTerm.trim());
    }
    
    @RequestMapping({"/save"})
    public CustomerModel save(@RequestBody CustomerModel cust) {
		if(cust.getId()==null){
			long now = new java.util.Date().getTime();
			cust.setId(now);
		}
    	return customer.save(cust);
    }
}
