package ke.novia.controllers.stock;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zkplus.spring.DelegatingVariableResolver;

import ke.novia.models.stock.StockItemCategoryModel;
import ke.novia.services.stock.StockItemCategoryService;

@RestController
@VariableResolver(DelegatingVariableResolver.class)
@SessionAttributes({"StockItemCategoryViewModel"})
@RequestMapping("/stockItemCategory")
public class StockItemCategoryController {
	@Autowired
	StockItemCategoryService stockItemCategory;
    @RequestMapping({"","/"})
    public ModelAndView index(Model model) {
        return new ModelAndView("stock/StockItemCategory");
    }
    
    @RequestMapping({"/search","/search/{searchTerm}"})
    public List<StockItemCategoryModel> search(Model model,@PathVariable String searchTerm) {
    	return stockItemCategory.search(searchTerm.trim());
    }
    
    @RequestMapping({"/save"})
    public StockItemCategoryModel save(@RequestBody StockItemCategoryModel itemCategory) {
		if(itemCategory.getId()==null){
			long now = new java.util.Date().getTime();
			itemCategory.setId(now);
		}
    	return stockItemCategory.save(itemCategory);
    }
}
