package ke.novia.controllers.purchases;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zkplus.spring.DelegatingVariableResolver;

import ke.novia.models.purchase.PurchaseReturnModel;
import ke.novia.services.purchase.PurchaseReturnService;

@RestController
@VariableResolver(DelegatingVariableResolver.class)
@SessionAttributes({"PurchaseReturnViewModel"})
@RequestMapping("/purchaseReturn")
public class PurchaseReturnController {
	@Autowired
	PurchaseReturnService purchaseReturn;
    @RequestMapping({"","/"})
    public ModelAndView index(Model model) {
        return new ModelAndView("stock/PurchaseReturn");
    }
    
    @RequestMapping({"/search","/search/{searchTerm}"})
    public List<PurchaseReturnModel> search(Model model,@PathVariable String searchTerm) {
    	return purchaseReturn.search(searchTerm.trim());
    }
    
    @RequestMapping({"/save"})
    public PurchaseReturnModel save(@RequestBody PurchaseReturnModel retun) {
		if(retun.getId()==null){
			long now = new java.util.Date().getTime();
			retun.setId(now);
		}
    	return purchaseReturn.save(retun);
    }
}
