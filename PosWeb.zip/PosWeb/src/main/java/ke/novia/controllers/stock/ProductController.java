package ke.novia.controllers.stock;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zkplus.spring.DelegatingVariableResolver;


import ke.novia.models.stock.ProductModel;
import ke.novia.services.stock.ProductService;

@RestController
@VariableResolver(DelegatingVariableResolver.class)
@SessionAttributes({"ProductViewModel"})
@RequestMapping("/product")
public class ProductController {
	@Autowired
	ProductService product;
    @RequestMapping({"","/"})
    public ModelAndView index(Model model) {
        return new ModelAndView("stock/Product");
    }
    
    @RequestMapping("/Product/{id}")
    public ProductModel productModel (@PathVariable Long id, Model model){
        model.addAttribute(product.findById(id));
        return product.findById(id);
    }
    
    @RequestMapping({"/search","/search/{searchTerm}"})
    public List<ProductModel> search(Model model,@PathVariable String searchTerm) {
    	return product.search(searchTerm.trim());
    }
    
    @RequestMapping({"/save"})
    public ProductModel save(@RequestBody ProductModel prod ) {
		if(prod.getId()==null){
			long now = new java.util.Date().getTime();
			prod.setId(now);
		}
    	return product.save(prod);
    }
}
