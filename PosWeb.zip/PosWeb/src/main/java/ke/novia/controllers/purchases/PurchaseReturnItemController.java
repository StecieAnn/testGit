package ke.novia.controllers.purchases;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zkplus.spring.DelegatingVariableResolver;

import ke.novia.models.purchase.PurchaseReturnItemModel;
import ke.novia.services.purchase.PurchaseReturnItemService;

@RestController
@VariableResolver(DelegatingVariableResolver.class)
@SessionAttributes({"PurchaseReturnItemViewModel"})
@RequestMapping("/purchaseReturnItem")
public class PurchaseReturnItemController {
	@Autowired
	PurchaseReturnItemService purchaseReturnItem;
    @RequestMapping({"","/"})
    public ModelAndView index(Model model) {
        return new ModelAndView("stock/PurchaseReturnItem");
    }
    
    @RequestMapping({"/search","/search/{searchTerm}"})
    public List<PurchaseReturnItemModel> search(Model model,@PathVariable String searchTerm) {
    	return purchaseReturnItem.search(searchTerm.trim());
    }
    
    @RequestMapping({"/save"})
    public PurchaseReturnItemModel save(@RequestBody PurchaseReturnItemModel returnItem) {
		if(returnItem.getId()==null){
			long now = new java.util.Date().getTime();
			returnItem.setId(now);
		}
    	return purchaseReturnItem.save(returnItem);
    }
}
