package ke.novia;
import org.springframework.boot.Banner;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.annotation.Configuration;

@EnableAutoConfiguration(exclude = { 
    org.springframework.boot.autoconfigure.security.SecurityAutoConfiguration.class 
})
@Configuration
@SpringBootApplication(scanBasePackages = {"ke.novia.config"})

public class Application {
    public static void main(String args[]) {
    	//System.getProperties().put( "server.port", 9000 );
    	//SpringApplication.run(Application.class, args);
        new SpringApplicationBuilder().sources(Application.class).bannerMode(Banner.Mode.OFF).run();
    }
}
/*
import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.zkoss.zk.au.http.DHtmlUpdateServlet;
import org.zkoss.zk.ui.http.DHtmlLayoutServlet;
import org.zkoss.zk.ui.http.HttpSessionListener;

@Configuration
@ComponentScan("ke.novia")
@EnableAutoConfiguration(exclude = { 
	    org.springframework.boot.autoconfigure.security.SecurityAutoConfiguration.class 
	})
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@RequestMapping("/")
	@ResponseBody
	String home() {
		return "hi!";
	}


	@Bean
	public ServletRegistrationBean dHtmlLayoutServlet() {
		Map<String, String> params = new HashMap<String, String>();
		params.put("update-uri", "/zkau");
		DHtmlLayoutServlet dHtmlLayoutServlet = new DHtmlLayoutServlet();
		ServletRegistrationBean reg = new ServletRegistrationBean(dHtmlLayoutServlet, "*.zul");
		reg.setLoadOnStartup(1);
		reg.setInitParameters(params);
		return reg;
	}

	@Bean
	public ServletRegistrationBean dHtmlUpdateServlet() {
		Map<String, String> params = new HashMap<String, String>();
		params.put("update-uri", "/zkau/*");
		ServletRegistrationBean reg = new ServletRegistrationBean(new DHtmlUpdateServlet(), "/zkau/*");
		reg.setLoadOnStartup(2);
		reg.setInitParameters(params);
		return reg;
	}
	
	@Bean
	public HttpSessionListener httpSessionListener() {
		return new HttpSessionListener();
	}

}

*/
// https://www.zkoss.org/wiki/Small_Talks/2012/November/Integrate_ZK_with_Spring_MVC_3

//http://www.springboottutorial.com/spring-boot-starter-projects

//48260 - 111291 Katan
