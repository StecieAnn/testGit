package ke.novia.models.stock;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="stock_item_categories")
@Getter @Setter @ToString
public class StockItemCategoryModel {
	@Id
	private Long id;
	@Column(unique=true,name="category_id")
	private Long categoryId;
	@Column(name="description")
	private String description;
	
}
