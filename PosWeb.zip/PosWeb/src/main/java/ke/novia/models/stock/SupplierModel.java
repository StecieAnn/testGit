package ke.novia.models.stock;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="stock_suppliers")
@Getter @Setter @ToString
public class SupplierModel {
	@Id
	private Long id;
	@Column(name="contact_person")
	private String contactPerson;
	@Column(name="supplier_name")
	private String supplierName;
	@Column(name="supplier_code")
	private String supplierCode;
	@Column(name="phone_number")
	private String phoneNumber;
	@Column(name="physical_location")
	private String physicalLocation;
	@Column(name="email")
	private String 	email;
	
}
