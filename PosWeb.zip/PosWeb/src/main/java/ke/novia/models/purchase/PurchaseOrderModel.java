package ke.novia.models.purchase;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import ke.novia.models.stock.ProductModel;
import ke.novia.models.stock.SupplierModel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "stock_purchase_orders")
@Getter @Setter @ToString
public class PurchaseOrderModel {
	@Id
	private Long id;
	@Column(name = "order_by")
	private String orderBy;
	@Column(name = "description")
	private String description;
	@Column(name = "order_number")
	private String orderNumber;
	@Column(name = "quantity")
	private double quantity;
	@Column(name = "order_from")
	private String orderFrom;
	@Column(name = "deliver_to")
	private String deliverTo;
	@ManyToOne
	@JoinColumn(name = "stock_item_id")
	ProductModel stockItem;
	@ManyToOne
	@JoinColumn(name = "stock_supplier_id")
	SupplierModel supplier;

}
