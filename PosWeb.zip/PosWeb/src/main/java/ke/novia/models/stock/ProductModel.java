package ke.novia.models.stock;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="stock_items")
@Getter @Setter @ToString
public class ProductModel {

	@Id
	private Long id;
	private String code;
	//Item Info	
    @ManyToOne
	@JoinColumn(name="stock_item_category_id")
	StockItemCategoryModel stockItemCategory;
	@ManyToOne
	@JoinColumn(name="product_type_id")
	ProductTypeModel productType;
	@ManyToOne
	@JoinColumn(name="product_brand_id")
	ProductBrandModel productBrand;
	@Column(name="display_name")
	private String displayName;
	@Column(name="description")
	private String description;//or notes
	//Pricing
	@Column(name="tax_rate")
	private double taxRate;
	@Column(name="purchase_price")
	private double purchasePrice;
	@Column(name="selling_price")
	private double sellingPrice;
	@Column(name="discount")
	private double discount;
	//Inventory Maintence
	@Column(name="purchase_unit_of_measure")
	private String purchaseUnitOfMeasure;
	@Column(name="purchase_quantity_per_unit")
	private String purchaseQuantityPerUnit;
	@Column(name="sale_unit_of_measure")
	private String saleUnitOfMeasure;
	@Column(name="sale_quantity_per_unit")
	private String saleQuantityPerUnit;
	//Inventory Maintence
	@Column(name="on_hand_quantity")
	private double onHandQuantity;
	@Column(name="minimum_quantity")
	private double minimumQuantity;
	@Column(name="reorder_quantity")
	private double reorderQuantity;
	@Column(name="last_stock_take_date")
	private Date lastStockTakeDate;
	@Column(name="last_stock_take_quantity")
	private double lastStockTakeQuantity;
	//Item Description
    @ManyToOne
	@JoinColumn(name="stock_supplier_id")
    SupplierModel supplier;
	@Column(name="item_size")
	private String itemSize;
	@Column(name="item_make")
	private String itemMake;
	@Column(name="item_style")
	private String itemStyle;
	@Column(name="item_weight")
	private double itemWeight;
	
}
