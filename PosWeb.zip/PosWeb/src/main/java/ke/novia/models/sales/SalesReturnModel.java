package ke.novia.models.sales;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import ke.novia.models.stock.ProductModel;
import ke.novia.models.stock.StockItemCategoryModel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="sales_returns")
@Getter @Setter @ToString
public class SalesReturnModel {
	@Id
	private Long id;
	@ManyToOne
	@JoinColumn(name="customer_id")
	CustomerModel customer;
	@ManyToOne
    @JoinColumn(name="sales_status_id")
	StatusModel status;	
	@ManyToOne
    @JoinColumn(name="stock_item_category_id")
	StockItemCategoryModel stockItemCategory;
	@ManyToOne
    @JoinColumn(name="stock_item_id")
	ProductModel stockItem;	
	@ManyToOne
    @JoinColumn(name="sales")
	SalesModel sales;
	@Column(name="return_date")
	private Date returnDate;
	@Column(name="reason_for_returning")
	private String reasonForReturning;
	@Column(name="quantity")
	private double quantity;
	
}
