package ke.novia.models.sales;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import ke.novia.models.stock.ProductModel;
import ke.novia.models.stock.StockItemCategoryModel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="sales")
@Getter @Setter @ToString
public class SalesModel {
	@Id
	private Long id;
	@ManyToOne
    @JoinColumn(name="stock_item_id")
	ProductModel stockItem;	
	@ManyToOne
	@JoinColumn(name="customer_id")
	CustomerModel customer;
	@Column(name="order_number")
	private Long orderNumber;
	@ManyToOne
    @JoinColumn(name="sales_status_id")
	StatusModel status;	
	@Column(name="quantity")
	private double quantity;
	@ManyToOne
    @JoinColumn(name="stock_item_category_id")
	StockItemCategoryModel stockItemCategory;
	@ManyToOne
    @JoinColumn(name="sales_tax_id")
	SalesTaxModel salesTax;	
	@Column(name="sales_date")
	private Date salesDate;
	@Column(name="barcode")
	private int barcode;
	@Column(name="serial_number")
	private String serialNumber;
	@Column(name="served_by")
	private String servedBy;
	@Column(name="discount")
	private double discount;
	@Column(name="subtotal")
	private double subtotal;
	@Column(name="total")
	private double total;

	
}
