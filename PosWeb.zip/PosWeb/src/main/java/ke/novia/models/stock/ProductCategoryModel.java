package ke.novia.models.stock;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

import lombok.Getter;
import lombok.Setter;
import lombok.Data;

@Entity
@Table(name = "stock_product_categories")
@Data
public class ProductCategoryModel {

	/**
	 * Primary key.
	 * @param id
	 * New value for id. 10
	 * @return The current value of id. 1000.
	 */
	@Id
	private Long id;
	
	@Column(unique = true, name = "category_id") @Getter @Setter private long categoryId;
	
	/**
	 * Product Description.
	 * 
	 * @param description
	 *            New value for this product description. E.g. Wheat FLour.
	 * @return The current value of this product description. Maize Flour.
	 */
	@NotNull
	@NotEmpty
	@Size(min=4, max=100,message = "Category Too Short")
	private String description;
}
