package ke.novia.models.stock;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="stock_store_modes")
@Getter @Setter @ToString
public class StockStoreModeModel {
	@Id
	private Long id;
	@Column(name="mode")
	private String mode;
	@Column(name="description")
	private String description;
	
}
