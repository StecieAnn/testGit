package ke.novia.models.sales;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="sales_taxes")
@Getter @Setter @ToString
public class SalesTaxModel {
	@Id
	private Long id;
	@Column(name="tax_name")
	private String taxName;
	@Column(name="tax_rate")
	private double taxRate;
	
}
