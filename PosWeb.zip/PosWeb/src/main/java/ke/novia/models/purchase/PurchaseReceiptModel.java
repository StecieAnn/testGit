package ke.novia.models.purchase;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import ke.novia.models.sales.PaymentModeModel;
import ke.novia.models.stock.SupplierModel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="stock_purchase_receipts")
@Getter @Setter @ToString
public class PurchaseReceiptModel {
	@Id
	private Long id;
	@Column(name="grn_no")
	private String grnNo;
	@Column(name="receiving_date")
	private Date receivingDate;
	@ManyToOne
	@JoinColumn(name="stock_purchase_order_id")
	PurchaseOrderModel purchaseOrder;
	@ManyToOne
	@JoinColumn(name="stock_supplier_id")
	SupplierModel supplier;
	@Column(name="delivery_note_no")
	private String deliveryNoteNo;
	@ManyToOne
	@JoinColumn(name="payement_mode_id")
	PaymentModeModel payment;
	@Column(name="comment")
	private String comment;

}
