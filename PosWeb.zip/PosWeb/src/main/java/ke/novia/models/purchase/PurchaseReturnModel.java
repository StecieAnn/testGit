package ke.novia.models.purchase;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import ke.novia.models.stock.ProductModel;
import ke.novia.models.stock.StockItemCategoryModel;
import ke.novia.models.stock.SupplierModel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Entity
@Table(name="stock_purchase_returns")
@Getter @Setter @ToString
public class PurchaseReturnModel {
	@Id
	private Long id;
	@ManyToOne
	@JoinColumn(name="stock_supplier_id")
    SupplierModel supplier;
	@ManyToOne
	@JoinColumn(name="stock_purchase_receipt_id")
	PurchaseReceiptModel purchaseReceipt;
	@ManyToOne
	@JoinColumn(name="stock_item_category_id")
	StockItemCategoryModel stockItemCategory;
	@ManyToOne
	@JoinColumn(name="stock_item_id")
	ProductModel stockItem;
	@Column(name="return_number")
	private String returnNumber;
	@Column(name="quantity")
	private double quantity;
	@Column(name="comment")
	private String comment;

}