package ke.novia.models.stock;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="non_returnable_items")
@Getter @Setter @ToString
public class NonReturnableItemModel {
	@Id
	private Long id;
	@ManyToOne
	@JoinColumn(name = "stock_item_id")
	ProductModel stockItem;
	@Column(name="quantity")
	private double quantity;
	
}
