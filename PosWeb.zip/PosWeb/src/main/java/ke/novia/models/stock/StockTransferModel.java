package ke.novia.models.stock;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="stock_transfers")
@Getter @Setter @ToString
public class StockTransferModel {
	@Id
	private Long id;	
	@ManyToOne
    @JoinColumn(name="stock_item_category_id")
	StockItemCategoryModel stockItemCategory;
	@ManyToOne
    @JoinColumn(name="stock_item_id")
	ProductModel stockItem;
	@Column(name="transfer_date")
	private Date transferDate;
	@Column(name="quantity")
	private double quantity;
	@Column(name="destination")
	private String destination;
	@Column(name="source")
	private String source;

	
}

