package ke.novia.models.purchase;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import ke.novia.models.stock.ProductModel;
import ke.novia.models.stock.StockItemCategoryModel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Entity
@Table(name="stock_purchase_receipt_items")
@Getter
@Setter
@ToString
public class PurchaseReceiptItemModel {
	@Id
	private Long id;
    @ManyToOne
    @JoinColumn(name="stock_purchase_receipt_id")
    PurchaseReceiptModel purchaseReceipt;
	@ManyToOne
    @JoinColumn(name="stock_item_category_id")
	StockItemCategoryModel stockItemCategory;
	@ManyToOne
    @JoinColumn(name="stock_item_id")
	ProductModel stockItem;	
	@Column(name="quantity")
	private double quantity;//purchaseUnits
	@Column(name="total_quantity")
	private double totalQuantity;//purchaseQuantityPerUnit*quantity
	@Column(name="unit_price")
	private double unitPrice;
	
}