package ke.novia.services.purchase;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import ke.novia.dao.purchase.PurchaseReturnDao;
import ke.novia.models.purchase.PurchaseReturnModel;
@Service
public class PurchaseReturnService{// implements PurchaseReturnService {
	
	@Autowired
	private PurchaseReturnDao purchaseReturnDao;
	public PurchaseReturnModel save(PurchaseReturnModel entity) {
		return purchaseReturnDao.save(entity);
	}
	public boolean delete(PurchaseReturnModel entity) {
		long id = entity.getId();
		purchaseReturnDao.delete(id);
		return purchaseReturnDao.findOne(id)==null;
	}
	public List<PurchaseReturnModel> findAll() {
		return purchaseReturnDao.findAll();
	}
	public List<PurchaseReturnModel> search(String searchTerm) {
		return purchaseReturnDao.findBysupplier(searchTerm, new PageRequest(0,10));
	}

}
