package ke.novia.services.sales;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import ke.novia.dao.sales.SalesDao;
import ke.novia.dao.sales.SalesReturnDao;
import ke.novia.dao.stock.ProductDao;
import ke.novia.models.sales.SalesReturnModel;


@Service
public class SalesReturnService{
	
	@Autowired
	private SalesReturnDao salesReturnDao;
	
	@Autowired
	private ProductDao productDao;
	
	@Autowired
	private SalesDao salesDao;
	
	public SalesReturnModel save(SalesReturnModel entity) {
		SalesReturnModel salesReturnModel =salesReturnDao.save(entity);
		if(salesReturnModel!=null && salesReturnModel.getId()>0){
			productDao.incrementStock(salesReturnModel.getStockItem().getId(), salesReturnModel.getQuantity());
			salesDao.decrementQuantity(salesReturnModel.getSales().getId(),salesReturnModel.getQuantity());
		}
		return salesReturnModel;
	}
	public boolean delete(SalesReturnModel entity) {
		long id = entity.getId();
		salesReturnDao.delete(id);
		return salesReturnDao.findOne(id)==null;
	}
	public List<SalesReturnModel>findAll() {
		return salesReturnDao.findAll();
	}
	public List<SalesReturnModel> search(String searchTerm) {
		return salesReturnDao.findBycustomer(searchTerm, new PageRequest(0,10));
	}
	

}
