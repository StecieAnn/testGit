package ke.novia.services.stock;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import ke.novia.dao.stock.ProductBrandDao;
import ke.novia.models.stock.ProductBrandModel;

@Service
public class ProductBrandService{
	
	@Autowired
	private ProductBrandDao productBrandDao;
	public ProductBrandModel save(ProductBrandModel entity) {
		return productBrandDao.save(entity);
	}
	public boolean delete(ProductBrandModel entity) {
		long id = entity.getId();
		productBrandDao.delete(id);
		return productBrandDao.findOne(id)==null;
	}
	public List<ProductBrandModel>findAll() {
		return productBrandDao.findAll();
	}
	public List<ProductBrandModel> search(String searchTerm) {
		return productBrandDao.findBydescription(searchTerm, new PageRequest(0,10));
	}
	

}
