package ke.novia.services.stock;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import ke.novia.dao.stock.StockTransferDao;
import ke.novia.models.stock.StockTransferModel;
@Service
public class StockTransferService{
	
	@Autowired
	private StockTransferDao stockTransferDao;
	public StockTransferModel save(StockTransferModel entity) {
		return stockTransferDao.save(entity);
	}
	public boolean delete(StockTransferModel entity) {
		long id = entity.getId();
		stockTransferDao.delete(id);
		return stockTransferDao.findOne(id)==null;
	}
	public List<StockTransferModel> findAll() {
		return stockTransferDao.findAll();
	}
	public List<StockTransferModel> search(String searchTerm) {
		return stockTransferDao.findBystockItem(searchTerm, new PageRequest(0,10));
	}

}
