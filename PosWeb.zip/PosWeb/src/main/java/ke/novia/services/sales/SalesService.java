package ke.novia.services.sales;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import ke.novia.dao.sales.SalesDao;
import ke.novia.dao.stock.ProductDao;
import ke.novia.models.sales.SalesModel;


@Service
public class SalesService{
	
	@Autowired
	private SalesDao salesDao;
	
	@Autowired
	private ProductDao productDao;
	
	public SalesModel save(SalesModel entity) {
		SalesModel salesModel = salesDao.save(entity);
		if(salesModel !=null && salesModel.getId()>0){
		//decrement the stock
			productDao.decrementStock(salesModel.getStockItem().getId(), salesModel.getQuantity());
		}
		 return salesModel;
	}
	public boolean delete(SalesModel entity) {
		long id = entity.getId();
		salesDao.delete(id);
		return salesDao.findOne(id)==null;
	}
	public SalesModel findbyId(Long id){
		return salesDao.findOne(id);
	}
	public List<SalesModel>findAll() {
		 return salesDao.findAll();
	}
	public List<SalesModel> search(String searchTerm) {
		 return salesDao.findBystockItem(searchTerm, new PageRequest(0,10));
	}
	

}
