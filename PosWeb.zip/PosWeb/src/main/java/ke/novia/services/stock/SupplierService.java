package ke.novia.services.stock;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import ke.novia.dao.stock.SupplierDao;
import ke.novia.models.stock.SupplierModel;
@Service
public class SupplierService{
	
	@Autowired
	private SupplierDao supplierDao;
	public SupplierModel save(SupplierModel entity) {
		return supplierDao.save(entity);
	}
	public boolean delete(SupplierModel entity) {
		long id = entity.getId();
		supplierDao.delete(id);
		return supplierDao.findOne(id)==null;
	}
	public List<SupplierModel> findAll() {
		return supplierDao.findAll();
	}
	public List<SupplierModel> search(String searchTerm) {
		return supplierDao.findBysupplierName(searchTerm, new PageRequest(0,10));
	}

}
