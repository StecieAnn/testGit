package ke.novia.services.stock;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import ke.novia.dao.stock.ConsumerStoreDao;
import ke.novia.dao.stock.ProductDao;
import ke.novia.models.stock.ConsumerStoreModel;


@Service
public class ConsumerStoreService{
	
	@Autowired
	private ConsumerStoreDao consumerStoreDao;
	
	@Autowired
	private ProductDao productDao;
	
	public ConsumerStoreModel save(ConsumerStoreModel entity) {
		ConsumerStoreModel consumerStoreModel=consumerStoreDao.save(entity);
		if(consumerStoreModel!=null && consumerStoreModel.getId()>0){
			productDao.decrementStock(consumerStoreModel.getStockItem().getId(), consumerStoreModel.getQuantity());	
		}
		return consumerStoreModel;
	}
	public boolean delete(ConsumerStoreModel entity) {
		long id = entity.getId();
		consumerStoreDao.delete(id);
		return consumerStoreDao.findOne(id)==null;
	}
	public List<ConsumerStoreModel>findAll() {
		return consumerStoreDao.findAll();
	}
	public ConsumerStoreModel getById(Long id){
		return consumerStoreDao.findOne(id);
	}
	public List<ConsumerStoreModel> search(String searchTerm) {
		return consumerStoreDao.findBystockItem(searchTerm, new PageRequest(0,10));
	}
	

}
