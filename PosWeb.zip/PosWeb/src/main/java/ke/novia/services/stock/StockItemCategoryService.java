package ke.novia.services.stock;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import ke.novia.dao.stock.StockItemCategoryDao;
import ke.novia.models.stock.StockItemCategoryModel;
@Service
public class StockItemCategoryService{
	
	@Autowired
	private StockItemCategoryDao stockItemCategoryDao;
	public StockItemCategoryModel save(StockItemCategoryModel entity) {
		return stockItemCategoryDao.save(entity);
	}
	public boolean delete(StockItemCategoryModel entity) {
		long id = entity.getId();
		stockItemCategoryDao.delete(id);
		return stockItemCategoryDao.findOne(id)==null;
	}
	public List<StockItemCategoryModel>findAll() {
		return stockItemCategoryDao.findAll();
	}
	
	public List<StockItemCategoryModel> search(String searchTerm) {
		return stockItemCategoryDao.findBydescription(searchTerm, new PageRequest(0,10));
	}

}
