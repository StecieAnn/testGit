package ke.novia.services.sales;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import ke.novia.dao.sales.PaymentModeDao;
import ke.novia.models.sales.PaymentModeModel;
@Service
public class PaymentModeService{
	
	@Autowired
	private PaymentModeDao paymentModeDao;
	public PaymentModeModel save(PaymentModeModel entity) {
		return paymentModeDao.save(entity);
	}
	public boolean delete(PaymentModeModel entity) {
		long id = entity.getId();
		paymentModeDao.delete(id);
		return paymentModeDao.findOne(id)==null;
	}
	public List<PaymentModeModel> findAll() {
		return paymentModeDao.findAll();
	}
	public List<PaymentModeModel> search(String searchTerm) {
		return paymentModeDao.findBydescription(searchTerm, new PageRequest(0,10));
	}

}
