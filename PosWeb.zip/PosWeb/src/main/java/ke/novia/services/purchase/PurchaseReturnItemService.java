package ke.novia.services.purchase;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import ke.novia.dao.purchase.PurchaseReturnItemDao;
import ke.novia.dao.stock.ProductDao;
import ke.novia.models.purchase.PurchaseReturnItemModel;
@Service
public class PurchaseReturnItemService{
	
	@Autowired
	private PurchaseReturnItemDao purchaseReturnItemDao;
	@Autowired
	private ProductDao productDao;
	
	public PurchaseReturnItemModel save(PurchaseReturnItemModel entity) {
		PurchaseReturnItemModel purchaseReturnItemModel= purchaseReturnItemDao.save(entity);
		if(purchaseReturnItemModel!=null && purchaseReturnItemModel.getId()>0){
			productDao.decrementStock(purchaseReturnItemModel.getStockItem().getId(),purchaseReturnItemModel.getQuantity());	
		}
			
		
		return purchaseReturnItemModel;
	}
	public boolean delete(PurchaseReturnItemModel entity) {
		long id = entity.getId();
		purchaseReturnItemDao.delete(id);
		return purchaseReturnItemDao.findOne(id)==null;
	}
	public List<PurchaseReturnItemModel>findAll() {
		return purchaseReturnItemDao.findAll();
	}
	public List<PurchaseReturnItemModel> search(String searchTerm) {
		return purchaseReturnItemDao.findBystockItemCategory(searchTerm, new PageRequest(0,10));
	}

}
