package ke.novia.services.sales;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import ke.novia.dao.sales.SalesTaxDao;
import ke.novia.models.sales.SalesTaxModel;


@Service
public class SalesTaxService{
	
	@Autowired
	private SalesTaxDao salesTaxDao;
	public SalesTaxModel save(SalesTaxModel entity) {
		 return salesTaxDao.save(entity);
	}
	public boolean delete(SalesTaxModel entity) {
		long id = entity.getId();
		salesTaxDao.delete(id);
		return salesTaxDao.findOne(id)==null;
	}
	public List<SalesTaxModel>findAll() {
		 return salesTaxDao.findAll();
	}
	public List<SalesTaxModel> search(String searchTerm) {
		 return salesTaxDao.findBytaxName(searchTerm, new PageRequest(0,10));
	}
	

}
