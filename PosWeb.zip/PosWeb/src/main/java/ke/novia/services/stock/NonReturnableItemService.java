package ke.novia.services.stock;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import ke.novia.dao.stock.NonReturnableItemDao;
import ke.novia.dao.stock.ProductDao;
import ke.novia.models.stock.NonReturnableItemModel;


@Service
public class NonReturnableItemService{
	
	@Autowired
	private NonReturnableItemDao nonReturnableItemDao;
	
	@Autowired
	private ProductDao productDao;
	
	public NonReturnableItemModel save(NonReturnableItemModel entity) {
		NonReturnableItemModel nonReturnableItemModel=nonReturnableItemDao.save(entity);
		if(nonReturnableItemModel!=null && nonReturnableItemModel.getId()>0){
			productDao.decrementStock(nonReturnableItemModel.getStockItem().getId(), nonReturnableItemModel.getQuantity());	
		}
		return nonReturnableItemModel;
	}
	public boolean delete(NonReturnableItemModel entity) {
		long id = entity.getId();
		nonReturnableItemDao.delete(id);
		return nonReturnableItemDao.findOne(id)==null;
	}
	public List<NonReturnableItemModel>findAll() {
		return nonReturnableItemDao.findAll();
	}
	public NonReturnableItemModel getById(Long id){
		return nonReturnableItemDao.findOne(id);
	}
	public List<NonReturnableItemModel> search(String searchTerm) {
		return nonReturnableItemDao.findBystockItem(searchTerm, new PageRequest(0,10));
	}

}
