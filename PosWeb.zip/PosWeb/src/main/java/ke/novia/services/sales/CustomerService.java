package ke.novia.services.sales;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import ke.novia.dao.sales.CustomerDao;
import ke.novia.models.sales.CustomerModel;


@Service
public class CustomerService{
	
	@Autowired
	private CustomerDao customerDao;
	public CustomerModel save(CustomerModel entity) {
		return customerDao.save(entity);
	}
	public boolean delete(CustomerModel entity) {
		long id = entity.getId();
		customerDao.delete(id);
		return customerDao.findOne(id)==null;
	}
	public List<CustomerModel>findAll() {
		return customerDao.findAll();
	}
	public List<CustomerModel> search(String searchTerm) {
		return customerDao.findBycustomerName(searchTerm, new PageRequest(0,10));
	}
	

}
