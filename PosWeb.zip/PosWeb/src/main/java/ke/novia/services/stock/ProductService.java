package ke.novia.services.stock;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import ke.novia.dao.purchase.PurchaseReceiptItemDao;
import ke.novia.dao.purchase.PurchaseReturnItemDao;
import ke.novia.dao.sales.SalesDao;
import ke.novia.dao.sales.SalesReturnDao;
import ke.novia.dao.stock.ProductDao;
import ke.novia.dao.stock.StockTakeDao;
import ke.novia.models.purchase.PurchaseReceiptItemModel;
import ke.novia.models.purchase.PurchaseReturnItemModel;
import ke.novia.models.sales.SalesModel;
import ke.novia.models.sales.SalesReturnModel;
import ke.novia.models.stock.ProductModel;
import ke.novia.models.stock.StockTakeModel;
@Service
public class ProductService{
	
	@Autowired
	private ProductDao productDao;
	@Autowired
	private PurchaseReceiptItemDao purchaseReceiptItemDao;
	
	@Autowired
	private PurchaseReturnItemDao purchaseReturnItemDao;
	
	@Autowired
	private SalesDao salesDao;
	
	@Autowired
	private StockTakeDao stockTakeDao;
	
	
	@Autowired
	private SalesReturnDao salesReturnDao;
	
	public ProductModel save(ProductModel entity) {
		return productDao.save(entity);
	}
	public boolean delete(ProductModel entity) {
		long id = entity.getId();
		productDao.delete(id);
		return productDao.findOne(id)==null;
	}
	public ProductModel findById(Long id){
		return productDao.findOne(id);
	}	
	public List<ProductModel> findAll() {
		return productDao.findAll();
	}
	public PurchaseReceiptItemModel getByQuantity(Long id){
		return purchaseReceiptItemDao.findOne(id);
	}
	public StockTakeModel getByquantity(Long id){
		return stockTakeDao.findOne(id);
	}
	public PurchaseReturnItemModel getByQnty(Long id){
		return purchaseReturnItemDao.findOne(id);
	}
	public SalesReturnModel getByqnty(Long id){
		return salesReturnDao.findOne(id);
	}
	public SalesModel getByqntty(Long id){
		return salesDao.findOne(id);
	}

	public List<ProductModel> search(String searchTerm) {
		return productDao.findBydisplayName(searchTerm, new PageRequest(0,10));
	}

}
