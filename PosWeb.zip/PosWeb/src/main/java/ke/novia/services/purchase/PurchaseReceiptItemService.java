package ke.novia.services.purchase;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import ke.novia.dao.purchase.PurchaseReceiptItemDao;
import ke.novia.dao.stock.ProductDao;
import ke.novia.models.purchase.PurchaseReceiptItemModel;
@Service
public class PurchaseReceiptItemService{
	
	@Autowired
	private PurchaseReceiptItemDao purchaseReceiptItemDao;
	
	@Autowired
	private ProductDao productDao;
	
	public PurchaseReceiptItemModel save(PurchaseReceiptItemModel entity) {
		PurchaseReceiptItemModel purchaseReceiptItemModel=purchaseReceiptItemDao.save(entity);
		if(purchaseReceiptItemModel!= null && purchaseReceiptItemModel.getId()>0){
			//We increment stock
			productDao.incrementStock(purchaseReceiptItemModel.getStockItem().getId(), purchaseReceiptItemModel.getQuantity());
		}
		return purchaseReceiptItemModel ;
	}
	public boolean delete(PurchaseReceiptItemModel entity) {
		long id = entity.getId();
		purchaseReceiptItemDao.delete(id);
		return purchaseReceiptItemDao.findOne(id)==null;
	}
	public List<PurchaseReceiptItemModel> findAll() {
		return purchaseReceiptItemDao.findAll();
	}
	
	public PurchaseReceiptItemModel findById(Long id){
		return purchaseReceiptItemDao.findOne(id);
	}
	public List<PurchaseReceiptItemModel> search(String searchTerm) {
		return purchaseReceiptItemDao.findBystockItemCategory(searchTerm, new PageRequest(0,10));
	}

}
