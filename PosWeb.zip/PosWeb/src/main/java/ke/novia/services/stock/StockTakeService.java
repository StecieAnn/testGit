package ke.novia.services.stock;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
//import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import ke.novia.dao.stock.StockTakeDao;
import ke.novia.dao.stock.ProductDao;
import ke.novia.models.stock.StockTakeModel;


@Service
public class StockTakeService{
	
	@Autowired
	private StockTakeDao stockTakeDao;
	
	@Autowired
	private ProductDao productDao;
	
	public StockTakeModel save(StockTakeModel entity) {
		StockTakeModel stockTakeModel=stockTakeDao.save(entity);
		if(stockTakeModel!=null && stockTakeModel.getId()>0){
			productDao.incrementQuantity(stockTakeModel.getStockItem().getId(), stockTakeModel.getQuantity());
			productDao.decrementStock(stockTakeModel.getStockItem().getId(), stockTakeModel.getQuantity());
		}
		return stockTakeModel;
	}
	public boolean delete(StockTakeModel entity) {
		long id = entity.getId();
		stockTakeDao.delete(id);
		return stockTakeDao.findOne(id)==null;
	}
	public List<StockTakeModel>findAll() {
		return stockTakeDao.findAll();
	}
	public StockTakeModel getById(Long id){
		return stockTakeDao.findOne(id);
	}
	public List<StockTakeModel> search(String searchTerm) {
		return stockTakeDao.findBystockItem(searchTerm, new PageRequest(0,10));
	}
	

}
