package ke.novia.services.stock;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import ke.novia.dao.stock.StockStoreModeDao;
import ke.novia.models.stock.StockStoreModeModel;
@Service
public class StockStoreModeService{
	
	@Autowired
	private StockStoreModeDao stockStoreModeDao;
	public StockStoreModeModel save(StockStoreModeModel entity) {
		return stockStoreModeDao.save(entity);
	}
	public boolean delete(StockStoreModeModel entity) {
		long id = entity.getId();
		stockStoreModeDao.delete(id);
		return stockStoreModeDao.findOne(id)==null;
	}
	public List<StockStoreModeModel>findAll(){
		return stockStoreModeDao.findAll();
	}
	public List<StockStoreModeModel> search(String searchTerm) {
		return stockStoreModeDao.findBydescription(searchTerm, new PageRequest(0,10));
	}

}
