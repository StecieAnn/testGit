package ke.novia.services.purchase;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import ke.novia.dao.purchase.PurchaseReceiptDao;
import ke.novia.dao.stock.SupplierDao;
import ke.novia.models.purchase.PurchaseReceiptModel;
import ke.novia.models.stock.SupplierModel;
@Service
public class PurchaseReceiptService{
	
	@Autowired
	private PurchaseReceiptDao purchaseReceiptDao;
	
	@Autowired
	private SupplierDao supplierDao;
	
	public PurchaseReceiptModel save(PurchaseReceiptModel entity) {
		return purchaseReceiptDao.save(entity);
	}
	public boolean delete(PurchaseReceiptModel entity) {
		long id = entity.getId();
		purchaseReceiptDao.delete(id);
		return purchaseReceiptDao.findOne(id)==null;
	}
	public List<PurchaseReceiptModel>findAll() {
		return purchaseReceiptDao.findAll();
	}
	public SupplierModel getBySupplierName(Long id){
		return supplierDao.findOne(id);
	}
	public List<PurchaseReceiptModel> search(String searchTerm) {
		return purchaseReceiptDao.findBycomment(searchTerm, new PageRequest(0,10));
	}

}
