package ke.novia.services.purchase;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import ke.novia.dao.purchase.PurchaseOrderDao;
import ke.novia.models.purchase.PurchaseOrderModel;
@Service
public class PurchaseOrderService{// implements ProductCategoryService {
	
	@Autowired
	private PurchaseOrderDao stockOrderDao;
	public PurchaseOrderModel save(PurchaseOrderModel entity) {
		return stockOrderDao.save(entity);
	}
	public boolean delete(PurchaseOrderModel entity) {
		long id = entity.getId();
		stockOrderDao.delete(id);
		return stockOrderDao.findOne(id)==null;
	}
	public List<PurchaseOrderModel> findAll() {
		return stockOrderDao.findAll();
	}
	public List<PurchaseOrderModel> search(String searchTerm) {
		return stockOrderDao.findByorderNumber(searchTerm, new PageRequest(0,10));
	}

}
