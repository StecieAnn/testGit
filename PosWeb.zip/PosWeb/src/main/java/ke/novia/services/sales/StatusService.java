package ke.novia.services.sales;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import ke.novia.dao.sales.StatusDao;
import ke.novia.models.sales.StatusModel;


@Service
public class StatusService{
	
	@Autowired
	private StatusDao statusDao;
	public StatusModel save(StatusModel entity) {
		return statusDao.save(entity);
	}
	public boolean delete(StatusModel entity) {
		long id = entity.getId();
		statusDao.delete(id);
		return statusDao.findOne(id)==null;
	}
	public List<StatusModel>findAll() {
		return statusDao.findAll();
	}
	public List<StatusModel> search(String searchTerm) {
		return statusDao.findBydescription(searchTerm, new PageRequest(0,10));
	}
	

}
