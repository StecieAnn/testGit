package ke.novia.services.stock;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import ke.novia.dao.stock.ProductTypeDao;
import ke.novia.models.stock.ProductTypeModel;
@Service
public class ProductTypeService{
	
	@Autowired
	private ProductTypeDao productTypeDao;
	public ProductTypeModel save(ProductTypeModel entity) {
		return productTypeDao.save(entity);
	}
	public boolean delete(ProductTypeModel entity) {
		long id = entity.getId();
		productTypeDao.delete(id);
		return productTypeDao.findOne(id)==null;
	}
	public List<ProductTypeModel> findAll() {
		return productTypeDao.findAll();
	}
	public List<ProductTypeModel> search(String searchTerm) {
		return productTypeDao.findBydescription(searchTerm, new PageRequest(0,10));
	}

}
