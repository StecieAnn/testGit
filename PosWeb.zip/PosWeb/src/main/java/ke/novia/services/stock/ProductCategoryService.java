package ke.novia.services.stock;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import ke.novia.dao.stock.ProductCategoryDao;
import ke.novia.models.stock.ProductCategoryModel;
@Service
public class ProductCategoryService{// implements ProductCategoryService {
	
	@Autowired
	private ProductCategoryDao productCategoryDao;
	public ProductCategoryModel save(ProductCategoryModel entity) {
		return productCategoryDao.save(entity);
	}
	public boolean delete(ProductCategoryModel entity) {
		long id = entity.getId();
		productCategoryDao.delete(id);
		return productCategoryDao.findOne(id)==null;
	}
	public List<ProductCategoryModel> search(String searchTerm) {
		System.err.println(searchTerm);
		return productCategoryDao.findBydescription(searchTerm, new PageRequest(0,10));
	}

}
