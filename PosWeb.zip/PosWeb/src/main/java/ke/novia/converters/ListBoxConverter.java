package ke.novia.converters;

import java.lang.reflect.InvocationTargetException;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.beanutils.BeanUtilsBean;
import org.zkoss.bind.BindContext;
import org.zkoss.bind.Converter;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.UiException;
import org.zkoss.zul.Combobox;
import org.zkoss.zul.Comboitem;
import org.zkoss.zul.ListModel;
import org.zkoss.zul.Listbox;
import org.zkoss.zul.Radiogroup;
import org.zkoss.zul.ext.Selectable;

/**
 * Convert combobox selected comboitem to bean and vice versa.
 * @author henrichen
 * @author dennis
 * @since 6.0.0
 */
public class ListBoxConverter implements Converter, java.io.Serializable {
	private static final long serialVersionUID = 201108171811L;

	@SuppressWarnings("unchecked")
	public Object coerceToUi(Object val, Component comp, BindContext ctx) {
		Listbox cbx = (Listbox) comp;
		final ListModel<?> model = cbx.getModel();
		//ZK-762 selection of ListModelList is not correct if binding to selectedItem
		if (model != null && !(model instanceof Selectable)) {
			//model has to implement Selectable if binding to selectedItem
			throw new UiException("model doesn't implement Selectable");
		}
		String sourcetVal = null;
		try {
			sourcetVal = BeanUtilsBean.getInstance().getProperty(val, "id");
		} catch (Exception e) { e.printStackTrace();}
		if(sourcetVal==null){
			return null;
		}
		//Notice, clear selection will cause combobox fire onAfterRender, and then reload selectedItem , 
		//it cause infinity loop
		//System.out.println(val);
		if (val != null) {
			if (model != null) {
				List<Object> ObjectList = (List<Object>) model;
				Object selectedItem = null;
				try {
					int itemCount = ObjectList.size();
					if(sourcetVal!=null)
		            for(int i =0 ; i<itemCount ; i++){
		            	String tempVal = BeanUtilsBean.getInstance().getProperty(model.getElementAt(i), "id");
						//System.out.println(tempVal);
						if(sourcetVal.equals(tempVal)){
							//System.out.println("Yipeeeeee! We have a match.");
							selectedItem = cbx.getItemAtIndex(i);
							cbx.setSelectedIndex(i);
							break;
						}
					}				
				
				} catch (Exception e) { e.printStackTrace();}
				return selectedItem;
			}
		}
		//nothing matched, clean the old selection
		if (model != null) {
			Set<Object> sels = ((Selectable<Object>) model).getSelection();
			if (sels != null && sels.size() > 0)
				((Selectable<Object>) model).clearSelection();
			return IGNORED_VALUE;
		}
		return null;
	}
	public Object coerceToBean(Object val, Component comp, BindContext ctx) {
		if (val != null) {
			final Listbox lbx = (Listbox) comp;
			final ListModel<?> model = lbx.getModel();
			if (model != null && !(model instanceof Selectable)) {
				throw new UiException("model doesn't implement Selectable");
			}
			if (model != null) {
				Set<?> selection = ((Selectable<?>) model).getSelection();
				if (selection == null || selection.size() == 0)
					return null;
				return selection.iterator().next();
			} else { //no model
				return ((Comboitem) val).getValue();
			}
		}
		return null;
	}
}


//https://github.com/zkoss/zk/blob/master/zkbind/src/org/zkoss/bind/converter/sys/ComboboxSelectedItemConverter.java

//https://fossies.org/diffs/zk-src/8.0.1.1_vs_8.0.2.2/zkbind/src/org/zkoss/bind/converter/sys/ComboboxSelectedItemConverter.java-diff.html