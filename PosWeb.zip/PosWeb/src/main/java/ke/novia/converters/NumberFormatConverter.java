package ke.novia.converters;

import java.text.NumberFormat;

import org.zkoss.bind.BindContext;
import org.zkoss.bind.Converter;
import org.zkoss.zk.ui.Component;

public class NumberFormatConverter implements Converter {
    public Object coerceToBean(Object val, Component comp, BindContext ctx) {
        return null;
    }

    public Object coerceToUi(Object val, Component comp, BindContext ctx) {

        if(!(val instanceof Integer)) {
            throw new IllegalArgumentException("The argument must be a number!");
        }

        final Object tmp = ctx.getConverterArg("length");
        int length = 0;

        if(tmp instanceof Integer) {
            length = (Integer)tmp;
        }

        final NumberFormat nf = NumberFormat.getInstance();
        nf.setMaximumFractionDigits(length);

        return nf.format(val);
    }
}
//<label value="@load(vm.message) @converter(ke.novia.converters.NumberFormatConverter)"/>
