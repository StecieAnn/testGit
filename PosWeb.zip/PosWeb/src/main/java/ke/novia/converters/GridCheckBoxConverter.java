package ke.novia.converters;

import java.lang.reflect.InvocationTargetException;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.beanutils.BeanUtilsBean;
import org.zkoss.bind.BindContext;
import org.zkoss.bind.Converter;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.UiException;
import org.zkoss.zul.Checkbox;
import org.zkoss.zul.Combobox;
import org.zkoss.zul.Comboitem;
import org.zkoss.zul.Grid;
import org.zkoss.zul.ListModel;
import org.zkoss.zul.Radiogroup;
import org.zkoss.zul.Row;
import org.zkoss.zul.Rows;
import org.zkoss.zul.ext.Selectable;

/**
 * Convert combobox selected comboitem to bean and vice versa.
 * @author henrichen
 * @author dennis
 * @since 6.0.0
 */
public class GridCheckBoxConverter implements Converter, java.io.Serializable {
	private static final long serialVersionUID = 201108171811L;

	@SuppressWarnings("unchecked")
	public Object coerceToUi(Object val, Component comp, BindContext ctx) {
		Grid cbx = (Grid) comp;
		final List<Object> listVals =(List<Object>) val;
		final ListModel<?> model = cbx.getModel();
		//ZK-762 selection of ListModelList is not correct if binding to selectedItem
		if (model != null && !(model instanceof Selectable)) {
			//model has to implement Selectable if binding to selectedItem
			throw new UiException("model doesn't implement Selectable");
		}
		//Notice, clear selection will cause combobox fire onAfterRender, and then reload selectedItem , 
		//it cause infinity loop
		//System.out.println(val);
		if (val != null) {
			if (model != null) {
				List<Object> ObjectList = (List<Object>) model;
				Object selectedItem = null;
				try {
					//String sourcetVal = BeanUtilsBean.getInstance().getProperty(val, "id");
					if(ObjectList.size()>0){
						
				        Rows rows = (Rows) cbx.getRows();
				        List gridrow = (List) rows.getChildren();
				        Iterator itrows = gridrow.iterator();
				        while (itrows.hasNext()) {
				            Row row = (Row) itrows.next();
				            List rowChild = row.getChildren();
				            Iterator itChild = rowChild.iterator();
				            //Checkbox chkALL = new Checkbox();
				            while (itChild.hasNext()) {
				                Object obj = (Object) itChild.next();
				                String objSimpleName = obj.getClass().getSimpleName().toString();
				                if (objSimpleName.equalsIgnoreCase("Checkbox")) {
				                	Checkbox currentCheckbox = (Checkbox)obj;
				                	//System.out.println(val.toString()+" - "+currentCheckbox.getValue().toString());
				                	for(int i=0; i<listVals.size();i++){
					                	if(listVals.get(i).equals(currentCheckbox.getValue())){
						                	System.out.println(val);
						                	break;
					                	}	
				                	}
				                	/*
				                    chkALL = (Checkbox) obj;
				                    if (chkAll.isChecked()) {
				                        chkALL.setChecked(true);
				                    } else {
				                        chkALL.setChecked(false);
				                    }
				                    */
				                }
				            }
				        }						
						/*
						List<Component> list = comp.getChildren();
						for(Component child:list){
							if (child instanceof Rows){
								List<Component> rowsList = child.getChildren();
								for(Component columns:rowsList){
									System.out.println(columns);
									
									List<Component> columnsList = columns.getChildren();
									for(Component rowColumnsList:columnsList){
										List<Component> rowC = rowColumnsList.getChildren();
										for(Component c:rowC){
											if (c instanceof Checkbox){
												Checkbox chk = (Checkbox)c;
												//System.err.println(chk.getValue()+" - "+chk.isChecked());
											}
										}
									}
									
								}
								
							}
						}
						*/
						/*
						for(int i =0 ; i<ObjectList.size() ; i++){
							if(ObjectList.get(i) is in
							//Checkbox checkbox = (Checkbox) event.getOrigin().getTarget();
						
						}
						*/
					}
					//System.out.println(ObjectList);
					/*
					int itemCount = ObjectList.size();
		            for(int i =0 ; i<itemCount ; i++){
		            	String tempVal = BeanUtilsBean.getInstance().getProperty(model.getElementAt(i), "id");
						//System.out.println(tempVal);
						if(sourcetVal.equals(tempVal)){
							System.out.println("Yipeeeeee! We have a match.");
							selectedItem = cbx.getItemAtIndex(i);
							cbx.setSelectedIndex(i);
							break;
						}
					}				
		            */
				} catch (Exception e) { e.printStackTrace();}
				return selectedItem;
			}
		}
		//nothing matched, clean the old selection
		if (model != null) {
			Set<Object> sels = ((Selectable<Object>) model).getSelection();
			if (sels != null && sels.size() > 0)
				((Selectable<Object>) model).clearSelection();
			return IGNORED_VALUE;
		}
		return null;
	}
	public Object coerceToBean(Object val, Component comp, BindContext ctx) {
		
		System.out.println(val);
		
		/*
		if (val != null) {
			final Radiogroup lbx = (Radiogroup) comp;
			final ListModel<?> model = lbx.getModel();
			if (model != null && !(model instanceof Selectable)) {
				throw new UiException("model doesn't implement Selectable");
			}
			if (model != null) {
				Set<?> selection = ((Selectable<?>) model).getSelection();
				if (selection == null || selection.size() == 0)
					return null;
				return selection.iterator().next();
			} else { //no model
				return ((Comboitem) val).getValue();
			}
		}
		*/
		return null;
	}
}


//https://github.com/zkoss/zk/blob/master/zkbind/src/org/zkoss/bind/converter/sys/ComboboxSelectedItemConverter.java

//https://fossies.org/diffs/zk-src/8.0.1.1_vs_8.0.2.2/zkbind/src/org/zkoss/bind/converter/sys/ComboboxSelectedItemConverter.java-diff.html