package ke.novia.converters;

import org.joda.time.DateTime;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.UiException;
import org.zkoss.bind.BindContext;
import org.zkoss.bind.Converter;
import java.util.Date;

@SuppressWarnings("rawtypes")
public class JodaTimeZkConverter implements Converter {
	@Override
	public Object coerceToUi(Object val, Component component, BindContext ctx) {
		
        final String format = (String) ctx.getConverterArg("format");
        if(format==null) throw new NullPointerException("format attribute not found");
        final Date date = (Date) val;
        //return date == null ? null : new SimpleDateFormat(format).format(date);
        return new DateTime(date);
		/*
        if (val == null)
            return val;
        if (val instanceof DateTime) {
            return ((DateTime) val).toDate();
        }
        throw new UiException("Converter expects a Date/DateTime object");
        */
	}

	@Override
	public Object coerceToBean(Object val, Component component, BindContext ctx) {
		/*
        final String format = (String) ctx.getConverterArg("format");
        if(format==null) throw new NullPointerException("format attribute not found");
        final String date = (String) val;
        try {
            return date == null ? null : new SimpleDateFormat(format).parse(date);
        } catch (ParseException e) {
            throw UiException.Aide.wrap(e);
        }
        */
        if (val == null)
            return val;

        if (val instanceof Date) {
            return new DateTime(val);
        }
        throw new UiException("Converter expects a Date/DateTime object");
	}
	// <datebox id="db4" cols="12" format="long+medium" onCreate="self.value = new Date()" width="230px" />
	// <datebox id="db2" cols="12" format="medium" onCreate="self.value = new Date()" />
    // <timebox id="tb2" cols="12" format="medium" onCreate="self.value = new Date()" />
}