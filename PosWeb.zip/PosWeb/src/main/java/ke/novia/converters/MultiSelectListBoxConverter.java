package ke.novia.converters;

import java.lang.reflect.InvocationTargetException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.beanutils.BeanUtilsBean;
import org.zkoss.bind.BindContext;
import org.zkoss.bind.Converter;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.UiException;
import org.zkoss.zul.Combobox;
import org.zkoss.zul.Comboitem;
import org.zkoss.zul.ListModel;
import org.zkoss.zul.ListModelList;
import org.zkoss.zul.Listbox;
import org.zkoss.zul.Listitem;
import org.zkoss.zul.Radiogroup;
import org.zkoss.zul.ext.Selectable;

/**
 * Convert combobox selected comboitem to bean and vice versa.
 * @author henrichen
 * @author dennis
 * @since 6.0.0
 */
public class MultiSelectListBoxConverter implements Converter {

	@SuppressWarnings("unchecked")
	public Object coerceToUi(Object val, Component comp, BindContext ctx) {
		Listbox cbx = (Listbox) comp;
		cbx.setMultiple(true);
		final ListModel<?> model = cbx.getModel();
		//System.out.println("MultiSelectListBoxConverter");
		Set<Listitem> selectedItems =  new HashSet<Listitem>();
		Set<Object> dbItems = (Set<Object>) val;
		//ZK-762 selection of ListModelList is not correct if binding to selectedItem
		if (model != null && !(model instanceof Selectable)) {
			//model has to implement Selectable if binding to selectedItem
			throw new UiException("model doesn't implement Selectable");
		}
		try {
			int itemCount = model.getSize();
        	for(Object item : dbItems){
        		String sourcetVal = BeanUtilsBean.getInstance().getProperty(item, "id");
        		for(Listitem li : cbx.getItems()){
        			if(li.getValue()!=null){
	        			//System.err.println(li.getValue());
	        			String tempVal = BeanUtilsBean.getInstance().getProperty(li.getValue(), "id");
		        		//System.err.println(sourcetVal);
		        		if(sourcetVal.equals(tempVal)){
		        			System.err.println("Checkbox Match Successful! - "+item);
		        			selectedItems.add(li);
		        			//break;
		        		}
        			}
        		}
        	}
	        cbx.setSelectedItems(selectedItems);
	        
		} catch (Exception e) { e.printStackTrace();}
		
		return selectedItems;
	}
	public Object coerceToBean(Object val, Component comp, BindContext ctx) {
		//System.out.println(val);
		return val;
	}
}