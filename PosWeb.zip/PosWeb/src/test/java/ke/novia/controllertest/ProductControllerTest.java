package ke.novia.controllertest;



import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import ke.novia.services.stock.ProductService;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc(secure=false)

public class ProductControllerTest {

	    @Autowired
	    private WebApplicationContext webApplicationContext;
	    @MockBean //define a Mockito mock for ProductService
	    private ProductService productServiceMock;
	    
	    private MockMvc mockMvc;
	    
	    @Before
		public void setup() {
			mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
		}
	    
	    @Test
	    public void testList() throws Exception {
	    	assertThat(this.productServiceMock).isNotNull();
	       // mockMvc.perform(get("/Product"))
	        mockMvc.perform(MockMvcRequestBuilders.get("/Product"))
	        //.andExpect(status().isOk())           
            .andDo(print()); 
             
            
    
	    }
	    
	
}

