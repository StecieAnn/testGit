package ke.novia.controllertest;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import ke.novia.ApplicationTests;
import ke.novia.services.stock.SupplierService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SupplierControllerTest extends ApplicationTests {
	@Autowired
	private WebApplicationContext webApplicationContext;
	
	@Autowired
	SupplierService supplier;
	
	private MockMvc mockMvc;
	
	@Before
	public void setup() {
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
	}
	
	@Test
	public void testList() throws Exception { {
			mockMvc.perform(get("/Supplier"));

		}
	}

}
