package ke.novia.servicetest;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import ke.novia.dao.stock.SupplierDao;



public class SupplierServiceTest{

 private SupplierDao supplierDaoMock;
    @Before
    public void setUp() {
    	supplierDaoMock = Mockito.mock(SupplierDao.class);
    	
    }
    @Test
    public void SSuccessfuly() throws Exception {
    
    }

  
}