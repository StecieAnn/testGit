package ke.novia;


import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ApplicationTests {

	@Test
	public void contextLoads() {
	}

}
//BEST
//http://www.javainuse.com/spring/springboot_testcases
//http://www.springboottutorial.com/unit-testing-for-spring-boot-rest-services
//BEST




//http://www.springboottutorial.com/unit-testing-for-spring-boot-rest-services



//https://spring.io/guides/gs/testing-web/
//https://dzone.com/articles/unit-and-integration-tests-in-spring-boot
//https://github.com/spring-projects/spring-boot/tree/master/spring-boot-test/src/test/java/org/springframework/boot/test
//https://stackoverflow.com/questions/29053974/how-to-write-a-unit-test-for-a-spring-boot-controller-endpoint
//http://www.baeldung.com/spring-boot-testing