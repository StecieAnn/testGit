package ViewModels;

public class ProfileViewModel {

}
